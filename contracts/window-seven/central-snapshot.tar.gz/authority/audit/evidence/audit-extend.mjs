import fs from 'node:fs';
import {runtimeAppIntegrationInventory,resolveRuntimeAppProduct} from './repositories/sash-app/src/catalog/runtime-master/runtime-app-bridge.mjs';
const x=JSON.parse(fs.readFileSync('audit-raw.json'));
const i=x.sash.find(p=>p.integration.uiCategory==='ENTRY_DOOR_COVER');
if(i){
 const seen=new Map(i.fields.map(f=>[f.key,f]));
 const initial=await resolveRuntimeAppProduct(i.integration.id,{});
 for(const thermal of initial.fields.find(f=>f.key==='thermal_spec').values){
  const r=await resolveRuntimeAppProduct(i.integration.id,{thermal_spec:thermal.value});
  for(const opening of r.fields.find(f=>f.key==='opening_type').values){
   for(const mode of ['PRODUCT_SELECTION','SURVEY_LINKED']){
    const selection={thermal_spec:thermal.value,opening_type:opening.value,runtime_mode:mode};
    const rr=await resolveRuntimeAppProduct(i.integration.id,selection,{workflowScope:'site_survey'});
    i.samples.push({selection,field_order:rr.fields.map(f=>f.key),normalized_selection:rr.selection,clearedFields:rr.clearedFields??[]});
    for(const f of rr.fields){let q=seen.get(f.key);if(!q){q={key:f.key,observations:[],options:[]};seen.set(f.key,q);}q.observations.push({...f,values:undefined});for(const v of f.values??[])if(!q.options.some(o=>JSON.stringify(o.value)===JSON.stringify(v.value)&&o.displayLabel===v.displayLabel))q.options.push(v);}
   }
  }
 }
 i.fields=[...seen.values()];console.log('Rechent complete declared mode universe',i.fields.length);
}
for(const p of x.exterior)for(const f of p.fields)for(const o of f.observations)delete o.source_identity;
for(const a of ['sash','exterior','interior'])for(const p of x[a])for(const f of p.fields)f.observations=[...new Map(f.observations.map(o=>[JSON.stringify(o),o])).values()];
fs.writeFileSync('audit-raw-compact.json',JSON.stringify(x,null,2));
