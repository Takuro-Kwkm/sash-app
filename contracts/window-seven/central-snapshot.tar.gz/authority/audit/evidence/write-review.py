import json,collections,re,hashlib,zipfile,shutil
from pathlib import Path
R=Path('/workspace/scratch/d9b184420226');D=R/'deliverables'
load=lambda f:json.loads((D/f).read_text())
s=load('AUDIT_SUMMARY.json');fields=load('FIELD_INVENTORY.json')['fields'];prov=load('AUTHORITY_PROVENANCE.json')
flow=load('CATEGORY_FLOW_REGISTRY_DRAFT_v0.1.json')
# Pin final field orders directly to the category contract rather than approximating it.
for f in flow['flows']:
 if f['category_id']=='entrance_renovation':
  source=(R/'repositories/sash-app/src/catalog/runtime-master/entry-door-cover-runtime-ui-contract.mjs').read_text()
  extract=lambda name:re.findall(r"'([^']+)'",re.search(name+r' = Object.freeze\(\[(.*?)\]\)',source,re.S).group(1))
  f['semantic_slot_order']=extract('ENTRY_DOOR_COVER_UI_STANDARD_ORDER');f['presentation_field_order']=extract('ENTRY_DOOR_COVER_PRESENTATION_ORDER')
  f['groups']=['基本仕様','子扉・袖・ガラス','本体・枠・吊元','クローザ・ハンドル','錠・FamiLock','額縁・下枠','W/H','Survey Linked 採寸・Fit','オプション']
  f['group_order']=list(range(1,10));f['groups_note']='Audit review grouping only; exact current order is presentation_field_order copied from active contract; not a new registered group schema.'
 elif f['category_id']=='interior_window':
  f['semantic_stage_order']=['PRODUCT','OPENING','CONFIGURATION','SIZE','FINISH','SCREEN','GLAZING','INSTALLATION_SURVEY','OPTION']
  f['presentation_note']='Current shared engine semantic stages + field presentation extensions. Size metadata may remain SIZE while final dimension control displays after options. Empty stages omitted.'
(D/'CATEGORY_FLOW_REGISTRY_DRAFT_v0.1.json').write_text(json.dumps(flow,ensure_ascii=False,indent=2)+'\n')
summary=s['classification_count'];m=s['mapping_count'];cov=s['observation_coverage_count']
product_lines=[]
names={'SER-LIX-EW':'LIXIL EW','SER-LIXIL-TW':'LIXIL TW','SER-LIXIL-INPLUS':'LIXIL インプラス（浴室仕様含む）','SER-LIX-SAMOS2H':'LIXIL サーモスⅡ-H','SER-LIX-SAMOSL':'LIXIL サーモスL','SER-LIXIL-RECHENT-D3-NF':'LIXIL リシェント玄関ドア3 非防火 R8','SER-YKK-APW430':'YKK AP APW430','SER-YKK-APW431':'YKK AP APW431','SER-YKKAP-UCHIRIMO':'YKK AP ウチリモ 内窓','nesca':'LIXIL ネスカ','fugo':'LIXIL フーゴ','ef-first':'YKK AP エフルージュ FIRST','standard':'ラシッサS 標準ドア R12','slide-vrail':'ラシッサS 室内引戸 Vレール v1.3','parent':'ラシッサS 親子ドア v0.7.2','pet':'ラシッサS ペットドア（ACTIVE_LEGACY）','bifold':'ラシッサS 中折れドア','closet':'ラシッサS クローゼットドア'}
for p in dict.fromkeys(r['product']for r in fields if r['product']!='APP_ROUTE'):
 rr=[r for r in fields if r['product']==p];product_lines.append(f"| {rr[0]['app']} | {names.get(p,p)} | {rr[0]['category']} | {len(rr)} | {'静的棚卸し・Mapping未確定' if p in ['parent','pet','bifold','closet'] else 'Resolver／Contract'} |")
auth='\n'.join(f"| {a['title']} | [{a['file_id']}]({a['url']}) |"for a in prov['authority_documents'])
heads='\n'.join(f"| [{p['repository']}](https://github.com/{p['repository']}) | `{p['branch']}` | `{p['HEAD']}` |"for p in prov['identities'])
rules=load('UI_STANDARD_REGISTRY_DRAFT_v0.1.json')['rules']
global_table='\n'.join(f"| `{r['rule_id']}` | {r['semantic_target']} | {r['status']} | 採用／Category限定／Exception／却下 |"for r in rules if r['scope']=='GLOBAL')
text=f'''# 3アプリ横断 UI Standard / Global Selection Flow Audit

監査日：2026-10-02 UTC。**REGISTRY_DESIGN_READY = PASS**。

主要現行フローを読取・実行確認し、Currentの分類、Registry Draft、Mapping、Dependency、Drift、Renderer／CI候補、Human Review Packageまで作成した。PASSは**正式候補の設計レビューへ進める状態**を表す。Global正式採用・Repository登録・Production全件QAの判定ではない。今回、アプリ実装、Runtime、Formal、Product Master、既存Registry、CSS、ラベル、保存データを変更していない。Commit／PR／Merge／Deployは0件。

## 1. Repository / Branch / HEAD

| Repository | 固定Branch | 固定HEAD |
|---|---|---|
{heads}

サッシはPR61の統合head `1ef41376b95225c485e9e5ccfac1986c21a81d6c` を経てmainへMerge済み。インテリアはPR6の承認head `ad1021b49fb26a20656ed2b56f223e4c80369eb7` からMerge済み。標準ドアはPR5承認済みsourceをPR6に同梱したsnapshotであり、PR5のopen branchそのものを現行アプリと扱わない。エクステリアは共通Carport PR12とTheme PR15のMerge後main。古いopen統合・Theme branchをCurrentとしていない。取得時点の固定snapshotによる監査であり、監査中の後続変更は自動追従しない。

## 2. Current AuthorityとRelease対応

| 実取得したAuthority | Drive参照 |
|---|---|
{auth}

現行ImplementationとHuman／Browser／Release QA証拠を優先し、ACTIVE Manifestで仕様版を解決した。サッシUI v1.8/v1.9は現行標準の根拠に使わず、v2.1を採用。sourceに残る古い版名は履歴・Driftとして分離した。

インテリアはCURRENT_RELEASE_MANIFEST v1.6が **INT-20261002-R002 / dpl_A4KVZueQoMBhfnKLYyH1x4kFTjxb / main90fd…** を明示。現行統合HTML SHA256は `3f75e12481305156f8d2d165d566d8e955c385bce53f1ab277fd46d9c03ba1a7` で正式Canonicalと一致。Mac Chrome実描画1280/768/390、Device Parity、保存／再表示／積算引渡しのRelease記録を確認した。hostの旧v0.9.0表記やレビューBuild IDは承認どおり保持されるため、それだけで未Releaseとは判定しない。

サッシPR61の現行説明とMerge APIは営業見積scopeのReleaseを示す。エクステリアPR12／15には承認QA・Production後の回帰検証証拠がある。ただし、この監査ではサッシ／エクステリアの最新Productionを独立して描画し、固定main SHAへのlive deployment対応を再検証していない。Current main＋承認QAのcarry-forwardとして記録し、Production実観測と混同しない。エクステリアの古いPR本文に残る「未Merge」「Deploy blocker」はlive merged stateを上書きしない。

## 3. Auditした商品・カテゴリ

| App | 商品／統合 | Category | Field数 | 取得根拠 |
|---|---|---|---:|---|
{chr(10).join(product_lines)}

この18統合／モジュールにアプリのRouting4Fieldを加えた。インテリアCatalog9件のうち6embeddedが現行商品UI、旧slide／transom／toiletの3pendingを実装済みUIとして数えていない。クロゼット等の内部品種を別Module扱いで重複計上していない。

対象は商品選定とそれに直結するInput／固定・派生表示・Routing。一般案件CRUD、認証、ファイル添付、価格／品番計算式の全機能監査は範囲外。施工・採寸Fieldは商品Selectionに関係するContract分を含め、営業見積とSurvey scopeを分離した。

## 4–10. 件数と数え方

**581件**。app × registered integration/module × logical fieldを1件とした。条件付き子Fieldを個別計上し、Select／Cardの鏡像やSashのhidden native multiple Selectは同じStateの1Fieldとして数えた。固定Identity／Readonlyも棚卸し対象に含む。

| Field分類 | 件数 |
|---|---:|
| GLOBAL候補 | {summary.get('GLOBAL',0)} |
| CATEGORY候補 | {summary.get('CATEGORY',0)} |
| SERIES | {summary.get('SERIES',0)} |
| PRODUCT固有 | {summary.get('PRODUCT',0)} |
| EXCEPTION_CANDIDATE | {summary.get('EXCEPTION_CANDIDATE',0)} |
| DRIFT分類のField | {summary.get('DRIFT',0)} |
| UNKNOWN | {summary.get('UNKNOWN',0)} |

別の集計単位として、**Global UIルール候補13件、Category UIルール4件、Category Flow Draft7件、Exceptionレコード6件、Driftレコード2件**。同じExceptionが複数Fieldを対象とするので、19Fieldと6レコードは一致しない。Drift2件は棚卸し／Authority参照の横断問題であり、特定ユーザーFieldを恣意的にDRIFTへ変更していない。

取得CoverageはResolverサンプル{cov.get('RESOLVER_SAMPLES',0)}件、Contract定義だけのField79件、既存4Module静的Field85件、Routing4件。これらをすべてBrowserで見た件数とは扱わない。UNKNOWN75件は主に既存4Moduleの正式Canonical Mapping不足であり、「存在しないField」ではない。GLOBALは同じ商品Identityの意味とPresentation責務が確認できたFieldに限り、数量・勝手・色の似た名前を3アプリGlobal同義へ押し込んでいない。

## 11. UI_STANDARD_REGISTRY_DRAFT v0.1

`UI_STANDARD_REGISTRY_DRAFT_v0.1.json` は17ルール。要求されたregistry_version／rule_id／scope／semantic_target／control_type／presentation／placeholder／label_rule／value_rule／required_rule／visibility_rule／reset_rule／unit_rule／formatter_rule／output_rule／authority／source_app／source_revision／statusを保持する。PROPOSED、VERIFIED_CURRENT、NEEDS_HUMAN_REVIEWを区別し、正式Global採用はすべてfalse。

| Global候補ID | 対象 | Draft status | 人間の選択 |
|---|---|---|---|
{global_table}

「選択してください」は3アプリの主要Selectで確認できるが、**正式採用済みは室内建具13.11のscopeのみ**。Global昇格には人間判断が必要。validationの「選択してね」は別の責務なのでCopy Driftとしない。Requiredの`*`／badge／文言、FixedのSummary／disabled Select、Dark presentationの完全統一も未採用。現行の差異を保存し、新しいUI案を生成していない。

## 12. CATEGORY_FLOW_REGISTRY_DRAFT v0.1

| Category | Current Flow / 境界 | Draft状態 |
|---|---|---|
| carport | メーカー→Category→Series→タイプ→仕様→台数→支持→構成→サイズ→柱高さ→本体色→屋根材→屋根材色→Option→Site→派生性能→数量→納入施工→積算確認。19親slot、子Fieldは親内 | Current確認済み・採用レビュー待ち |
| indoor_joinery | 商品／方式→構造variant→勝手→W/H→デザイン→本体色→枠種類→見込→枠色→Glass→操作部品→部品色→錠→構造部品色→機能→依存部品→Readonly派生→下枠→特別仕様→数量→引渡し。21 semantic stage | 標準ドア／VレールCurrent、既存4Module Mapping未確定 |
| window | PRODUCT→OPENING→CONFIGURATION→SIZE→FINISH→SCREEN→GLAZING→INSTALLATION_SURVEY→OPTION | Current確認済み |
| interior_window | 上記とCategory slotを共有する箇所はあるがGlass／納まり／Option固有。最終W/Hはpresentation extensionで後段 | Current確認済み、Windowと分離 |
| entrance_renovation | 断熱→ランマ→開き形式→デザイン→子扉／袖／Glass→本体・枠・吊元→Hardware／錠／FamiLock→額縁・下枠→W/H→Survey Linked→Option | リシェント非防火R8、Current確認済み |
| entrance_door | 新築玄関ドアの現行登録商品UIを確認できない。リシェントへ代入しない | UNKNOWN・未完成 |
| cover_method | Entrance coverは上段のRechent。外窓coverの現行Runtime/UI根拠が不足。工法そのものを統一Product Flowにしない | UNKNOWN・未完成 |

Draftはgroups／group_order／standard_fields／field_order／required_fields／optional_fields／dependency_edges／reset_rules／extension_points／known_exceptions／authority／statusを持つ。Rechentのsemantic slot順とpresentation field順は**現行Contractから直接複写**し、取り違えを防いだ。Field一覧の抽出順はUI順のAuthorityではない。実状態ごとのfield_orderは`RESOLVER_OBSERVATIONS.json`、最終Orderは各Category Contractに固定する。新規商品候補の理想フローを発明していない。

## 13. FIELD_MAPPING_MATRIXとDependency

`FIELD_INVENTORY.json` に全581件の要求38属性と分類・Mapping・Exception・Coverageを記録した。Source revisionは全件固定SHA。属性不足はUNKNOWN／N/Aで保持し、Optionラベルと保存Valueを別配列として記録した。Optionの取得unionは**その商品・その選択状態での無条件Allowed Setではない**。正本Resolverに条件評価を委譲する。

Mapping：exact match {m.get('exact match',0)}、semantic match {m.get('semantic match',0)}、product specific {m.get('product specific',0)}、ambiguous {m.get('ambiguous',0)}、unmapped 0、独立Field ID重複0。ambiguousのCanonical KeyはUNKNOWN。似たLabelを理由にCanonicalを補完していない。window_specの多対1はsemantic container／承認aliasの関係であり、複数の独立Stateを一つへ合成していない。

Dependency Matrixは**727行**。Sashのdeclared parent、Carportの「先行canonical slotすべて」という保守的依存、子Field明示親、Interior Formalのeffect行、VレールRenderer実行例をprecision別に分離した。Formalの部品・品番・NON_UI・旧日本語名targetは独立Selectorへ勝手に変換していない。各行にKEEP／REEVALUATE／CLEAR／HIDE_AND_EXCLUDE／MANUAL_CONFIRM／UNKNOWN候補と現状根拠があり、未解決Mappingを残す。

## 14. DRIFT_REPORTとExceptions

| ID | Severity | 確認したCurrent | 影響と次Work対象 |
|---|---|---|---|
| D-001 | P1 | Sash既存V3棚卸しは4統合を0Fieldとしてtotal174、exit0。今回ResolverではサーモスⅡ-H30、サーモスL28、APW43016、APW43116の計90Fieldを確認 | Field coverage/flow gateが偽の完全性を示す可能性。inventory／adapter universe／CI層で扱う。UI欠落そのものとは判定しない |
| D-002 | P3 | Sash registry UI spec版名やcached Authority pointerにv1.9／旧v1.8が残る。ACTIVEはv2.1 | 将来Auditが旧標準を拾う可能性。Manifest FirstのAuthority resolver／metadata層 |

P0確認なし、P2の現行主要UI Copy／Raw enum／Output不整合は断定できない。SourceにString(value) fallbackはあるが、実際の無効内部enum露出を再現できたという意味ではない。古いFIRST QAのsnow=…表示は現行schemaの日本語Formatterで処理されるためCurrent Driftとしなかった。Required:true＋visible:falseも現行fieldSatisfiedが非該当をskipするので、そのmetadataだけで矛盾とは扱わない。

Exception候補は①Carport Select/Radio差、②内窓final寸法順、③Vレールdesign→glass標準戻し、④既存4Module段階移行、⑤出力destination別境界、⑥Placeholder正式scope。詳細は`EXCEPTION_CANDIDATES.json`。

Vレールの再現：**LGA／透明ガラスE → LGCを選ぶとカスミDへ置換**。LGCでもEはAllowed Candidateのまま。現行Rendererコメントが標準ガラスへ戻す意図を明示し、Current Good Implementationには理由がある。そのため、採用済みExceptionとは断言せずEXCEPTION_CANDIDATEとした。KEEP_VALID共通契約との扱いはHuman Reviewへ。actionsにはこの置換が明示されず、診断責務の共通化余地として記録した。修正していない。

## 15. Common Renderer Opportunity

ラベル／Option Label・Value、Required／Visibility／Disabled／Error／Empty、Readonly／Derived、Number Unit、Multi Enum State、Identity付きSave／Reloadの**責務interface**を共通化候補にした。既存Rendererを置換する具体UIは設計していない。サイズFormatterはCategory hook、選択肢・メーカー依存・製作範囲・価格／BOMはProduct／Runtime所有を維持する。既存4ModuleはCanonical Mappingを確定してから段階移行する候補で、類似JSの一括抽出を正当化するものではない。

## 16. CI Validation Candidates

`CI_VALIDATION_CANDIDATES.json` に15件。必須の12検査を含む。

| 検査責務 | 主な検出層 |
|---|---|
| raw Runtime exposure、Placeholder | STATIC＋UNIT TEST＋BROWSER TEST（scope／公式コード例外付き） |
| unknown control、Field ID重複、semantic role不足、target/reset不足、Global unmapped、Exception ID不足 | SCHEMA（NON_UI namespace・draft UNKNOWNを区別） |
| Order矛盾、Required／hidden実効矛盾、非該当Output、Save／Reload identity | UNIT TEST＋BROWSER TEST |
| Device parityと実際のsummary／handoff表示 | BROWSER TEST |
| registered Resolver universe欠落、Current Authority参照 | STATIC＋SCHEMA＋UNIT TEST |

既存GateをこのWorkで変更していない。UnknownなDraftを正式schemaへ昇格する際は必ず判定対象から分離する。Stage順だけ合う0Field inventoryをPASSさせない案がD-001に対応する。

## 17. Human Review Package

A Global候補、B Category Flow、C Drift、D Unresolvedを`HUMAN_REVIEW_PACKAGE.json`で分離した。特に次の判断が必要。

1. Placeholderを3アプリGlobalへ正式採用するか、室内建具限定を維持するか。
2. Carport同一slotのSelect/Radioを許可Control Setとするか商品Exceptionとするか。
3. Vレールvalid glassの標準戻しを商品Exceptionとして正式採用するか、別WorkでKEEP_VALIDへ合わせるか。
4. 既存4Module75 UNKNOWN FieldのCanonical Mappingを確定する時期と初回Registry適用scope。
5. 新築玄関ドア／外窓coverのactive product Authorityを追加取得するまでUNKNOWNを保持すること。
6. Requiredのglyph、Fixed presentation、Dark Modeは現行Category境界を維持すること。
7. 正式Registry登録前に、エクステリア最新Production→固定mainの追加対応証拠を必須にするか。

## 18. 検証と次Work判定

このセッションでは既存の対象テストを実行し、**134テストPASS（Sash33、Exterior20、Interior81）**。Interiorの初回はfixture未materializeでファイル単位失敗が1件発生したが、正本fixtureを取得してその17テストを再実行し全PASS。初回の64PASSと合わせ81PASSとして数え、失敗ログも保存した。Exteriorの帳票Component renderテスト1件はesbuild／React依存不足で未完遂。製品Assertion失敗と分離した。全アプリbuild／全suite／Browser QAの再実行はしていない。

既存Browser／Release QAはsource revision／coverageを明示してcarry-forwardした。ライブProduction全件実観測、全組合せ網羅、Legacy per-field state/output parityはこのPASSに含めない。取得時のソースmaterializationに伴う大容量File取得・UTF-8分割の問題は正本blob／cloneで解決済みで、製品Driftへ誤分類していない。Sash cloneのgit statusはclean。

**REGISTRY_DESIGN_READY = PASS**。3アプリの主要Current Good Flow、分類、2種類のRegistry Draft、Mapping、Dependency、Drift／Exception、Renderer／CI候補、Human Reviewが揃い、Non-mutationを守った。次Workとして、人間の採用判断と適用scope確定後に、隔離した正式Registry／Schema作成へ進める。UNKNOWNカテゴリとLegacy Mappingは未完成のまま明示的に分離し、既存Productionを変更する許可へ読み替えない。

## 納品ファイル

`UI_FLOW_AUDIT_v0.1.zip` にReport、UI／Flow Draft JSON、Field Inventory JSON、Field Mapping CSV、Reset Matrix JSON／CSV、Drift、Exception、Renderer、CI、Human Review、Authority／Summary、Resolver観測、既存Testログ・再現証拠・抽出スクリプトを同梱。外部Repositoryの全文や無関係な案件データは同梱していない。各ファイルのSHA256は`FILE_MANIFEST.json`に記録する。
'''
(D/'UI_FLOW_AUDIT_REPORT.md').write_text(text)
required=load('FIELD_INVENTORY.json')['required_columns']
checks=[]
checks.append({'check':'all requested inventory attributes','status':'PASS' if all(all(k in r for k in required)for r in fields)else 'FAIL','attribute_count':len(required)})
checks.append({'check':'unique qualified field_id','status':'PASS' if len(set(r['field_id']for r in fields))==len(fields)else 'FAIL'})
checks.append({'check':'classification sum','status':'PASS' if sum(s['classification_count'].values())==len(fields)else 'FAIL'})
checks.append({'check':'source revision pinned','status':'PASS' if all(re.fullmatch('[0-9a-f]{40}',r['source_revision'])for r in fields)else 'FAIL'})
uikeys=['registry_version','rule_id','scope','semantic_target','control_type','presentation','placeholder','label_rule','value_rule','required_rule','visibility_rule','reset_rule','unit_rule','formatter_rule','output_rule','authority','source_app','source_revision','status']
checks.append({'check':'UI draft required schema','status':'PASS'if all(all(k in r for k in uikeys)for r in rules)else 'FAIL'})
flowkeys=['category_id','flow_version','groups','group_order','standard_fields','field_order','required_fields','optional_fields','dependency_edges','reset_rules','extension_points','known_exceptions','authority','status']
checks.append({'check':'flow draft required schema','status':'PASS'if all(all(k in r for k in flowkeys)for r in flow['flows'])else 'FAIL'})
exc={e['exception_id']for e in load('EXCEPTION_CANDIDATES.json')['exceptions']}
checks.append({'check':'exception references resolve','status':'PASS' if all(x in exc for r in fields for x in r['exception_ids'])else 'FAIL'})
checks.append({'check':'canonical artifact hashes','status':'PASS'if all(x['sha256']==x['authority_expected_sha256']for x in prov['artifact_checks'])else 'FAIL'})
checks.append({'check':'current source paths resolve','status':'PASS','note':'source paths verified locally; legacy embedded module fragment is exact current host artifact'})
for r in fields:
 for source in r['source_implementation_path']:
  if isinstance(source,dict)and 'path'in source:
   app=source['repository'].split('/')[-1];p=R/('repositories'if app=='sash-app'else'evidence')/app/source['path']
   if not p.exists():checks[-1]['status']='FAIL';checks[-1].setdefault('missing',[]).append(source['path'])
(D/'ARTIFACT_VALIDATION.json').write_text(json.dumps({'validation_scope':'audit deliverables only; does not promote current UI assertions','checks':checks},ensure_ascii=False,indent=2))
assert all(c['status']=='PASS'for c in checks),checks
shutil.copyfile(R/'build-audit.py',D/'evidence/build-audit.py');shutil.copyfile(R/'write-review.py',D/'evidence/write-review.py')
manifest=[{'path':str(p.relative_to(D)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(D.rglob('*'))if p.is_file()and p.name!='FILE_MANIFEST.json']
(D/'FILE_MANIFEST.json').write_text(json.dumps({'version':'0.1','files':manifest},ensure_ascii=False,indent=2))
with zipfile.ZipFile(R/'UI_FLOW_AUDIT_v0.1.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(D.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(D)))
print(json.dumps({'report_bytes':(D/'UI_FLOW_AUDIT_REPORT.md').stat().st_size,'archive_bytes':(R/'UI_FLOW_AUDIT_v0.1.zip').stat().st_size,'files':len(manifest)+1,'validation':checks},ensure_ascii=False,indent=2))
