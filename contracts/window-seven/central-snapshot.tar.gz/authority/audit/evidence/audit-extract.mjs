import fs from 'node:fs';
import path from 'node:path';
import {runtimeAppIntegrationInventory,resolveRuntimeAppProduct} from './repositories/sash-app/src/catalog/runtime-master/runtime-app-bridge.mjs';
import {loadRegisteredRuntime} from './repositories/sash-app/src/catalog/runtime-master/runtime-master-registry.mjs';
import {applyRuntimeUiCategoryOrder} from './repositories/sash-app/src/catalog/runtime-master/new-construction-sash-runtime-ui-contract.mjs';
import {carportAdapters} from './evidence/exterior-estimator/src/features/runtime/carport/adapters.ts';
import {getCarportFlow,transitionCarport,initialCarportState} from './evidence/exterior-estimator/src/features/runtime/carport/engine.ts';
import {createVrailRendererRuntime} from './evidence/interior-estimator/packages/interior-runtime-adapter/lasissa-s-vrail.mjs';
import {buildCanonicalRuntime} from './evidence/interior-estimator/candidate/standard-door/packages/interior-runtime-adapter/lasissa-s-standard-door.mjs';
import * as std from './evidence/interior-estimator/candidate/standard-door/packages/flow-engine/selection-runtime.mjs';
const out={sash:[],exterior:[],interior:[],errors:[],coverage_note:'Field union from declared contracts and deterministic branch samples; not exhaustive state coverage and not browser QA.'};
const json=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const hashState=s=>JSON.stringify(s,Object.keys(s).sort());
const exists=x=>x!==undefined&&x!==null&&x!=='';
for(const integration of runtimeAppIntegrationInventory()){
 const runtime=await loadRegisteredRuntime(integration.manufacturer,integration.series);
 const item={integration,fields:[],definitions:runtime.master?.fields??[],samples:[],source_integrity:runtime.sourcePackageIntegrity};
 const seen=new Map();
 function collect(r,selection){
  item.samples.push({selection,field_order:r.fields.map(f=>f.key),normalized_selection:r.selection,clearedFields:r.clearedFields??[]});
  for(const f of r.fields){
   let rec=seen.get(f.key);if(!rec){rec={key:f.key,observations:[],options:[]};seen.set(f.key,rec);}
   rec.observations.push({...f,values:undefined});
   for(const v of f.values??[])if(!rec.options.some(x=>JSON.stringify(x.value)===JSON.stringify(v.value)&&x.displayLabel===v.displayLabel))rec.options.push(v);
  }
 }
 async function run(seed={},greedy=false){
  let s={...seed},prev='',r;
  for(let turn=0;turn<(greedy?15:1);turn++){
   r=await resolveRuntimeAppProduct(integration.id,s);collect(r,s);
   let next={...r.selection};
   for(const f of r.fields){if(f.readOnly||f.disabled||exists(next[f.key])||!f.required)continue;
    const value=f.values?.find(v=>!v.disabled)?.value;
    if(value!==undefined)next[f.key]=f.dataType==='MULTI_ENUM'?[value]:value;
   }
   const sig=hashState(next);if(sig===prev)break;prev=sig;s=next;
  }
  return {r,state:s};
 }
 try{
  const base=await run({},true);
  const first=await resolveRuntimeAppProduct(integration.id,{});
  for(const key of ['window_type','room_specification','product_variant','thermal_spec','lock_type','opening_type','transom']){
   const f=first.fields.find(f=>f.key===key)??base.r.fields.find(f=>f.key===key);
   for(const candidate of f?.values??[])if(!candidate.disabled)await run({...base.state,[key]:candidate.value},true);
  }
  for(const key of ['glass_family','size_mode','fukashi_presence','fukashi_depth','sash_configuration','design','electric_lock_power','sales_midrail_request']){
   const f=base.r.fields.find(f=>f.key===key);
   for(const v of (f?.values??[]).slice(0,8))if(!v.disabled)await run({...base.state,[key]:v.value},true);
  }
  for(const key of ['option_items','option']){
   const f=base.r.fields.find(f=>f.key===key);
   for(const v of (f?.values??[]).slice(0,8))await run({...base.state,[key]:[v.value]},true);
  }
  if(integration.uiCategory==='INNER_WINDOW')await run({...base.state,room_specification:'bathroom'},true);
  if(integration.id==='SER-LIXIL-INPLUS')await run({product_variant:'bathroom'},true);
  const survey=await resolveRuntimeAppProduct(integration.id,{...base.state,runtime_mode:'SITE_SURVEY'},{workflowScope:'site_survey'});collect(survey,{...base.state,runtime_mode:'SITE_SURVEY'});
  for(const def of runtime.master?.fields??[]){
   if(seen.has(def.field_name))continue;
   try{const fields=applyRuntimeUiCategoryOrder([{key:def.field_name,field_name:def.field_name,displayLabel:def.display_label,dataType:({enum:'ENUM',array:'MULTI_ENUM',number:'NUMBER',integer:'NUMBER',string:'TEXT',boolean:'ENUM'})[def.data_type]??'UNKNOWN',values:[],required:def.required_mode==='REQUIRED',displayOrder:def.display_order,...def}],integration);
    if(fields[0])seen.set(def.field_name,{key:def.field_name,observations:[fields[0]],options:[],declared_only:true});
   }catch(error){item.unmapped??=[];item.unmapped.push({key:def.field_name,error:error.message});}
  }
  item.fields=[...seen.values()];
 }catch(error){out.errors.push({app:'sash',product:integration.id,message:error.message});item.fields=[...seen.values()];}
 out.sash.push(item);
 console.log('sash',integration.series,item.fields.length,item.samples.length);
}
for(const a of carportAdapters){
 const item={product:a.slug,manufacturer:a.manufacturer,name:a.name,identity:a.identity,mapping:a.mapping,fields:[],samples:[]};const seen=new Map();
 function collect(s){const flow=getCarportFlow(a.slug,s);item.samples.push({state:s,field_order:flow.filter(f=>f.visible).map(f=>f.slot_id)});
  for(const f of flow.flatMap(f=>[f,...(f.children??[])])){let rec=seen.get(f.slot_id);if(!rec){rec={key:f.slot_id,observations:[],options:[]};seen.set(f.slot_id,rec);}rec.observations.push({...f,children:undefined,allowed_values:undefined});for(const c of f.allowed_values)if(!rec.options.some(x=>x.id===c.id&&x.label===c.label))rec.options.push(c);}
 }
 function complete(seed){let s=transitionCarport(a.slug,initialCarportState(a.slug),seed).state;
  for(let pass=0;pass<2;pass++)for(const f of getCarportFlow(a.slug,s)){
   if(f.visible&&f.behavior_mode==='USER_SELECTABLE'&&f.control!=='MULTI_SELECT'&&f.allowed_values.length&&!exists(s[f.slot_id]))s=transitionCarport(a.slug,s,{[f.slot_id]:f.allowed_values.find(c=>!c.disabled)?.id}).state;
  }return s;
 }
 const base=complete({});collect(initialCarportState(a.slug));collect(base);
 for(const f of getCarportFlow(a.slug,base)){
  if(f.control==='MULTI_SELECT')for(const c of f.allowed_values)collect(complete({...base,[f.slot_id]:[c.id]}));
  else if(['product_type','product_variant','vehicle_capacity','support_configuration','layout_type','roof_material'].includes(f.slot_id))for(const c of f.allowed_values.slice(0,15))collect(complete({...base,[f.slot_id]:c.id}));
 }
 collect(complete({...base,fulfillment_mode:'DELIVERY_ONLY',service_details:{delivery_method:'PICKUP'}}));
 collect(complete({...base,fulfillment_mode:'INSTALLATION',service_details:{ground_condition:'GRAVEL',chipping_required:'YES',water_free_loan:'YES',electricity_free_loan:'YES'}}));
 item.fields=[...seen.values()];out.exterior.push(item);console.log('exterior',a.slug,item.fields.length,item.samples.length);
}
const interiorRoot='evidence/interior-estimator/';
const vr=createVrailRendererRuntime(json(interiorRoot+'candidate/data/runtime/lasissa-s-vrail.formal.json'));
const standardRoot=interiorRoot+'candidate/standard-door/';
const sr=buildCanonicalRuntime(json(standardRoot+'data/runtime/LIXIL_LASISSA_S_STD_DOOR_runtime_v0.1-CANDIDATE-R12.json'),json(standardRoot+'tests/full-coverage/fixtures/lasissa-s-standard-door.r12.mapping-input.json'),json(standardRoot+'packages/interior-canonical-schema/lasissa-s-standard-door.r12.mapping.json'),json(standardRoot+'packages/flow-engine/interior-joinery.global-selection-flow.v1.0.json'),{asOf:'2026-09-30'});
for(const [kind,runtime] of [['standard',sr],['slide-vrail',vr]]){
 const getCandidates=(key,s)=>kind==='standard'?std.getCandidateSet(runtime,key,s):runtime.adapter.candidates(key,s);
 const visible=(key,s)=>kind==='standard'?std.fieldIsVisible(runtime,key,s):runtime.adapter.visible(key,s);
 const required=(key,s)=>kind==='standard'?std.fieldIsRequired(runtime,key,s):runtime.adapter.required(key,s);
 const change=(s,key,value)=>kind==='standard'?std.reconcileSelectionState(runtime,s,key,value).state:runtime.adapter.normalize({...s,[key]:value});
 const fields=runtime.flow.fields.map(f=>({...f}));
 if(kind==='standard'&&!fields.some(f=>f.key==='quantity'))fields.push({key:'quantity',label:'依頼数量',input:'number',required:true,order:fields.length,source_field:'SharedProductSelection quantity UI'});
 let base=kind==='standard'?{quantity:1,special_spec_records:[]}:runtime.adapter.initialState();
 for(let pass=0;pass<3;pass++)for(const f of fields){if(f.input==='readonly'||!visible(f.key,base)||exists(base[f.key]))continue;const c=getCandidates(f.key,base)[0];if(c)base=change(base,f.key,f.input==='multi_select'?[]:c.value);}
 const samples=[{},base];
 for(const f of fields)for(const c of getCandidates(f.key,base).slice(0,30))samples.push(change(base,f.key,f.input==='multi_select'?[c.value]:c.value));
 const rows=fields.map(f=>{const options=[];const observations=[];for(const s of samples){const candidates=getCandidates(f.key,s);for(const c of candidates)if(!options.some(x=>x.value===c.value&&x.label===c.label))options.push(c);observations.push({visible:visible(f.key,s),required:required(f.key,s)});}return{...f,options,observations};});
 out.interior.push({product:kind,identity:runtime.identity,mapping:runtime.mapping,fields:rows,samples,dependencies:kind==='standard'?runtime.data.dependencies:vr.core.rules,base});console.log('interior',kind,rows.length,samples.length);
}
fs.writeFileSync('audit-raw.json',JSON.stringify(out,null,2));
