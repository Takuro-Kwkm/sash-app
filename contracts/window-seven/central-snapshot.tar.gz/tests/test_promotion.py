import copy
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from contracts import load_bundle, validate_bundle, validate_formal_promotion
from formal_promotion import (COMMON, GATES, digest, validate_promotion, validate_evidence,
                             acceptance_payload, approval_payload, runtime_identity)

spec = importlib.util.spec_from_file_location('promotion_builder', ROOT / 'scripts/build-promotion-fixtures.py')
builder = importlib.util.module_from_spec(spec); spec.loader.exec_module(builder)
BASE = load_bundle()
POLICY = BASE['promotion_policy']
CASES = json.loads((ROOT / 'fixtures/promotion-negative.v0.1.json').read_text())['cases']

def make_case(root, classification='EXACT', fact_kind='PRODUCT_FACT'):
    # Fully synthetic product/evidence. Never admitted into central or app data.
    field = copy.deepcopy(BASE['references'][0])
    field.update(field_id='fixture-app:generic-item:choice', status='FORMAL')
    field['scope'] = {'app': 'fixture-app', 'product': 'generic-item', 'kind': 'APPLICATION_FIELD'}
    mapped = {k: field[k] for k in ['field_id', 'category', 'semantic_role', 'runtime_key', 'canonical_key']}
    mapped.update(app=field['scope']['app'], product=field['scope']['product'],
                  mapping_type={'EXACT': 'exact match', 'SEMANTIC': 'semantic match', 'PRODUCT_SPECIFIC': 'product specific'}[classification])
    mapping = {field['field_id']: mapped}
    builder.write(root, 'fixtures/synthetic-authority.json', {'scope': 'SYNTHETIC_TEST_ONLY',
                  'official_fact': 'fictional choice', 'meaning': 'fixture semantic meaning', 'rules': 'fixture responsibility'})
    builder.write(root, 'fixtures/synthetic-runtime.json', {'scope': 'SYNTHETIC_TEST_ONLY', 'field_id': field['field_id'],
                  'runtime_identity_sha256': runtime_identity(field), 'runtime_parity': 'PASS', 'flow_parity': 'PASS'})
    claims = COMMON + ['PRODUCT_FACT', 'FIELD_RESPONSIBILITY', 'DERIVATION_AUTHORITY', 'MEANING_EQUIVALENCE', 'PRODUCT_SPECIFIC_IDENTITY']
    sources = [('SYNTHETIC-OFFICIAL', 'OFFICIAL_PRIMARY_SOURCE', builder.ref(root, 'fixtures/synthetic-authority.json'), claims),
               ('SYNTHETIC-RUNTIME', 'VERIFIED_RUNTIME_BEHAVIOR', builder.ref(root, 'fixtures/synthetic-runtime.json'), ['RUNTIME_PARITY'])]
    evidence, promotions = builder.certify(root, [field], mapping, 'APPLICATION_FIELD', sources, fact_kind, 'SYNTHETIC')
    return {'field': field, 'evidence': evidence, 'promotions': promotions, 'mapping': mapping,
            'gates': {name: [] for name in GATES}, 'root': root, 'policy': copy.deepcopy(POLICY)}

def refresh(case):
    """Re-attest deliberate test changes so each policy rejection is isolated."""
    root = case['root']; registry = case['evidence']; promotions = case['promotions']
    decisions = []
    for e in registry['evidence']:
        decisions.append({'decision_id': e['review']['decision_id'], 'status': 'APPROVED', 'payload': acceptance_payload(e)})
    path = 'authority/synthetic-evidence-decisions.v0.1.json'
    builder.write(root, path, {'scope': 'SYNTHETIC_TEST_ONLY', 'decisions': decisions})
    for a in registry['authorities']:
        if a['authority_id'] == 'SYNTHETIC-ACCEPTANCE-REVIEW': a['identity'] = builder.ref(root, path)
    for i, e in enumerate(registry['evidence']): e['review']['decision_ref'] = builder.ref(root, path, '/decisions/' + str(i))
    for a in promotions['approvals']:
        d = next(d for d in promotions['dossiers'] if d['approval_id'] == a['approval_id'])
        a.update(contract_sha256=d['contract_sha256'], dossier_sha256=digest(d),
                 evidence_sha256=digest([e for eid in d['evidence_ids'] for e in registry['evidence'] if e['evidence_id'] == eid]))
    path = 'authority/synthetic-promotion-decisions.v0.1.json'
    builder.write(root, path, {'scope': 'SYNTHETIC_TEST_ONLY',
                              'decisions': [{'decision_id': a['review']['decision_id'], 'status': 'APPROVED', 'payload': approval_payload(a)} for a in promotions['approvals']]})
    for a in registry['authorities']:
        if a['authority_id'] == 'SYNTHETIC-PROMOTION-REVIEW': a['identity'] = builder.ref(root, path)
    for i, a in enumerate(promotions['approvals']): a['review']['decision_ref'] = builder.ref(root, path, '/decisions/' + str(i))

def validate(case):
    return validate_promotion(case['policy'], case['evidence'], case['promotions'],
                              [(case['field'], 'APPLICATION_FIELD')], case['root'], case['gates'], case['mapping'])

def mutate(c, name):
    e = c['evidence']['evidence'][0]; d = c['promotions']['dossiers'][0]; a = c['promotions']['approvals'][0]
    if name == 'no_evidence': d['evidence_ids'] = []
    elif name in {'insufficient', 'conflicting'}: e['status'] = name.upper(); refresh(c)
    elif name == 'malformed': del e['source_identifier']
    elif name == 'invalid_approval': a['review']['decision_id'] = 'UNREGISTERED'
    elif name == 'blocker': c['promotions']['blockers'].append({'blocker_id': 'GAP', 'field_id': c['field']['field_id'], 'status': 'OPEN', 'reason': 'Unresolved official source conflict'})
    elif name == 'illegal_transition': d['transition']['from'] = 'FORMAL'; refresh(c)
    elif name == 'unknown_class': e['source_class'] = 'AI_INFERENCE'
    elif name == 'invalid_reference': d['evidence_ids'] = ['ABSENT']; refresh(c)
    elif name == 'unverified': e['verification_state'] = 'UNVERIFIED'; refresh(c)
    elif name == 'self_declaration': c['promotions']['dossiers'] = []; c['promotions']['approvals'] = []
    elif name == 'mapping': c['mapping'][c['field']['field_id']]['mapping_type'] = 'ambiguous'
    elif name.endswith('_gate'):
        gate = {'semantic_gate': 'mapping', 'exception_gate': 'exceptions', 'presentation_gate': 'presentation-resolution', 'dependency_gate': 'dependency'}[name]
        c['gates'][gate] = [{'code': 'EXISTING_AUTHORITY_REJECTED', 'path': c['field']['field_id'], 'message': 'invalid scoped contract'}]
    elif name == 'unknown_state': d['transition']['to'] = 'BLOCKED'
    elif name == 'product_hardcode': c['policy']['product_overrides'] = {'generic-item': 'PASS'}
    elif name == 'runtime_fact':
        e['source_class'] = 'VERIFIED_RUNTIME_BEHAVIOR'
        c['evidence']['authorities'][0]['source_classes'] = ['VERIFIED_RUNTIME_BEHAVIOR']; refresh(c)
    elif name == 'reference_application': d['fact_kind'] = 'REFERENCE_CONTRACT'; refresh(c)
    elif name == 'semantic_evidence':
        d['mapping_classification'] = 'SEMANTIC'; c['mapping'][c['field']['field_id']]['mapping_type'] = 'semantic match'
        e['claims'].remove('MEANING_EQUIVALENCE'); refresh(c)
    elif name == 'specific_reason':
        d['mapping_classification'] = 'PRODUCT_SPECIFIC'; c['mapping'][c['field']['field_id']]['mapping_type'] = 'product specific'; refresh(c)
    elif name == 'scope': e['scope']['category'] = 'other-category'; refresh(c)
    elif name == 'stale_approval': d['mapping_rationale'] += ' changed'
    elif name == 'stale_contract': c['field']['runtime_key'] = 'changed_runtime_key'
    elif name == 'source_hash': e['source_ref']['sha256'] = '0' * 64
    elif name == 'hidden_conflict':
        conflict = copy.deepcopy(e); conflict['evidence_id'] = 'HIDDEN-CONFLICT'; conflict['status'] = 'CONFLICTING'
        c['evidence']['evidence'].append(conflict); refresh(c)
    elif name == 'duplicate_evidence': c['evidence']['evidence'].append(copy.deepcopy(e))
    elif name == 'duplicate_dossier': c['promotions']['dossiers'].append(copy.deepcopy(d))
    elif name == 'acceptance': e['review']['decision_id'] = 'UNREGISTERED'
    elif name == 'semantic_change':
        d['transition']['previous_contract']['runtime_key'] = 'different_old_key'
        d['transition']['previous_contract_sha256'] = digest(d['transition']['previous_contract']); refresh(c)
    elif name == 'runtime_missing':
        runtime = c['evidence']['evidence'][1]; runtime['claims'] = ['DEPENDENCY']; refresh(c)
    else: raise AssertionError('Unknown fixture mutation: ' + name)

class NegativeValidation(unittest.TestCase): pass

for case in CASES:
    def reject(self, case=case):
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory)); self.assertEqual([], validate(c))
            mutate(c, case['mutation'])
            errors = validate(c)
            self.assertIn(case['expected_error'], {e['code'] for e in errors}, str(errors))
    setattr(NegativeValidation, 'test_' + case['fixture_id'].replace('-', '_'), reject)

class PromotionGovernance(unittest.TestCase):
    def test_machine_readable_positive_fixture_cases_A_to_D(self):
        packet = json.loads((ROOT / 'fixtures/promotion-positive.v0.1.json').read_text())
        self.assertEqual(['A', 'B', 'C', 'D'], [x['case_id'] for x in packet['cases']])
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for path, value in packet['files'].items(): builder.write(root, path, value)
            c = {k: copy.deepcopy(packet[k]) for k in ['field', 'mapping', 'evidence', 'promotions']}
            c.update(root=root, policy=copy.deepcopy(POLICY), gates={k: [] for k in GATES})
            provisional = copy.deepcopy(c); provisional['field']['status'] = 'PROVISIONAL'
            provisional['evidence'] = {'version': '0.1', 'authorities': [], 'evidence': []}
            provisional['promotions'] = {'version': '0.1', 'approvals': [], 'dossiers': [], 'blockers': []}
            self.assertEqual([], validate(provisional))  # A
            self.assertEqual([], validate(c))  # B
            mutate(c, 'insufficient'); self.assertTrue(validate(c))  # C
            c['evidence']['evidence'][0]['status'] = 'ACCEPTED'; refresh(c)
            self.assertEqual([], validate(c))  # D

    def test_existing_baseline_and_reference_certifications_valid(self):
        self.assertEqual('PASS', validate_bundle(BASE)['status'])
        self.assertEqual(492, sum(f['status'] == 'PROVISIONAL' for f in BASE['fields']))
        self.assertEqual(5, len(BASE['field_promotions']['dossiers']))
        self.assertTrue(all(d['purpose'] == 'CONTRACT_REFERENCE' for d in BASE['field_promotions']['dossiers']))

    def test_provisional_needs_no_formal_only_evidence(self):
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory)); c['field']['status'] = 'PROVISIONAL'
            c['evidence'] = {'version': '0.1', 'authorities': [], 'evidence': []}
            c['promotions'] = {'version': '0.1', 'approvals': [], 'dossiers': [], 'blockers': []}
            self.assertEqual([], validate(c))

    def test_complete_evidence_and_approval_valid_for_each_class(self):
        for classification in ['EXACT', 'SEMANTIC', 'PRODUCT_SPECIFIC']:
            with self.subTest(classification=classification), tempfile.TemporaryDirectory() as directory:
                self.assertEqual([], validate(make_case(Path(directory), classification)))

    def test_same_field_insufficient_then_added_evidence_eligible(self):
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory)); field = copy.deepcopy(c['field'])
            mutate(c, 'insufficient'); self.assertTrue(validate(c))
            c['evidence']['evidence'][0]['status'] = 'ACCEPTED'; refresh(c)
            self.assertEqual([], validate(c)); self.assertEqual(field, c['field'])

    def test_mixed_formal_provisional(self):
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory)); provisional = copy.deepcopy(c['field'])
            provisional.update(field_id='fixture-app:generic-item:pending', status='PROVISIONAL')
            self.assertEqual([], validate_promotion(c['policy'], c['evidence'], c['promotions'],
                             [(c['field'], 'APPLICATION_FIELD'), (provisional, 'APPLICATION_FIELD')], c['root'], c['gates'], c['mapping']))

    def test_business_input_and_derived_require_scoped_authority(self):
        for kind in ['BUSINESS_INPUT', 'DERIVED']:
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as directory:
                c = make_case(Path(directory), fact_kind=kind)
                self.assertEqual([], validate(c))
                claim = 'FIELD_RESPONSIBILITY' if kind == 'BUSINESS_INPUT' else 'DERIVATION_AUTHORITY'
                c['evidence']['evidence'][0]['claims'].remove(claim); refresh(c)
                self.assertIn('FORMAL_REQUIREMENTS_UNMET', {e['code'] for e in validate(c)})

    def test_demotion_preserves_provisional_without_formal_requirements(self):
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory)); previous = copy.deepcopy(c['field']); c['field']['status'] = 'PROVISIONAL'
            d = c['promotions']['dossiers'][0]; d['contract_sha256'] = digest(c['field'])
            d['transition'].update({'from': 'FORMAL', 'to': 'PROVISIONAL', 'reason': 'Evidence lost; approved reevaluation',
                                    'previous_contract': previous, 'previous_contract_sha256': digest(previous)})
            c['evidence']['evidence'][0]['status'] = 'INSUFFICIENT'; refresh(c)
            self.assertEqual([], validate(c))

    def test_reference_certification_cannot_be_reused_in_application(self):
        b = copy.deepcopy(BASE); f = copy.deepcopy(b['references'][0]); b['fields'].append(f)
        codes = {e['code'] for e in validate_formal_promotion(b)}
        self.assertIn('FORMAL_PROMOTION_REQUIRED', codes)

    def test_empty_or_unknown_gate_is_not_a_pass(self):
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory)); del c['gates']['mapping']
            self.assertIn('PROMOTION_GATE_FAILED', {e['code'] for e in validate(c)})

    def test_source_path_cannot_escape_snapshot(self):
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory)); c['evidence']['authorities'][0]['identity']['path'] = '../outside.json'
            self.assertIn('INVALID_PROMOTION_AUTHORITY', {e['code'] for e in validate(c)})

    def test_real_existing_validator_failures_block_formal(self):
        for gate, mutation in [('schema', lambda b: b['references'][0].update(status='INVALID')),
                               ('mapping', lambda b: b['mapping']['fields'][0].update(semantic_role='UNKNOWN')),
                               ('presentation-resolution', lambda b: b['presentation_fixtures'][0]['contract']['presentation_resolution'].update(version='INVALID')),
                               ('dependency', lambda b: b['dependencies']['edges'][0].update(upstream='ABSENT')),
                               ('exceptions', lambda b: next(e for e in b['exceptions']['exceptions'] if e['status']=='TEMPORARY_EXCEPTION')['expiry_or_review_condition'].update(review_by='2000-01-01'))]:
            with self.subTest(gate=gate):
                b = copy.deepcopy(BASE); mutation(b)
                errors = validate_formal_promotion(b)
                self.assertTrue(any(e['code']=='PROMOTION_GATE_FAILED' and e['message'].endswith(gate) for e in errors), errors)

    def test_governance_is_generic_across_scope_names(self):
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory)); f = c['field']; f['scope']['app'] = 'another-app'; f['scope']['product'] = 'another-product'
            c['mapping'][f['field_id']].update(app='another-app', product='another-product')
            d = c['promotions']['dossiers'][0]; d['contract_sha256'] = digest(f)
            d['transition']['previous_contract']['scope'] = copy.deepcopy(f['scope'])
            d['transition']['previous_contract_sha256'] = digest(d['transition']['previous_contract']); refresh(c)
            path = 'fixtures/synthetic-runtime.json'
            report = json.loads((c['root'] / path).read_text()); report['runtime_identity_sha256'] = runtime_identity(f)
            builder.write(c['root'], path, report)
            c['evidence']['authorities'][1]['identity'] = builder.ref(c['root'], path)
            c['evidence']['evidence'][1]['source_ref'] = builder.ref(c['root'], path); refresh(c)
            self.assertEqual([], validate(c))

    def test_failed_runtime_report_is_rejected_even_when_accepted(self):
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory)); path = 'fixtures/synthetic-runtime.json'
            report = json.loads((c['root'] / path).read_text()); report['runtime_parity'] = 'FAIL'
            builder.write(c['root'], path, report)
            c['evidence']['authorities'][1]['identity'] = builder.ref(c['root'], path)
            c['evidence']['evidence'][1]['source_ref'] = builder.ref(c['root'], path); refresh(c)
            self.assertIn('INVALID_RUNTIME_PARITY_EVIDENCE', {e['code'] for e in validate(c)})

    def test_unresolved_exception_cannot_hide_without_field_reference(self):
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory))
            errors = validate_promotion(c['policy'], c['evidence'], c['promotions'], [(c['field'], 'APPLICATION_FIELD')],
                      c['root'], c['gates'], c['mapping'], exception_records=[{'field_id': [c['field']['field_id']], 'status': 'PENDING_REVIEW'}])
            self.assertIn('UNRESOLVED_PROMOTION_EXCEPTION', {e['code'] for e in errors})

    def test_review_cannot_use_unregistered_decision_artifact(self):
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory)); c['evidence']['evidence'][0]['review']['decision_ref']['path'] = 'forged.json'
            self.assertIn('INVALID_EVIDENCE_ACCEPTANCE', {e['code'] for e in validate(c)})

    def test_retired_source_and_review_authorities_are_rejected(self):
        for index, code in [(0, 'INVALID_EVIDENCE_REFERENCE'), (2, 'INVALID_EVIDENCE_ACCEPTANCE')]:
            with self.subTest(index=index), tempfile.TemporaryDirectory() as directory:
                c = make_case(Path(directory)); c['evidence']['authorities'][index]['status'] = 'RETIRED'
                self.assertIn(code, {e['code'] for e in validate(c)})

    def test_approved_document_with_malformed_decision_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory)); path = 'authority/synthetic-evidence-decisions.v0.1.json'
            builder.write(c['root'], path, {'decisions': ['malformed', 'malformed']})
            c['evidence']['authorities'][2]['identity'] = builder.ref(c['root'], path)
            for i, e in enumerate(c['evidence']['evidence']): e['review']['decision_ref'] = builder.ref(c['root'], path, '/decisions/' + str(i))
            self.assertIn('INVALID_EVIDENCE_ACCEPTANCE', {e['code'] for e in validate(c)})

    def test_binary_official_evidence_uses_bytes_and_page_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory)); path = 'fixtures/synthetic-official.pdf'
            (c['root'] / path).write_bytes(b'%PDF-SYNTHETIC-TEST-ONLY\x00\xff')
            source = builder.ref(c['root'], path)
            c['evidence']['authorities'][0]['identity'] = source
            e = c['evidence']['evidence'][0]; e.update(source_ref=source, page_or_section='synthetic page 1')
            refresh(c); self.assertEqual([], validate(c))

    def test_field_cannot_claim_reference_purpose_while_application_scoped(self):
        # Even a refreshed dossier cannot grant reference purpose to an app Field.
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory)); d = c['promotions']['dossiers'][0]
            d['purpose'] = 'CONTRACT_REFERENCE'; d['fact_kind'] = 'REFERENCE_CONTRACT'
            refresh(c)
            errors = validate_promotion(c['policy'], c['evidence'], c['promotions'], [(c['field'], 'CONTRACT_REFERENCE')],
                                        c['root'], c['gates'], c['mapping'])
            self.assertIn('PROMOTION_SCOPE_MISMATCH', {e['code'] for e in errors})

    def test_product_specific_owner_and_source_must_resolve(self):
        for key in ['owner', 'source', 'review_condition']:
            with self.subTest(key=key), tempfile.TemporaryDirectory() as directory:
                c = make_case(Path(directory), 'PRODUCT_SPECIFIC')
                c['promotions']['dossiers'][0]['product_specific'][key] = 'UNKNOWN'; refresh(c)
                self.assertIn('PRODUCT_SPECIFIC_PROMOTION_GOVERNANCE', {e['code'] for e in validate(c)})

    def test_accepted_evidence_cannot_have_unknown_document_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            c = make_case(Path(directory)); c['evidence']['evidence'][0]['document_version'] = 'UNKNOWN'; refresh(c)
            self.assertIn('INVALID_EVIDENCE_ACCEPTANCE', {e['code'] for e in validate(c)})
