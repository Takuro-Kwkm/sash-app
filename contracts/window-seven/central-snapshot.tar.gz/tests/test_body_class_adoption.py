import copy,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
import body_class_adoption as a
import contracts

class BodyClassAdoption(unittest.TestCase):
    def test_exact_normative_adoption(self):self.assertEqual([],a.validate(ROOT))
    def bundle(self):
        b=contracts.load_bundle(ROOT);d=a.load(ROOT)
        for binding in d['bindings']:
            for i,f in enumerate(b['fields']):
                if f['field_id']==binding['field_id']:b['fields'][i]=copy.deepcopy(binding['adopted_provisional_contract'])
            row=next(m for m in b['mapping']['fields'] if m['field_id']==binding['field_id'])
            for key in ['app','product','category','runtime_key','canonical_key','canonical_target','semantic_role','mapping_type']:row[key]=binding[key]
        return b
    def test_exact_rebinding_passes(self):
        b=self.bundle();self.assertEqual([],contracts.validate_mapping(b));self.assertEqual([],contracts.validate_selection_contract(b))
    def test_old_audit_stays_accepted(self):self.assertEqual([],contracts.validate_mapping(contracts.load_bundle(ROOT)))
    def test_completed_capacity_cannot_replace_body_class(self):
        b=self.bundle();row=next(m for m in b['mapping']['fields'] if m['field_id']=='exterior-estimator:nesca:vehicle_capacity');row['canonical_key']='vehicle_capacity';self.assertFalse(a.mapping_is_adopted(b,row));self.assertTrue(contracts.validate_mapping(b))
    def test_unrelated_semantic_change_rejected(self):
        b=self.bundle();row=b['mapping']['fields'][0];row['canonical_key']='body_class';self.assertFalse(a.mapping_is_adopted(b,row));self.assertTrue(contracts.validate_mapping(b))
    def test_field_mutation_breaks_adoption(self):
        b=self.bundle();row=next(m for m in b['mapping']['fields'] if m['field_id']=='exterior-estimator:fugo:vehicle_capacity');next(f for f in b['fields'] if f['field_id']==row['field_id'])['default']['policy']='GUESSED';self.assertFalse(a.mapping_is_adopted(b,row))

if __name__=='__main__':unittest.main()
