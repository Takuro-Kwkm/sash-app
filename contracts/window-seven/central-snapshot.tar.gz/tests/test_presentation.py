import copy
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from jsonschema import Draft202012Validator
from contracts import ROOT, load_bundle, validate_bundle, validate_presentation, validate_selection_contract
from presentation import validate_policy, resolve_presentation, presentation_schema

BASE = load_bundle()
FIXTURE = BASE['presentation_fixtures'][0]
POLICY = FIXTURE['contract']['presentation_resolution']
CASES = json.loads((ROOT / 'fixtures/presentation-negative.v0.1.json').read_text())['cases']
READY = {'candidate_count': 2, 'applicable': True, 'resolution_status': 'READY'}

class NegativeValidation(unittest.TestCase):
    pass

for case in CASES:
    def reject(self, case=case):
        self.assertIn(case['expected_error'], {e['code'] for e in validate_policy(case['policy'])})
        with self.assertRaises(ValueError):
            resolve_presentation(case['policy'], READY)
    setattr(NegativeValidation, 'test_' + case['fixture_id'].replace('-', '_'), reject)

class PresentationResolution(unittest.TestCase):
    def test_gap_fixture_all_cases_keep_semantic_identity(self):
        field = FIXTURE['contract']
        before = copy.deepcopy(field)
        for case in FIXTURE['cases']:
            resolved = resolve_presentation(POLICY, case['context'], field['semantic_role'])
            self.assertEqual(field['semantic_role'], resolved['semantic_role'])
            self.assertEqual(case['expected'], {k: resolved[k] for k in ['state', 'control_type']})
        self.assertEqual(before, field)

    def test_multi_select_and_single_summary(self):
        for count, expected in [(1, 'SUMMARY'), (2, 'SELECT'), (2000, 'SELECT')]:
            self.assertEqual(expected, resolve_presentation(POLICY, dict(READY, candidate_count=count))['control_type'])

    def test_zero_is_empty_without_choice_control(self):
        result = resolve_presentation(POLICY, dict(READY, candidate_count=0))
        self.assertEqual(('EMPTY', None), (result['state'], result['control_type']))

    def test_default_only_fixed_is_valid(self):
        policy = {k: copy.deepcopy(v) for k, v in POLICY.items() if k != 'rules'}
        policy['default'] = {'state': 'FIXED', 'control_type': 'READONLY'}
        self.assertEqual([], validate_policy(policy))
        self.assertEqual('READONLY', resolve_presentation(policy, READY)['control_type'])

    def test_default_only_free_entry_needs_no_choice(self):
        policy = {k: copy.deepcopy(v) for k, v in POLICY.items() if k != 'rules'}
        policy['default'] = {'state': 'SELECTABLE', 'control_type': 'TEXT'}
        self.assertEqual('TEXT', resolve_presentation(policy, dict(READY, candidate_count=0))['control_type'])

    def test_override_precedes_conditional_rule(self):
        policy = copy.deepcopy(POLICY)
        policy['overrides'] = [{'rule_id': 'reviewed-override', 'when': {'candidate_count': {'min': 1, 'max': 1}, 'applicable': True},
                                'result': {'state': 'FIXED', 'control_type': 'READONLY'}}]
        resolved = resolve_presentation(policy, dict(READY, candidate_count=1))
        self.assertEqual('READONLY', resolved['control_type'])
        self.assertEqual('overrides:reviewed-override', resolved['resolved_by'])

    def test_conditional_rule_precedes_default(self):
        self.assertEqual('rules:single-candidate', resolve_presentation(POLICY, dict(READY, candidate_count=1))['resolved_by'])

    def test_default_precedes_fallback(self):
        policy = copy.deepcopy(POLICY)
        policy['fallback'] = {'state': 'ERROR', 'control_type': None}
        self.assertEqual('default', resolve_presentation(policy, READY)['resolved_by'])

    def test_valid_fallback_when_default_absent(self):
        policy = copy.deepcopy(POLICY)
        policy['fallback'] = policy.pop('default')
        self.assertEqual('fallback', resolve_presentation(policy, READY)['resolved_by'])

    def test_rules_partition_unbounded_domain_without_default(self):
        policy = copy.deepcopy(POLICY)
        policy['rules'].append({'rule_id':'multiple', 'when':{'candidate_count':{'min':2,'max':None}}, 'result':policy.pop('default')})
        self.assertEqual([], validate_policy(policy))
        self.assertEqual('SELECT', resolve_presentation(policy, dict(READY, candidate_count=10**100))['control_type'])

    def test_applicability_guard_precedes_override(self):
        result = resolve_presentation(POLICY, dict(READY, applicable=False))
        self.assertEqual('APPLICABILITY_GUARD', result['resolved_by'])
        self.assertEqual(('NOT_APPLICABLE', None), (result['state'], result['control_type']))

    def test_status_guard_separates_error_empty_confirmation(self):
        for status, state in [('EMPTY','EMPTY'),('BLOCKED','ERROR'),('ERROR','ERROR'),('CONFIRMATION_REQUIRED','MANUAL_CONFIRMATION')]:
            result = resolve_presentation(POLICY, dict(READY, resolution_status=status))
            self.assertEqual((state,None), (result['state'],result['control_type']))

    def test_conflict_is_not_hidden_by_fallback_or_guard(self):
        policy = copy.deepcopy(next(c['policy'] for c in CASES if c['fixture_id']=='conflicting-rules'))
        policy['fallback'] = {'state':'EMPTY','control_type':None}
        with self.assertRaisesRegex(ValueError, 'PRESENTATION_RULE_CONFLICT'):
            resolve_presentation(policy, dict(READY, applicable=False))

    def test_context_type_and_unknown_keys_are_rejected(self):
        for context in [dict(READY,candidate_count=-1), dict(READY,candidate_count=True), dict(READY,product='invented'), dict(READY,resolution_status='MYSTERY')]:
            with self.assertRaisesRegex(ValueError,'INVALID_PRESENTATION_CONTEXT'):
                resolve_presentation(POLICY,context)

    def test_policy_and_context_are_read_only(self):
        policy, context = copy.deepcopy(POLICY), copy.deepcopy(READY)
        before = copy.deepcopy((policy,context))
        resolved=resolve_presentation(policy,context)
        resolved['control_type']='tamper'
        self.assertEqual(before,(policy,context))

    def test_role_reassignment_is_rejected(self):
        with self.assertRaisesRegex(ValueError,'PRESENTATION_SEMANTIC_MISMATCH'):
            resolve_presentation(POLICY,READY,'invented:role')

    def test_category_permission_alone_does_not_create_field_rule(self):
        policy=copy.deepcopy(POLICY)
        policy['rules']=policy['rules'][:1]
        self.assertEqual('SELECT',resolve_presentation(policy,dict(READY,candidate_count=1),allowed_controls=['SELECT','SUMMARY'])['control_type'])

    def test_category_forbidden_control_is_rejected(self):
        with self.assertRaisesRegex(ValueError,'PRESENTATION_CATEGORY_CONTROL'):
            resolve_presentation(POLICY,READY,allowed_controls=['SELECT'])

    def test_field_default_cannot_rewrite_primary_audit(self):
        bundle=copy.deepcopy(BASE)
        bundle['presentation_fixtures'][0]['contract']['presentation_resolution']['default']['control_type']='RADIO'
        self.assertIn('PRESENTATION_DEFAULT_CONTROL',{e['code'] for e in validate_presentation(bundle)})

    def test_unregistered_presentation_authority_is_rejected(self):
        bundle=copy.deepcopy(BASE)
        bundle['presentation_fixtures'][0]['contract']['presentation_resolution']['authority']=['invented']
        self.assertIn('UNKNOWN_PRESENTATION_AUTHORITY',{e['code'] for e in validate_presentation(bundle)})

    def test_integrated_schema_and_validators_accept_gap_fixture(self):
        self.assertTrue(Draft202012Validator(json.loads((ROOT/'schemas/selection-contract.schema.json').read_text())).is_valid(FIXTURE['contract']))
        self.assertEqual('PASS',validate_bundle(BASE)['status'])
        self.assertEqual([],validate_selection_contract(BASE))

    def test_old_492_contracts_remain_unmodified_and_provisional(self):
        self.assertEqual(492,len(BASE['fields']))
        self.assertTrue(all('presentation_resolution' not in f and f['status']=='PROVISIONAL' for f in BASE['fields']))
        self.assertEqual(5,len(BASE['references']))

    def test_generic_solver_reuses_other_semantic_identities(self):
        for role,control in [('window:generic','RADIO'),('indoor:generic','CARD_SELECT'),('inner:generic','MULTI_SELECT')]:
            policy=copy.deepcopy(POLICY);policy['semantic_role']=role;policy['default']['control_type']=control
            resolved=resolve_presentation(policy,READY,role)
            self.assertEqual((role,control),(resolved['semantic_role'],resolved['control_type']))

    def test_standalone_and_embedded_policy_schema_agree(self):
        field_schema=json.loads((ROOT/'schemas/selection-contract.schema.json').read_text())
        standalone=json.loads((ROOT/'schemas/presentation-resolution.schema.json').read_text())
        standalone.pop('$id');standalone.pop('$schema')
        self.assertEqual(presentation_schema(),standalone)
        self.assertEqual(standalone,field_schema['properties']['presentation_resolution'])

    def test_conditional_select_still_requires_global_placeholder(self):
        bundle=copy.deepcopy(BASE)
        field=next(f for f in bundle['fields'] if f['control_type']=='RADIO' and f['canonical_key']=='product_type')
        policy=copy.deepcopy(POLICY);policy['semantic_role']=field['semantic_role']
        policy['default']['control_type']='RADIO'
        policy['rules'][1]['result']={'state':'SELECTABLE','control_type':'RADIO'}
        policy['rules'].append({'rule_id':'conditional-select','when':{'candidate_count':{'min':2,'max':None}},
                                'result':{'state':'SELECTABLE','control_type':'SELECT'}})
        field['presentation_resolution']=policy
        self.assertIn('PRESENTATION_SELECT_PLACEHOLDER',{e['code'] for e in validate_presentation(bundle)})

if __name__=='__main__':
    unittest.main()
