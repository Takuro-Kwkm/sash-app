import copy,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
import carport_authority as c
from contracts import load_bundle
class CarportAuthority(unittest.TestCase):
 def setUp(self):self.data=c.load(ROOT);self.fields=load_bundle(ROOT)['fields']
 def codes(self,d):return {x['code'] for x in c.validate(ROOT,d,self.fields)}
 def test_current_authority_and_shared_bindings(self):
  self.assertEqual([],c.validate(ROOT,self.data,self.fields));self.assertEqual(39,len(self.data['responsibility']['bindings']));self.assertEqual(15,len(self.data['responsibility']['rules']))
 def test_wrong_owner(self):
  self.data['responsibility']['bindings'][0]['owner']='MANUFACTURER';self.assertIn('WRONG_RESPONSIBILITY_OWNER',self.codes(self.data))
 def test_wrong_product(self):
  self.data['responsibility']['bindings'][0]['product']='other';self.assertIn('RESPONSIBILITY_SCOPE',self.codes(self.data))
 def test_incomplete_derivation(self):
  del self.data['derivation']['rules'][0]['reinforcement_rules'];self.assertIn('INCOMPLETE_DERIVATION',self.codes(self.data))
 def test_runtime_derivation_authority(self):
  self.data['derivation']['rules'][0]['source_authority']='Runtime resolver';self.assertIn('RUNTIME_AS_AUTHORITY',self.codes(self.data))
 def test_ui_authority(self):
  self.data['responsibility']['source_authorities'][0]['path']='src/ui.tsx';self.assertIn('CARPORT_AUTHORITY_SOURCE',self.codes(self.data))
 def test_stale_source_bytes(self):
  self.data['responsibility']['source_authorities'][0]['sha256']='0'*64;self.assertIn('CARPORT_AUTHORITY_SOURCE',self.codes(self.data))
 def test_body_class_not_capacity(self):
  self.data['semantic']['rules'][0]['identity']='IDENTITY';self.assertIn('BODY_CAPACITY_FALSE_EQUIVALENCE',self.codes(self.data))
 def test_alias_only(self):
  self.data['semantic']['rules'][0]['prohibited_mapping'].remove('alias_only');self.assertIn('SEMANTIC_ALIAS_ONLY',self.codes(self.data))
 def test_central_bypass(self):
  self.data['manifest']['adoption']='EXTERIOR_ONLY_JSON';self.assertIn('CENTRAL_AUTHORITY_BYPASS',self.codes(self.data))
 def test_no_runtime_self_certification(self):
  self.data['derivation']['rules'][0]['current_runtime_certification']=True;self.assertIn('INCOMPLETE_DERIVATION',self.codes(self.data))
 def test_shared_rule_duplication_rejected(self):
  self.data['responsibility']['rules'].append(copy.deepcopy(self.data['responsibility']['rules'][0]));self.assertIn('DUPLICATE_RESPONSIBILITY',self.codes(self.data))
 def test_manufacturer_fact_not_created_by_contract(self):
  self.assertTrue(all(r['lifecycle_scope']=='DERIVATION_RESPONSIBILITY_ONLY; THIS_CONTRACT_SUPPLIES_NO_NEW_MANUFACTURER_NUMERIC_FACT' for r in self.data['derivation']['rules']))
if __name__=='__main__':unittest.main()
