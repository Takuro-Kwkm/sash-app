import copy
import datetime as dt
import importlib.util
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from jsonschema import Draft202012Validator
from contracts import *

BASE=load_bundle()
CASES=read(ROOT,'fixtures/negative-cases.v0.1.json')['cases']

def apply_mutation(b, mutation):
    tokens=[x.replace('~1','/').replace('~0','~') for x in mutation['path'].lstrip('/').split('/')]
    obj=b
    for token in tokens[:-1]: obj=obj[int(token)] if isinstance(obj,list) else obj[token]
    token=int(tokens[-1]) if isinstance(obj,list) else tokens[-1]
    if mutation['op']=='delete': del obj[token]
    elif mutation['op']=='append': obj[token].append(copy.deepcopy(mutation['value']))
    else: obj[token]=copy.deepcopy(mutation['value'])

class PositiveValidation(unittest.TestCase): pass
for name,fn in VALIDATORS.items():
    def positive(self,fn=fn): self.assertEqual([],fn(BASE))
    setattr(PositiveValidation,'test_'+name.replace('-','_'),positive)

class NegativeValidation(unittest.TestCase): pass
for case in CASES:
    def negative(self,case=case):
        b=copy.deepcopy(BASE)
        for mutation in case['mutations']: apply_mutation(b,mutation)
        errors=VALIDATORS[case['validator']](b)
        self.assertIn(case['expected_error'],{e['code'] for e in errors},case['fixture_id']+': '+str(errors[:3]))
    setattr(NegativeValidation,'test_'+case['fixture_id'].replace('-','_'),negative)

class BehavioralContracts(unittest.TestCase):
    def test_valid_downstream_kept(self):
        self.assertEqual({'action':'KEEP_VALID','value':'E'},select_reset('E',['D','E']))
    def test_invalid_downstream_cleared(self):
        self.assertEqual({'action':'CLEAR_RESELECT','value':None},select_reset('E',['D']))
    def test_non_applicable_hidden_and_excluded(self):
        self.assertEqual({'action':'HIDE_AND_EXCLUDE','value':None},select_reset('E',['E'],False))
    def test_vrail_current_difference_does_not_change_global(self):
        evidence=read(ROOT,'authority/audit/evidence/vrail-reset-observation.json')
        self.assertIn('E',json.dumps(evidence))
        self.assertEqual('E',select_reset('E',['D','E'])['value'])
        ex=next(e for e in BASE['exceptions']['exceptions'] if e['exception_id']=='EX-VRAIL-DESIGN-GLASS')
        self.assertEqual('TEMPORARY_EXCEPTION',ex['status'])
    def test_output_destination_and_applicability(self):
        rows=[{'field_id':'color','applicable':True,'visible':True,'destinations':['estimate']},
              {'field_id':'old-glass','applicable':False,'visible':True,'destinations':['estimate']},
              {'field_id':'survey','applicable':True,'visible':True,'destinations':['survey']},
              {'field_id':'hidden','applicable':True,'visible':False,'destinations':['estimate']}]
        self.assertEqual(['color'],[r['field_id'] for r in business_output(rows,'estimate')])
        self.assertEqual(3,len(check_output_rows(rows,'estimate')))
    def test_reload_identity_preserved(self):
        identity={'product':'EW','runtime_sha':'a'*64,'contract_sha':'b'*40}
        selection={'window_type':'WT-EW-TATE-SUBERI','glass_type':'G1'}
        snapshot={'identity':identity,'selection':selection}
        restored=reload_selection(snapshot,identity)
        self.assertEqual(selection,restored);self.assertIsNot(selection,restored)
    def test_reload_wrong_identity_rejected(self):
        with self.assertRaisesRegex(ValueError,'RELOAD_IDENTITY_MISMATCH'):
            reload_selection({'identity':{'product':'EW'},'selection':{}},{'product':'TW'})
    def test_manifest_first_ignores_old_cache_hint(self):
        current=resolve_authority(BASE['manifest'],BASE['authority']['authorities'],'sash_ui_standard','UI_SPEC_v1.8.json')
        self.assertEqual('Sash UI Standard CURRENT v2.1',current['title'])
    def test_ordinary_placeholder_does_not_change_error_message(self):
        rule=next(r for r in BASE['ui']['rules'] if r['rule_id']=='UI-SELECT-PLACEHOLDER')
        self.assertIn('ERROR',rule['placeholder_contract']['excluded_roles'])
        f=copy.deepcopy(BASE['references'][0]);f['error_state']['policy']='CATEGORY_APP_ERROR_AUTHORITY'
        schema=read(ROOT,'schemas/selection-contract.schema.json')
        self.assertTrue(Draft202012Validator(schema).is_valid(f))
    def test_official_code_label_requires_evidence(self):
        o={'kind':'INTERNAL_VALUE','value':'LGA','label':'LGA','official_label':True,'authority':'OFFICIAL'}
        self.assertEqual([],check_option_labels([o],{'OFFICIAL'}))
        self.assertTrue(check_option_labels([o],set()))
    def test_raw_internal_option_exposure_rejected(self):
        self.assertTrue(check_option_labels([{'kind':'INTERNAL_VALUE','value':'snow_20','label':'snow_20'}],set()))
    def test_temporary_exception_expiry_boundary(self):
        e=next(e for e in BASE['exceptions']['exceptions'] if e['status']=='TEMPORARY_EXCEPTION')
        date=dt.date.fromisoformat(e['expiry_or_review_condition']['review_by'])
        self.assertEqual([],validate_exceptions(BASE,date-dt.timedelta(days=1)))
        self.assertIn('EXPIRED_TEMPORARY_EXCEPTION',{x['code'] for x in validate_exceptions(BASE,date)})
    def test_reciprocal_audit_metadata_quarantined_with_identity(self):
        pending=BASE['dependencies']['pending_edges']
        self.assertEqual(2,sum('DECLARED_PARENT_CYCLE' in p['reason'] for p in pending))
        self.assertEqual(727,len(pending)+len(BASE['dependencies']['edges']))
    def test_d001_exact_four_module_ninety_field_omission_rejected(self):
        omitted={'SER-LIX-SAMOS2H','SER-LIX-SAMOSL','SER-YKK-APW430','SER-YKK-APW431'}
        b=copy.deepcopy(BASE)
        self.assertEqual(90,sum(m['product'] in omitted for m in b['mapping']['fields']))
        b['mapping']['fields']=[m for m in b['mapping']['fields'] if m['product'] not in omitted]
        b['mapping']['field_count']=491
        b['coverage']['expected_field_count']=491
        b['coverage']['registered_universe']=[m for m in b['coverage']['registered_universe'] if m['product'] not in omitted]
        for k in ['resolver_universe','inventory_universe']:
            b['coverage'][k]=[m for m in b['coverage'][k] if m.split(':')[1] not in omitted]
        self.assertIn('REGISTERED_UNIVERSE_OMISSION',{e['code'] for e in validate_coverage(b)})
    def test_legacy_unknown_and_mapped_are_distinct(self):
        rows=BASE['mapping']['fields']
        self.assertEqual(75,sum(m['canonical_key']=='UNKNOWN' for m in rows))
        self.assertEqual(85,sum(m['product'] in LEGACY_PRODUCTS for m in rows))
        self.assertEqual(10,sum(m['product'] in LEGACY_PRODUCTS and m['canonical_key']!='UNKNOWN' for m in rows))
    def test_inner_window_final_dimension_remains_separate(self):
        inner=next(c for c in BASE['flows'] if c['category_id']=='interior_window')
        self.assertIn('SIZE',inner['semantic_stages']);self.assertIn('INNER_WINDOW_FINAL_DIMENSION',inner['groups'])
        self.assertGreater(inner['groups'].index('INNER_WINDOW_FINAL_DIMENSION'),inner['groups'].index('OPTION'))
    def test_all_five_formal_reference_contracts(self):
        self.assertEqual(FORMAL_CATEGORIES,{f['category'] for f in BASE['references']})
        self.assertTrue(all(f['status']=='FORMAL' for f in BASE['references']))
    def test_unknown_draft_is_schema_valid(self):
        f=copy.deepcopy(BASE['references'][0]);f['status']='DRAFT';f['semantic_role']='UNKNOWN';f['default']['policy']='UNKNOWN'
        self.assertTrue(Draft202012Validator(read(ROOT,'schemas/selection-contract.schema.json')).is_valid(f))
    def test_unknown_formal_is_schema_invalid(self):
        f=copy.deepcopy(BASE['references'][0]);f['semantic_role']='UNKNOWN'
        self.assertFalse(Draft202012Validator(read(ROOT,'schemas/selection-contract.schema.json')).is_valid(f))
    def test_snapshot_requires_commit_and_hash(self):
        schema=Draft202012Validator(read(ROOT,'schemas/snapshot.schema.json'))
        good={'repository':'Takuro-Kwkm/product-ui-contracts','revision':'a'*40,'ui_standard':'0.1','category_flow':'carport@0.1','content_sha256':'b'*64}
        self.assertTrue(schema.is_valid(good))
        for v in ['latest','main','HEAD','0.1']:
            bad=dict(good,revision=v);self.assertFalse(schema.is_valid(bad))
    def test_invalid_json_schema_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);shutil.copytree(ROOT/'schemas',root/'schemas')
            p=root/'schemas/ui-standard.schema.json';p.write_text('{"type":"invented-type"}')
            b=dict(BASE,root=str(root));self.assertIn('INVALID_SCHEMA',{x['code'] for x in validate_schema(b)})

if __name__=='__main__': unittest.main()
