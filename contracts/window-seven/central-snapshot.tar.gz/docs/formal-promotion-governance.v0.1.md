# Field Formal Promotion Governance v0.1

Foundation package: 0.3.0 PR candidate. Central base authority:
`Takuro-Kwkm/product-ui-contracts@3d4aa126293905b3c7fa9294535007c594626e7a`.
This adds a shared governance layer for Exterior, Sash, Interior and future apps.
It changes no existing Field ID, role, mapping, product fact, Presentation or Flow.

## Authority and records

| Artifact | Responsibility |
|---|---|
| `registries/formal-promotion/governance.v0.1.json` | State machine, evidence strength, mapping requirements and existing validator Gate IDs |
| `schemas/evidence-acceptance.schema.json` | Source/reviewer authorities, typed source identity and scoped evidence |
| `authority/field-evidence-acceptance.v0.1.json` | Independently registered source/review authority and evidence records |
| `schemas/formal-promotion.schema.json` | Field dossier, status-only transition, approval and blocker records |
| `authority/field-promotion-approvals.v0.1.json` | Content-bound approval and dossier registry |
| `scripts/formal_promotion.py` | Offline acceptance and lifecycle validation |
| `scripts/contracts.py` | Snapshot integration; invokes existing schema/mapping/semantic/category/dependency/exception gates |

Source authority is registered independently of the Field/dossier. Its allowed source
classes and purposes, CURRENT state, cached file, SHA256 and JSON Pointer must match
the evidence. Evidence includes source identifier, document version, page/section,
captured date, verification state, status, affected Field/category/purpose and claims.
The cached locator is the stable reference; document section/page is retained even
when whole-file bytes are cached. No live official website or floating main is read
by CI. Evidence hashes identify cached bytes, not an unverified original workbook.

ACCEPTED requires VERIFIED and an APPROVED decision from an independently registered
CURRENT review authority for the same purpose. The decision pointer must resolve
inside the registered review document and approve the exact evidence payload.
INSUFFICIENT, CONFLICTING and UNVERIFIED can be recorded without pretending acceptance.
Future dates, missing files, stale hashes/pointers, duplicate IDs, unknown classes and
unregistered/retired/mismatched authorities fail with an error code and affected path.

Review records are auditable attestations admitted through repository review. CI
verifies their identity, scope, decision and content binding; it does not authenticate
a human reviewer cryptographically, judge catalog truth, or replace protected-branch
review permissions. Adding a reviewer/source authority is an explicit reviewed
authority change, not a Field-local switch. Approval records cannot be generated as
real application authorization from Runtime observations or AI inference alone.

## Evidence strength and claim acceptance

| Claim | Accepted source strength |
|---|---|
| Product fact | Official primary/catalog/order/technical/specification/Web source, verified Formal Product Master, human-reviewed official evidence |
| Semantic identity / mapping / equivalence / product-specific identity | Above authoritative sources, audited mapping, Contract Authority or Formal Registry; no Runtime-only meaning assertion |
| Business input responsibility / derivation authority | Authoritative sources, Contract Authority or Formal Registry |
| Runtime/Flow parity | VERIFIED_RUNTIME_BEHAVIOR; cached report has this Field ID, status-independent Contract identity hash, runtime_parity PASS and flow_parity PASS |
| Presentation / dependency / rule conformity / exception review | Scoped ACCEPTED evidence plus the existing central validators; evidence alone never overrides a failing Gate |

FORMAL_PRODUCT_MASTER and FORMAL_REGISTRY classify already verified source scope;
their names do not promote an unverified legacy artifact. Source verification and
reviewed acceptance are still required. Manufacturer Product Fact evidence and
business responsibility evidence are different claims. Business inputs and derived
Fields need their own accepted responsibility/derivation authority, rather than
invented manufacturer facts. The approved dossier binds this fact_kind decision.

## Promotion approval

Every FORMAL Field must have exactly one matching dossier and independent APPROVED
approval. The approval binds Field/category/purpose, the canonical JSON SHA256 of the
target Contract, the entire dossier, and the ordered selected evidence records. A
change to status, semantic identity, source bytes, classification, evidence or rationale
requires renewed acceptance/approval as applicable. A Field's `status: FORMAL` alone
is rejected. Orphan dossiers/approvals and duplicate IDs are rejected.

| Classification | Additional evidence requirement |
|---|---|
| EXACT | Validated one-to-one mapping and accepted MAPPING claim; exact spelling does not waive product evidence |
| SEMANTIC | Accepted MEANING_EQUIVALENCE claim plus reviewed mapping rationale |
| PRODUCT_SPECIFIC | Accepted PRODUCT_SPECIFIC_IDENTITY, reason, why Global role is insufficient, owner/source, REVIEWED status and review condition |

All classes require accepted semantic identity, mapping, Presentation, dependency,
rule conformity and exception review. Product Fact Fields require accepted strong
Product Fact evidence. Application Fields require Runtime and Flow parity evidence.
All 12 preexisting Validator Gates must PASS: schema, mapping, selection-contract,
ui-standard, category-flow, dependency, reset, exceptions, authority, coverage, output
and presentation-resolution. They remain the existing Authority, not copied new rules.

Any registered CONFLICTING evidence for the affected Field/purpose blocks promotion,
even if omitted from selected evidence_ids. An OPEN promotion blocker or scoped pending/
legacy exception also blocks FORMAL. Valid scoped formal/temporary exceptions remain
subject to existing registry and expiry checks; no fabricated expiry is introduced.

## Lifecycle and compatibility

Only approved `PROVISIONAL → FORMAL` and `FORMAL → PROVISIONAL` transitions are modeled.
Both bind the prior Contract/hash/state and a reason. Only status may change. Contract
semantics or options need a separate adoption Work. An approved demotion may retain
insufficient evidence and uses ordinary PROVISIONAL validation; it does not invent a
third Field status. Evidence loss/conflict invalidates a remaining FORMAL declaration
until an approved reevaluation/demotion is recorded. CI never edits status automatically.

PROVISIONAL Fields without a promotion dossier need no FORMAL-only evidence. Mixed
Field status in one product is supported. Selection and Presentation schemas/bytes
remain unchanged. New package 0.3.0 tightens FORMAL validator acceptance (BREAKING in
0.x), while all existing current Contracts remain valid. Fixed older snapshot consumers
continue using their old bytes and validator until explicit adoption.

The five existing FORMAL examples are `REFERENCE_CONTRACT_NOT_INSTALLED`. Their separate REFERENCE_CERTIFICATION operation retains FORMAL→FORMAL for an already
adopted reference, with unchanged prior/target Contract hashes; it is not an application
lifecycle transition or a fabricated historical PROVISIONAL state. Their new
certificates reproduce the already adopted normative handoff rules and fixed audit
mapping, with `CONTRACT_REFERENCE / REFERENCE_CONTRACT` purpose. They certify Schema
reference behavior only. They do not accept Product Facts, runtime parity or application
promotion. Reference decisions are explicitly labeled reference certification and
inherit the existing Human Review/audit scope; they are not invented manufacturer
evidence or new human approvals for application Fields. Trusted purpose comes from the
snapshot container (`references` versus application `fields`), not a Field-controlled
flag. Moving/relabeling a reference into application scope fails approval matching.

## Fixtures and CI

`fixtures/promotion-positive.v0.1.json` contains synthetic, isolated cached sources,
decisions, evidence and dossiers. A: PROVISIONAL valid; B: complete FORMAL valid;
C: same Field with insufficient evidence blocked; D: accepted evidence/approval added,
same Field eligible. These fictional official sources are never loaded as adoption
evidence. Thirty-two named negative fixtures are in `fixtures/promotion-negative.v0.1.json`;
each checks its expected error code. Additional tests cover real existing Gate failures,
invalid runtime proof, authority retirement, pending exception, mixed status and demotion.

Normal PR/push CI runs all validators and tests, preserves every old test identity,
regenerates original foundation/schemas/negative/Presentation fixtures plus governance
fixtures, then checks tracked authority/registry/mapping/fixture/schema byte diffs.
The central PR is a review candidate; app adoption must use its eventual merged SHA.

## Exterior boundary and next Work

PR #19's audit is preserved on Exterior main `6b6726b55d60f6e515f94d725b05b48b3785f4b2`.
FORMAL 0 / PROVISIONAL 101, EXACT 74 / SEMANTIC 13 / PRODUCT_SPECIFIC 14, split 31/36/34,
Mapping changes 0, original Adoption Gap 0. All four previous adoption/enforcement Gates
are carried forward. This central PR changes neither the adopted Snapshot nor the
Exterior audit guard, Field evidence decisions or existing Pilot status baseline.

The two central capability gaps are CLOSED at implementation/review-candidate scope.
Exterior's preserved historical 103 promotion gap records are not silently rewritten:
the audit's policy gap aggregates both central capabilities, while its second shared
gap includes consumer Pilot/baseline migration. Consumer status-guard migration and
101 Field evidence acceptance remain next Work after central merge and explicit fixed
Snapshot adoption. Production Identity UNVERIFIED is separate, not a promotion blocker.
