# Presentation Resolution Contract v0.1

Semantic Field Identity answers what the Field means. `presentation_resolution` answers how its current authoritative context may be presented. It is optional in Selection Contract v0.1. The standalone schema is `schemas/presentation-resolution.schema.json`; the identical definition is embedded in `schemas/selection-contract.schema.json`, with no network `$ref`.

`field_id`, `semantic_role`, `runtime_key`, `canonical_key`, scope and stored values stay stable. The nested `semantic_role` must equal the outer registered role. `control_type`, `allowed_control_types` and audit observations remain the immutable primary/audited presentation anchor. They retain their old validation for legacy and opt-in Fields. Only an explicit opt-in policy can authorize conditional results; Category allowance alone is insufficient. A declared default must use the anchored primary Control. Every non-null resolved Control also needs permission in the Category semantic role allowed set.

```json
{
  "version": "0.1",
  "semantic_role": "carport:5722b712c4e829b3",
  "authority": ["HUMAN-PRESENTATION-RESOLUTION", "AUDIT-e54db5710df861d62a27"],
  "default": {"state": "SELECTABLE", "control_type": "SELECT"},
  "rules": [
    {"rule_id": "zero", "when": {"candidate_count": {"min": 0, "max": 0}},
     "result": {"state": "EMPTY", "control_type": null}},
    {"rule_id": "single", "when": {"candidate_count": {"min": 1, "max": 1}},
     "result": {"state": "FIXED", "control_type": "SUMMARY"}}
  ]
}
```

This is an opt-in example, not a rule automatically applied to all Selects or categories. Product type, multi-select, input or container Fields can have different authoritative policies. A `FIXED` decision does not select a value: the application continues to use its existing Runtime-derived value.

| State | Control | Meaning |
|---|---|---|
| SELECTABLE | Existing choice or entry Control | User can enter/select |
| FIXED | SUMMARY / READONLY / READONLY_INPUT | Existing value is read only; no selection implied |
| CONTAINER | GROUP | Existing structural group, not a candidate selector |
| NOT_APPLICABLE | null | Hide and exclude Selection from business output |
| EMPTY | null | No ordinary choice control; empty-result responsibility stays separate |
| MANUAL_CONFIRMATION | null | Confirmation handoff; not an error or placeholder |
| ERROR | null | Error/blocked context; no invented selectable option |

No new renderer Control enum is introduced. State is separate from Control. `BLOCKED` is a context status resolving to ERROR; it does not add another presentation mode. Empty/error/confirmation copy and destination output remain App/Category responsibilities.

Context requires exactly `candidate_count` (nonnegative integer), `applicable` (boolean), `resolution_status` (READY / EMPTY / BLOCKED / CONFIRMATION_REQUIRED / ERROR). It must come from the actual state-dependent Resolver and business applicability. Do not count audit union values or infer applicability from labels. For noncandidate free-entry or structural Fields, 0 candidates is normal; the zero-choice restriction covers actual choice Controls, not TEXT/NUMBER/GROUP/read-only facts.

Resolution precedence is fixed:

1. Applicability guard: false → NOT_APPLICABLE/null.
2. Status guard: EMPTY → EMPTY; BLOCKED/ERROR → ERROR; CONFIRMATION_REQUIRED → MANUAL_CONFIRMATION, all null Control.
3. Matching explicit `overrides` rule.
4. Matching conditional `rules` rule.
5. Declared `default`.
6. Declared `fallback` when no default/matching rule exists.

Override and rule conditions accept only `candidate_count: {min, max}` and/or `applicable`. `max: null` means unbounded. Conditions in one `when` are AND. No JavaScript, arbitrary expression, product name, Field name or label predicate is permitted. Same-priority intervals may not overlap, even with identical results. Cross-priority overlap is intentional: override wins. Conflicts, malformed or illegal results are errors before resolution; fallback never hides them. Non-applicable predicates are unreachable behind the mandatory guard and are rejected. Explicit overrides cannot bypass applicability/error guards.

A default-only policy is valid for appropriate fixed/entry/container presentation. A default-only choice Select with the full nonnegative candidate domain is invalid unless its zero state is explicitly handled. Defaults are not automatically converted to SUMMARY. The whole definition must resolve the READY candidate domain, including the unbounded tail. Null-control fallback may represent EMPTY or confirmation, never fabricate Product facts.

`resolve_presentation(policy, context, semantic_role, allowed_controls)` returns semantic role, state, Control and `resolved_by`. It does not mutate either argument, execute app code, generate candidates, reset values, format labels, persist or render. Consumers keep dependency, KEEP_VALID/CLEAR_INVALID, output and persistence in their current authority. `scripts/presentation.py` is a normative reference resolver, not an application Flow engine migration.

Versioning: Selection Contract API v0.1 remains backwards-compatible; Presentation Resolution starts at v0.1, Foundation package becomes 0.2.0 for the new feature. A consumer must explicitly adopt a new commit-fixed Snapshot and Validator. Old validators reject the new optional property; no forward compatibility is claimed. No existing Field status is promoted.
