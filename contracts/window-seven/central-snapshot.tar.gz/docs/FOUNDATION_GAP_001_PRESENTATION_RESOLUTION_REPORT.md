# FOUNDATION_GAP-001 — Presentation Resolution Closure Candidate

Central base: `Takuro-Kwkm/product-ui-contracts@6e2836de3706719445d0526a619769bf086c7546`, actual main equality and source bytes verified. Branch: `feat/presentation-resolution-contract-v0.1`. Merge is not authorized. PR identity and final checks are recorded on the PR and final handoff after creation.

## Problem / Root Cause

Exterior Pilot covered 101 Fields (31 Nesca, 36 Fugo, 34 FIRST), all PROVISIONAL; Mapping EXACT 74 / SEMANTIC 13 / PRODUCT_SPECIFIC 14. Runtime/UI/Production changes were zero. One Field, Fugo roof_color, has normal SELECT and a single-candidate DERIVED_VISIBLE/SUMMARY state at FUGO-F + RF-FUGO-POLY-BLACK. The latter is not FIXED_VISIBLE identity; it is an existing automatic Runtime-derived presentation. The fixed Field allowed/observed set retained SELECT alone. Category SUMMARY permission did not supply explicit Field authorization.

The root cause is conflation of semantic identity with static presentation observation. Static observations correctly protect legacy behavior but cannot specify state-dependent presentation resolution. No Runtime defect was reproduced.

## Design / Schema Change

Add an optional `presentation_resolution` to Selection Schema v0.1 and a standalone Presentation Resolution v0.1 schema. Keep Field identity, runtime/canonical mapping, audited primary Control and Field status. State and Control are separate result properties. Known existing Controls are reused; no Fugo/Exterior-specific predicate, Schema or validator branch exists.

Mandatory applicability/status guard → override → conditional rule → default → fallback. Same-priority conflicts fail; fallback cannot hide them. Null Control states explicitly represent zero/empty/error/confirmation/non-applicable states. Text/number input and fixed facts are distinguished from candidate choice Controls. The read-only reference resolver returns a decision and never performs Product selection, Reset or App rendering.

## Validator Change / Fixture

Original eleven validators and current audited Control/set checks remain. A twelfth validator checks typed conditions/results, role consistency, Category permission, authority, intervals, conflicts, candidate-domain coverage and reproduction fixtures. New `foundation-gap-001.json` attaches opt-in policy to an exact copy of the central Fugo Field, keeps its primary SELECT and PROVISIONAL status, and validates seven abstract contexts (multiple/single/zero/non-applicable/confirmation/error/blocked). This is not a copy or execution of Exterior Runtime. The prior single-candidate witness is carried as evidence; no Product candidate union is adopted.

20 persisted negative definitions fail for unknown mode/condition, overlap/conflict, negative/fractional/boolean/inverted count, unbounded unresolved tail, malformed default/policy, illegal state/control, zero Select, hardcoded product/Field condition, duplicate ID and unreachable guard. Tests exercise real rejection, not only fixture counts.

## Regression / Backward Compatibility

Local full validation: 12/12 PASS, error 0. Tests: 156/156 PASS, skip 0. Every one of the original 110 passing Test IDs is preserved. Original negatives: 78/78; added negative fixtures: 20/20 expected rejection. Added tests: 46 (one validator positive plus 45 presentation tests). Gap fixture: 7/7 context decisions PASS. Reproduction output and per-test evidence accompany this change.

Existing 492 baseline Fields and five Formal reference contracts remain byte-identical; no baseline opt-in or promotion. 291 roles, 581 mappings, 6 exceptions and 14 Global Rules stay unchanged. Selection Schema v0.1 required keys and old validation remain; only an optional property is added. Foundation package 0.2.0 follows the existing MINOR feature policy; the new primitive is version 0.1. Old fixed snapshots remain immutable. Older Validators reject the new property, so opt-in requires a new explicit Snapshot/Validator; forward compatibility is not claimed.

## Remaining Risks

This is a Foundation Closure candidate until this PR is reviewed and merged. A passing abstract fixture does not make Exterior Pilot PASS. Candidate count, applicability and status must come from Current Resolver state; using audit union or guesses could produce an incorrect presentation. Noncandidate/zero-state mapping and destination-specific visibility must be checked in the App adapter. Product predicates and complete manufacturer constraint models stay outside this reference model. Production identity remains UNVERIFIED and blocks future mandatory enforcement, not this Foundation change alone.

## Exterior Pilot Handoff

1. After authorized Merge, fetch the actual merged central SHA. Record both the old fixed SHA and newly explicitly adopted SHA; do not silently read latest/main or mutate old Snapshot bytes.
2. Reuse the previous app Pilot code, 101 contracts, full mapping, tests and evidence. Re-fetch current Exterior main and resolve current manifest first; report any base drift instead of treating old `6f321e…` as current indefinitely.
3. Add the reviewed optional policy to the Fugo roof_color App Selection Contract. Copy the new central model/Schema/Validator via a new complete fixed Snapshot, including `scripts/presentation.py`. When the App loads the extracted central validator dynamically, resolve its imports from the verified local extracted `scripts` directory, never the network or App-edited copies. Keep role `carport:5722b712c4e829b3`, canonical/runtime key roof_color, original SELECT anchor, PROVISIONAL status and stored values. No Runtime/UI change is needed. No broad allowed_control_types widening or invented Exception waiver is needed.
4. Update App read-only adapter and mapping layer to resolve Presentation from actual per-state count/applicability/status and compare the actual visible presentation plus behavior. Keep the primary audited Control separately. Category allowed set is only a bound, never the runtime decision. For non-applicable/error/confirmation states, compare the abstract state and actual UI visibility/handoff responsibilities; a null resolved Control is not a request to change Runtime metadata. Preserve product_type and other existing per-Field behavior; do not add the example policy universally.
5. The old App verifier requires every app Field to equal the old pinned record. Keep that integrity check for all baseline properties; allow only explicit presentation opt-in bound to the newly adopted model/authority. Verify opt-in records through the new central validator and Category permission. Do not weaken the old identity/schema/reset/output/coverage checks or overwrite pinned audit observations.
6. Rerun snapshot/Schema/Mapping/identity coverage, all central validators, existing app tests, all 39 Pilot tests plus new resolution/parity tests. Refresh actual representative Runtime state validation; reuse prior mapping/fixtures rather than repeat Product Master creation. Replace the old 'Gap must be detected' expectation with 'legacy definition still detects Gap; explicitly opted-in definition resolves the correct presentation' regression.
7. Recheck SELECT → single DERIVED_VISIBLE/SUMMARY, 0/hidden/confirmation states, exact Label/Value/Control, per-state options, dependency/reset effects, output and canonical save/reload identity. Keep current Production unchanged and the Production identity enforcement gate.
8. Mark FOUNDATION_GAP-001 closed for Pilot only when the adopted central authority, approved explicit policy and actual runtime parity all pass. Then rejudge `UI_CONTRACT_PILOT_READY`; create the Exterior PR under its authorized PASS condition. Never infer Pilot PASS from this Foundation PR.

Changes are confined to the central repository. Exterior/Sash/Interior Runtime/UI changes 0; Product Master/Pricing changes 0; Production Deploy 0; Merge 0. Common Renderer migration and Registry Enforcement remain separate Work.
