# Presentation validation

`python scripts/validate-presentation-resolution.py` or `python scripts/validate.py --only presentation-resolution` runs the new twelfth validator. Full validation keeps every original validator enabled. All central validation and presentation fixtures run in existing CI; no application CI/enforcement is installed.

Schema validation checks strict object shapes, known Controls/states, positive rule IDs, nonnegative integer intervals, typed context, and opt-in Field structure. Rule predicates cannot reference product/Field identifiers or arbitrary expressions. Semantic validation checks role equality, Category role permission, unchanged default primary Control and CURRENT authority references. Existing selection-contract validation still rejects changed audited Control/set and mapping/identity drift.

Conflict analysis compares every pair of intervals at the same priority. Applicability is a boolean dimension; disjoint values do not overlap. Inverted intervals, duplicate rule IDs and unreachable non-applicable rules fail. Coverage partitions the nonnegative unbounded integer domain at every interval min/max boundary, checks all resulting equivalence cells and the open-ended tail, and checks mandatory status/applicability guards in unit fixtures. This is complete for the permitted interval/boolean language; no general product predicate or manufacturer constraint coverage is claimed.

No rule/default/fallback → UNRESOLVED_PRESENTATION. Zero candidates returning a choice Control → ILLEGAL_ZERO_CANDIDATE_PRESENTATION. A contradictory result is not rescued by fallback. Error codes and persisted negative cases are in `fixtures/presentation-negative.v0.1.json`. The 20 fixtures are actually rejected through both validation and resolution. Validity of a Foundation fixture does not prove App runtime/UI parity.

Run:

```sh
python scripts/validate.py --report test-results/validation.json
python scripts/run-tests.py test-results/unit-tests.json
python scripts/verify-previous-tests.py test-results/unit-tests.json test-results/previous-regression.json
```

`docs/evidence/previous-110-tests.json` holds the 110 individual Test IDs passed at fixed main `6e2836de3706719445d0526a619769bf086c7546`. CI requires every identity to appear in the new passing set; larger totals, skips or renamed omissions do not substitute for preservation. Existing 78 adversarial fixtures remain unchanged. The new resolution validator adds a positive validation test, and `tests/test_presentation.py` supplies 45 behavioral/integration/negative tests (20 negative).

Generation stays deterministic:

```sh
python scripts/build-foundation.py
python scripts/build-schemas.py
python scripts/build-negative-fixtures.py
python scripts/build-presentation-fixtures.py
git diff --exit-code -- authority registries mappings fixtures schemas
```

The new authority decision hash is generated into the registry; source audit files stay byte-exact. Schema definitions are generated from the same strict model used by the reference validator. No validator rule is weakened, no Field is silently migrated, and no app code is imported by the new generic model or fixtures.
