# Carport Field Closure Authority v0.1

営業見積依頼Scopeの正式Category Authority。巧竜の2026-10-06 Work指示に基づくFoundation追加。Human Evidence Decision、Promotion Approval、メーカー仕様認証を発行しない。

`authority/carport/manifest.v0.1.json` が3 Contractのexact bytesを登録する。消費アプリは中央Merge後の固定SHAと全Snapshot hashを明示採用する。Exteriorだけの非公式JSONはこのAuthorityを代替できない。

- **CARPORT_FIELD_RESPONSIBILITY_CONTRACT**: 15共通概念を一度定義し、Nesca/Fugo/FIRSTの39 Fieldから参照。営業入力、積算/施工/施主による確認、Applicable/Required、未確認初期値、納入⇄施工の子値Reset、保存Identity、出力責務を定義。メーカー仕様・構造適否を入力チェックで認証しない。
- **CARPORT_DERIVATION_CONTRACT**: 3商品でexact scoped official row lookupを使用する規範。禁止→HOLD→全補強前提が揃った公式強化行→公式基本行→UNKNOWNの順。V0と試験風速、案件要求と商品性能を分離する。UNKNOWNを0に置換しない。本Contractは数値の新しい商品Factを供給しない。数値を用いる経路は原資料行と全条件のEvidenceを別途固定する。
- **CARPORT_SEMANTIC_MAPPING_CONTRACT**: 本体区分、完成時台数、屋根/連結構成、支持構成、呼称サイズを分離する。Nesca `base_body_class`→`vehicle_capacity`はNON_IDENTITY。許可Mappingは`base_body_class`→`body_class`、完成時台数は公式構成別Lookup。旧Rejectedを復活させず、ApplicationのSemantic/Mapping Adoptionを別Gateとする。

中央の旧audit baseline、Selection API v0.1、Governance v0.1、既存Authority/Evidence/Approvalは変更しない。新規Validatorはnormative Contract、source hash、入力owner、Field scope、導出完全性、誤った台数同一視を検証する。旧audit mapping自体は歴史的観測として保持され、今後の昇格証明には誤同一視を使用できない。

現Applicationの動作を新規規範の唯一の根拠にしていない。入力責務は営業見積依頼責務境界v1.0とArchitectureの責任分離を明文化したもの。Runtimeに相違があれば後続Application Gateで検証・修正する。今回のContract追加はRuntimeを改変しない。

検証: 全中央Validator、既存213テストと新規13テスト、固定156 Regression inventory、Schema/Fixture builder再現性。新規Human Evidence採用とPromotion Approvalは別途必要。

Fugo base-body car_capacity also remains non-identical to completed vehicle_capacity. Contextual non-applicability for inherited variant/support axes requires the full manufacturer table binding; hidden UI is never that proof.
