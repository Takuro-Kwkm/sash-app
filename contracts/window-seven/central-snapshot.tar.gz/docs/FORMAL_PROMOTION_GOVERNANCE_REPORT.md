# Formal Promotion Governance — Foundation Continuation

## Authority and Exterior audit preservation

- Central repository: `Takuro-Kwkm/product-ui-contracts`.
- Base/adopted authority: `3d4aa126293905b3c7fa9294535007c594626e7a`; current central main readback matched this SHA.
- Exterior previous adopted main: `245d91169331023967b157ad8395037ec5c296ff`.
- PR #19 exact reviewed HEAD: `6db66592efb0fd306485cabecae20cb3d616d627`; open, non-draft, mergeable/clean, latest CI PASS, eight audit/Validator/CI files only.
- Authorized Squash Merge succeeded: Exterior main/merge commit `6b6726b55d60f6e515f94d725b05b48b3785f4b2`.
- Merge tree `4b942681e7d6344f21ce28a0aa5247a5d0b62382` equals PR HEAD tree. Main Report and Promotion Matrix were independently fetched at the merge SHA.
- [Post-Merge CI 37239340480](https://github.com/Takuro-Kwkm/exterior-estimator/actions/runs/37239340480): completed/success. Quality, 41 enforcement tests, Pilot preservation, 19 promotion audit tests, Contract validation and fresh Runtime/Flow parity all PASS. App 110 and existing negative 29 carry forward through this successful CI.

| Exterior adoption | Preserved result |
|---|---:|
| Fields | 101 |
| ネスカ / フーゴ / エフルージュ FIRST | 31 / 36 / 34 |
| EXACT / SEMANTIC / PRODUCT_SPECIFIC | 74 / 13 / 14 |
| FORMAL / PROVISIONAL | 0 / 101 |
| Mapping / Contract status mutations | 0 / 0 |
| Original Adoption Gap | 0 |

`UI_CONTRACT_PILOT_READY`, `EXTERIOR_SELECTION_CONTRACT_ADOPTED`,
`EXTERIOR_CONTRACT_ENFORCEMENT_READY`, `EXTERIOR_CONTRACT_ENFORCEMENT_ADOPTED`
are existing PASS carried forward, not reconstructed or redefined.

## Root cause and generic design

The adopted snapshot defined FORMAL critical-identity checks and PROVISIONAL baseline,
but lacked Field-scoped Evidence Acceptance and Promotion Approval. These are distinct
central capabilities; neither Runtime existence nor an exact name match proves a
Product Fact. Governance v0.1 adds these capabilities for any app/product scope and
retains all existing Selection/Presentation/UI/Category/Exception authorities.

Foundation package 0.3.0 is a PR candidate. Three schemas bring the total to 17;
two integrated validators bring the total to 14. Selection and Presentation schemas
and existing Contract bytes are unchanged. CHANGELOG explicitly records stronger
FORMAL validator acceptance as a 0.x BREAKING change with migration instructions.

Evidence records identify source class/authority, document/source ID/version,
page/section, captured date, verification state, cached bytes/hash/pointer, Field scope,
claims and an independently registered reviewer decision. States are ACCEPTED,
INSUFFICIENT, CONFLICTING, UNVERIFIED. ACCEPTED requires VERIFIED, resolved source
identity, exact bytes, valid scope/class and exact reviewed acceptance payload.

Approval binds Contract, dossier and selected evidence hashes. The prior Contract
and transition are included in the approved dossier. PROVISIONAL↔FORMAL may change
status only. FORMAL with no dossier/approval fails. Old PROVISIONAL needs no new
evidence; mixed statuses and reviewed demotion are supported. All existing validator
gates must pass. Conflicts cannot be hidden by omitting evidence IDs; OPEN promotion
blockers and pending/legacy exceptions block FORMAL.

EXACT requires mapping proof; SEMANTIC adds accepted meaning equivalence;
PRODUCT_SPECIFIC adds accepted stable Identity and scoped source/owner/reason/Global
insufficiency/review governance. Product Facts require authoritative official/verified
Formal Master evidence. Runtime cannot provide Product Fact or semantic identity
authority. Application Runtime/Flow evidence must carry PASS and the exact Field's
status-independent Contract Identity hash. Business-input/derived Fields require
their respective accepted responsibility/derivation authority.

The five existing FORMAL reference examples remain byte-for-byte unchanged and receive
explicit reference-only certifications against existing Human Review/audit scope.
A separate REFERENCE_CERTIFICATION operation preserves their existing FORMAL state
and exact prior bytes; it does not fabricate a prior PROVISIONAL state.
Trusted origin is the snapshot container, and reference Field scope is checked.
These certificates cannot authorize actual application Fields or manufacturer facts.
Synthetic official-source and reviewer fixtures stay isolated under fixture/temp roots.

## Validation and regression

| Check | Local result |
|---|---:|
| Central validators | 14 / 14 PASS; zero errors |
| Previous tests preserved by individual ID | 156 / 156 PASS |
| Added tests | 56 / 56 PASS |
| Named new negative fixtures | 32 / 32 PASS |
| Added positive/integration/edge tests | 24 / 24 PASS |
| Total tests | 212 / 212 PASS |
| Positive cases A / B / C / D | Valid PROVISIONAL / valid FORMAL / insufficient blocked / evidence added eligible |
| Existing negative tests | 98 / 98 PASS; total named negative tests 130 |
| Existing 492 PROVISIONAL baseline / five FORMAL examples | VALID; unchanged |
| Selection / Presentation / semantic / dependency / Exception regression | PASS through preserved tests and validators |
| Reproducible generation | Original builders + new governance builder; tracked byte diff check required in CI |

Negative coverage includes all eight requested cases plus missing/stale references,
unverified acceptance, self declaration, unresolved mapping, existing semantic/
exception/Presentation/dependency gates, unknown state, product-policy hardcode,
Runtime-as-Product-Fact, reference reuse, semantic proof, product-specific rationale,
scope, stale approval/Contract/source, hidden conflict, duplicates, unknown reviewer,
semantic mutation and missing Runtime parity. Additional edge tests reject failed
Runtime reports, pending exceptions, retired/forged review authority, unknown accepted
document identity and unresolved product-specific source/owner.

PR/push CI automatically runs both new validators via validate.py, every test,
all 156 previous test identities, reproducible governance/schema/fixture generation
and tracked diff verification. Validation evidence is uploaded as foundation-validation.
The final PR body and Actions run record the exact published HEAD and remote CI result;
this Report does not embed its own commit SHA or claim remote checks before they run.

## Foundation Gap Closure and boundaries

`docs/formal-promotion-foundation-gaps.v0.1.json` registers:

| Central capability gap | Result |
|---|---|
| FORMAL_PROMOTION_FOUNDATION_GAP-001: Evidence Acceptance | CLOSED at implementation/review-candidate scope |
| FORMAL_PROMOTION_FOUNDATION_GAP-002: Promotion Approval | CLOSED at implementation/review-candidate scope |

Common gaps: 2; CLOSED: 2; remaining new Promotion Foundation gaps: 0.
This does not rewrite Exterior's historical 103 promotion gap records. Its central
policy gap aggregates these capabilities; its shared validation gap also requires
consumer Pilot/baseline migration. Those consumer decisions remain next Work.
Existing Adoption Gap remains 0. Other existing quarantined source/Legacy concerns
are carried forward; no claim of whole-Foundation or whole-product evidence closure.

Product Master / Runtime / UI / Production changes: **0 / 0 / 0 / 0**.
Production Identity: **UNVERIFIED**. No Production deploy/login/browser QA or Field
promotion, Snapshot switch, 101 Field extraction, Master re-QA, or app behavior change.

Review-record admission still relies on repository review authority; CI verifies
records and content binding, not a person's cryptographic identity or manufacturer
truth. Real application evidence/approval must be reviewed before registration.
No central Merge is authorized in this Work. Next: central review/merge → explicit
new Snapshot adoption → consumer guard migration → Field-by-Field reevaluation.

## Final Gate

`FORMAL_PROMOTION_GOVERNANCE_READY_FOR_MERGE` is evaluated after this dedicated central
PR is created, its exact HEAD CI passes and it is non-draft/Ready for Review. The final
PR readback/body and task response hold that decision. Central remains unmerged;
Exterior FORMAL 0 / PROVISIONAL 101 is preserved.
