"""Minimal contract fixtures; imports no application Runtime or product data."""
import copy
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
def write(path, value):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

field = next(f for f in json.loads((ROOT / 'fixtures/current-selection-baseline.v0.1.json').read_text())['fields']
             if f['field_id'] == 'exterior-estimator:fugo:roof_color')
contract = copy.deepcopy(field)
policy = {'version': '0.1', 'semantic_role': field['semantic_role'],
          'authority': [field['option_source']['authority'], 'HUMAN-PRESENTATION-RESOLUTION'],
          'default': {'state': 'SELECTABLE', 'control_type': 'SELECT'},
          'rules': [
              {'rule_id': 'no-candidates', 'when': {'candidate_count': {'min': 0, 'max': 0}},
               'result': {'state': 'EMPTY', 'control_type': None}},
              {'rule_id': 'single-candidate', 'when': {'candidate_count': {'min': 1, 'max': 1}},
               'result': {'state': 'FIXED', 'control_type': 'SUMMARY'}},
          ]}
contract['presentation_resolution'] = policy
contexts = [('multiple', 2, True, 'READY', 'SELECTABLE', 'SELECT'),
            ('single', 1, True, 'READY', 'FIXED', 'SUMMARY'),
            ('zero', 0, True, 'READY', 'EMPTY', None),
            ('not-applicable', 0, False, 'READY', 'NOT_APPLICABLE', None),
            ('manual-confirmation', 0, True, 'CONFIRMATION_REQUIRED', 'MANUAL_CONFIRMATION', None),
            ('error', 0, True, 'ERROR', 'ERROR', None),
            ('blocked', 0, True, 'BLOCKED', 'ERROR', None)]
write('fixtures/presentation/foundation-gap-001.json', {
    'fixture_id': 'FOUNDATION_GAP-001', 'contract': contract,
    'cases': [{'case_id': name, 'context': {'candidate_count': count, 'applicable': applicable,
               'resolution_status': status}, 'expected': {'state': state, 'control_type': control}}
              for name, count, applicable, status, state, control in contexts],
    'evidence_limits': 'Abstract presentation contexts, not AllowedValue/product facts. Single-candidate SUMMARY reproduces the prior Pilot witness; no Exterior Runtime is copied or executed.',
    'prior_witness': {'product_type': 'FUGO-F', 'roof_material': 'RF-FUGO-POLY-BLACK',
                      'current_behavior_mode': 'DERIVED_VISIBLE', 'current_control': 'SUMMARY',
                      'app_commit': '6f321e07766a30c6c474c313693224c2a39e8ed6'},
})

cases = []
def negative(name, code, mutation):
    bad = copy.deepcopy(policy)
    mutation(bad)
    cases.append({'fixture_id': name, 'expected_error': code, 'policy': bad})
negative('invalid-mode', 'INVALID_PRESENTATION_SCHEMA', lambda p: p['default'].update(control_type='MAGIC'))
negative('unknown-condition', 'INVALID_PRESENTATION_SCHEMA', lambda p: p['rules'][0]['when'].update(weather='rain'))
negative('conflicting-rules', 'PRESENTATION_RULE_CONFLICT', lambda p: p['rules'].append(
    {'rule_id': 'overlap', 'when': {'candidate_count': {'min': 0, 'max': 1}}, 'result': {'state': 'EMPTY', 'control_type': None}}))
negative('identical-overlap', 'PRESENTATION_RULE_CONFLICT', lambda p: p['rules'].append({**copy.deepcopy(p['rules'][0]), 'rule_id': 'same-outcome'}))
negative('override-conflict', 'PRESENTATION_RULE_CONFLICT', lambda p: p.update(overrides=[
    {**copy.deepcopy(p['rules'][0]), 'rule_id': 'override-one'},
    {**copy.deepcopy(p['rules'][0]), 'rule_id': 'override-two'}]))
negative('negative-count', 'INVALID_PRESENTATION_SCHEMA', lambda p: p['rules'][0]['when']['candidate_count'].update(min=-1))
negative('fractional-count', 'INVALID_PRESENTATION_SCHEMA', lambda p: p['rules'][0]['when']['candidate_count'].update(min=0.5))
negative('boolean-count', 'INVALID_PRESENTATION_SCHEMA', lambda p: p['rules'][0]['when']['candidate_count'].update(min=True))
negative('invalid-count-range', 'INVALID_CANDIDATE_RANGE', lambda p: p['rules'][0]['when']['candidate_count'].update(min=2,max=0))
negative('unresolved-state', 'UNRESOLVED_PRESENTATION', lambda p: p.pop('default'))
negative('unbounded-unresolved-tail', 'UNRESOLVED_PRESENTATION', lambda p: (
    p.pop('default'), p['rules'].append({'rule_id':'finite-tail','when':{'candidate_count':{'min':2,'max':1000000}},
                                     'result':{'state':'SELECTABLE','control_type':'SELECT'}})))
negative('malformed-default', 'INVALID_PRESENTATION_SCHEMA', lambda p: p.update(default='SELECT'))
negative('illegal-state-control', 'INVALID_PRESENTATION_SCHEMA', lambda p: p['rules'][1]['result'].update(control_type='SELECT'))
negative('zero-choice-select', 'ILLEGAL_ZERO_CANDIDATE_PRESENTATION', lambda p: p['rules'].pop(0))
negative('product-hardcode', 'INVALID_PRESENTATION_SCHEMA', lambda p: p['rules'][1]['when'].update(product='fugo'))
negative('field-hardcode', 'INVALID_PRESENTATION_SCHEMA', lambda p: p['rules'][1]['when'].update(field='roof_color'))
negative('malformed-resolution', 'INVALID_PRESENTATION_SCHEMA', lambda p: p.update(rules={'candidate_count':1}))
negative('empty-definition', 'INVALID_PRESENTATION_SCHEMA', lambda p: (p.pop('default'),p.update(rules=[])))
negative('duplicate-rule-id', 'DUPLICATE_PRESENTATION_RULE', lambda p: p['rules'][1].update(rule_id=p['rules'][0]['rule_id']))
negative('unreachable-applicability', 'UNREACHABLE_PRESENTATION_RULE', lambda p: p['rules'][1]['when'].update(applicable=False))
write('fixtures/presentation-negative.v0.1.json', {'version':'0.1','cases':cases})
print('Generated one gap fixture and ' + str(len(cases)) + ' presentation negatives')
