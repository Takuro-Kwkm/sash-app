"""unittest runner with structured per-test evidence and nonzero failure exit."""
import json
import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
class Result(unittest.TextTestResult):
    def __init__(self,*a,**kw): super().__init__(*a,**kw);self.passed=[]
    def addSuccess(self,test): super().addSuccess(test);self.passed.append(test.id())
suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'))
result=unittest.TextTestRunner(verbosity=1,resultclass=Result).run(suite)
data={'test_count':result.testsRun,'pass_count':len(result.passed),'fail_count':len(result.failures),
      'error_count':len(result.errors),'skip_count':len(result.skipped),'status':'PASS' if result.wasSuccessful() else 'FAIL',
      'passed':result.passed,'failures':[{'test':t.id(),'trace':m} for t,m in result.failures],
      'errors':[{'test':t.id(),'trace':m} for t,m in result.errors],
      'negative_test_count':sum('.NegativeValidation.' in x for x in result.passed)}
if len(sys.argv)>1:
    p=Path(sys.argv[1]);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({k:v for k,v in data.items() if k not in {'passed','failures','errors'}},indent=2))
sys.exit(0 if result.wasSuccessful() else 1)
