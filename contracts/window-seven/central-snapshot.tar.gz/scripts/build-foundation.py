"""Deterministically normalize the immutable audit; never re-audit applications."""
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / 'authority/audit'
VERSION = '0.1'
LEGACY = {'parent', 'pet', 'bifold', 'closet'}
CONTROLS = ['SELECT', 'RADIO', 'NUMBER', 'TEXT', 'TEXTAREA', 'CHECKBOX', 'MULTI_SELECT',
            'SUMMARY', 'GROUP', 'CARD_SELECT', 'READONLY', 'READONLY_INPUT', 'DATE',
            'MODULE_CHOICES', 'CHECKBOX_GROUP_WITH_HIDDEN_MULTIPLE_SELECT']
RESET = {'on_upstream_change': 'REEVALUATE', 'valid': 'KEEP_VALID',
         'invalid': 'CLEAR_RESELECT', 'non_applicable': 'HIDE_AND_EXCLUDE'}

def read(name):
    return json.loads((AUDIT / name).read_text())

def write(path, data):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def arr(v):
    return v if isinstance(v, list) else [v]

FIELDS = read('FIELD_INVENTORY.json')['fields']
FLOWS = read('CATEGORY_FLOW_REGISTRY_DRAFT_v0.1.json')['flows']
SUMMARY = read('AUDIT_SUMMARY.json')
assert SUMMARY['REGISTRY_DESIGN_READY'] == 'PASS'
assert len(FIELDS) == 581
for item in read('FILE_MANIFEST.json')['files']:
    assert digest(AUDIT / item['path']) == item['sha256'], item['path']
REVISIONS = {x['repository'].split('/')[1]: x['HEAD'] for x in read('AUTHORITY_PROVENANCE.json')['identities']}
AUTH = [{'authority_id': 'AUDIT-REPORT', 'kind': 'AUDIT_SNAPSHOT', 'status': 'CURRENT',
         'path': 'authority/audit/UI_FLOW_AUDIT_REPORT.md',
         'sha256': digest(AUDIT / 'UI_FLOW_AUDIT_REPORT.md'), 'revision': 'audit-2026-10-02'},
        {'authority_id': 'HUMAN-ADOPTION', 'kind': 'HUMAN_DECISION', 'status': 'CURRENT',
         'path': 'authority/human-review-adoption.v0.1.json', 'revision': 'human-2026-10-03'}]

def audit_ref(filename, pointer):
    key = 'AUDIT-' + hashlib.sha256((filename + pointer).encode()).hexdigest()[:20]
    if not any(x['authority_id'] == key for x in AUTH):
        AUTH.append({'authority_id': key, 'kind': 'AUDIT_SNAPSHOT', 'status': 'CURRENT',
                     'path': 'authority/audit/' + filename, 'pointer': pointer,
                     'sha256': digest(AUDIT / filename), 'revision': 'audit-2026-10-02'})
    return key

DECISIONS = [
    ('HR-2.1', 'FORMAL', 'Ordinary SELECT empty placeholder only: 選択してください. Error/validation/confirmation/empty-result copy remains separate.'),
    ('HR-2.2', 'CATEGORY_ONLY', 'carport permits SELECT/RADIO per semantic slot. Each contract pins current interactive control. Readonly SUMMARY states require explicit product authority; no arbitrary switching.'),
    ('HR-2.3', 'FORMAL', 'Reevaluate downstream; KEEP_VALID / CLEAR_RESELECT / HIDE_AND_EXCLUDE. Special reset needs scoped authority and exception.'),
    ('HR-2.4', 'TEMPORARY_EXCEPTION', 'V-rail design->glass reset quarantined, not a permanent product/global rule; investigate in separate Change Work.'),
    ('HR-2.5', 'LEGACY_PENDING_MAPPING', '75 UNKNOWN fields remain ambiguous. All four legacy modules (85 fields total, including 10 mapped observations) are outside initial mandatory scope.'),
    ('HR-2.6', 'NOT_FORMALIZED', 'entrance_door and cover_method have insufficient current authority; entrance_renovation cannot substitute.'),
    ('HR-2.7', 'CATEGORY_ONLY', 'Required glyph/badge/text, fixed value rendering and detailed dark presentation keep current app/category boundaries.'),
    ('HR-2.8', 'ENFORCEMENT_GATE', 'Exterior live production->pinned main correspondence does not block foundation, but is mandatory before app CI enforcement.'),
    ('HR-7', 'FORMAL', 'Adopt explicitly requested label/value, applicability, reload identity, derived, unit and flow-authority responsibilities.'),
    ('HR-15', 'FORMAL', 'Authority resolution is Manifest First; archive filenames/comments/caches cannot override CURRENT manifest.'),
    ('HR-16', 'FORMAL', 'Registered/resolver/inventory universes, positive counts and expected adapter coverage must match.'),
    ('HR-19', 'FORMAL', 'Apps consume pinned central commit snapshots, never floating latest.'),
]
write('authority/human-review-adoption.v0.1.json', {'version': VERSION, 'date': '2026-10-03',
      'source': 'Explicit user instructions for Product UI Contracts Foundation',
      'decisions': [{'decision_id': i, 'status': s, 'decision': d} for i,s,d in DECISIONS]})
AUTH[1]['sha256'] = digest(ROOT / AUTH[1]['path'])
DOCS = read('AUTHORITY_PROVENANCE.json')['authority_documents']
for i, d in enumerate(DOCS):
    AUTH.append({'authority_id': 'DOC-' + str(i), 'kind': 'DOCUMENT_IDENTITY',
                 'status': 'CURRENT', 'url': d['url'], 'title': d['title'],
                 'file_id': d['file_id'], 'sha256': d['fetched_content_sha256'],
                 'revision': d['title'], 'content_access': 'AUDIT_ATTESTED_HASH_ONLY'})
ui_doc = next('DOC-' + str(i) for i,d in enumerate(DOCS) if d['title'] == 'Sash UI Standard CURRENT v2.1')
manifest_doc = next('DOC-' + str(i) for i,d in enumerate(DOCS) if d['title'] == 'CURRENT_INFORMATION_SOURCE_MANIFEST v1.5')
write('authority/active-manifest.v0.1.json', {'version': VERSION, 'status': 'ACTIVE',
      'resolution_policy': 'MANIFEST_FIRST', 'snapshot_date': '2026-10-02',
      'source_manifest': manifest_doc, 'current': {'sash_ui_standard': ui_doc},
      'superseded': {'sash_ui_standard': ['v1.8', 'v1.9']},
      'app_revisions': REVISIONS, 'freshness': 'PINNED_AUDIT_SNAPSHOT_NOT_LIVE_MANIFEST'})

# Formalize only explicit adoption. Do not mass-convert the 17 draft statuses.
ADOPTED = {'UI-LABEL-VALUE', 'UI-APPLICABILITY', 'UI-REEVALUATE', 'UI-OUTPUT-SCOPE',
           'UI-RELOAD-IDENTITY', 'UI-DERIVED', 'UI-SELECT-PLACEHOLDER', 'UI-UNIT', 'UI-FLOW-AUTHORITY'}
RULES = []
for i, d in enumerate(read('UI_STANDARD_REGISTRY_DRAFT_v0.1.json')['rules']):
    status = 'FORMAL' if d['rule_id'] in ADOPTED else ('CATEGORY_ONLY' if d['scope'].startswith('CATEGORY') or d['rule_id'] in {'UI-REQUIRED-MARKER','UI-DARK-PRESENTATION','UI-CONTROL-KIND'} else 'PROVISIONAL')
    def contract(key):
        return {'responsibility': d.get(key, 'N/A'), 'owner': 'GLOBAL' if status == 'FORMAL' else 'CATEGORY_OR_APP'}
    r = {'rule_id': d['rule_id'], 'version': VERSION, 'scope': d['scope'],
         'semantic_target': d['semantic_target'], 'status': status,
         'control_contract': {'current_type_must_be_pinned': True, 'arbitrary_switch': False},
         'presentation_contract': contract('presentation'), 'placeholder_contract': contract('placeholder'),
         'label_contract': contract('label_rule'), 'value_contract': contract('value_rule'),
         'required_contract': contract('required_rule'), 'visibility_contract': contract('visibility_rule'),
         'applicability_contract': {'non_applicable': 'HIDE_AND_EXCLUDE'},
         'reset_contract': RESET.copy(), 'unit_contract': contract('unit_rule'),
         'formatter_contract': contract('formatter_rule'), 'output_contract': contract('output_rule'),
         'persistence_contract': {'identity': 'PRESERVE_SELECTION_AND_SOURCE_IDENTITY'},
         'authority': [audit_ref('UI_STANDARD_REGISTRY_DRAFT_v0.1.json', '/rules/' + str(i))] + (['HUMAN-ADOPTION'] if status in {'FORMAL','CATEGORY_ONLY'} else []),
         'source_revision': d['source_revision'],
         'exception_policy': {'deviation_requires_exception_id': True, 'implicit_if_exception': False},
         'audit_status': d['status']}
    if d['rule_id'] == 'UI-SELECT-PLACEHOLDER':
        r['placeholder_contract'] = {'role': 'ORDINARY_SELECT_PLACEHOLDER', 'text': '選択してください',
                                     'excluded_roles': ['VALIDATION','ERROR','EMPTY_RESULT','CONFIRMATION']}
    if d['rule_id'] == 'UI-CONTROL-KIND':
        r['scope'] = 'CATEGORY:carport'
    RULES.append(r)
for rule_id, target, behavior in [
    ('UI-KEEP-VALID','downstream valid after change','KEEP_VALID'),
    ('UI-CLEAR-INVALID','downstream invalid after change','CLEAR_RESELECT'),
    ('UI-HIDE-EXCLUDE','non-applicable selection and business output','HIDE_AND_EXCLUDE'),
    ('UI-MANIFEST-FIRST','authority resolution','MANIFEST_FIRST'),
    ('UI-REGISTERED-UNIVERSE-COVERAGE','adapter resolver inventory completeness','REGISTERED_UNIVERSE_COVERAGE')]:
    r = json.loads(json.dumps(RULES[2]))
    r.update(rule_id=rule_id, semantic_target=target, audit_status='EXPLICIT_HUMAN_ADOPTION',
             authority=['AUDIT-REPORT','HUMAN-ADOPTION'], interaction_behavior=behavior)
    RULES.append(r)
write('registries/ui-standard/ui-standard.v0.1.json', {'version': VERSION, 'rules': RULES})

# Category-owned semantic roles; labels alone never create mappings.
ROLE_MAP = {}
ROLES = []
for x in FIELDS:
    if x['classification'] == 'UNKNOWN':
        continue
    s = x['semantic_role']
    stage = s['semantic_stage'] if isinstance(s, dict) else s
    slot = s.get('semantic_slot', x['canonical_key']) if isinstance(s, dict) else x['canonical_key']
    key = (x['category'], stage, slot)
    rid = x['category'] + ':' + hashlib.sha256('|'.join(key).encode()).hexdigest()[:16]
    ROLE_MAP[x['field_id']] = rid
    if not any(r['semantic_role_id'] == rid for r in ROLES):
        ROLES.append({'semantic_role_id': rid, 'category': x['category'], 'semantic_stage': stage,
                      'semantic_slot': slot, 'canonical_target': x['standard_field'],
                      'status': 'OBSERVED_BASELINE', 'authority': [audit_ref('FIELD_INVENTORY.json','/fields/' + str(FIELDS.index(x)))]})
BODY_ADOPTION = json.loads((ROOT/'authority/carport/body-class-adoption.v0.1.json').read_text()) if (ROOT/'authority/carport/body-class-adoption.v0.1.json').exists() else None
if BODY_ADOPTION: ROLES.append(BODY_ADOPTION['role'])
write('mappings/semantic-role-registry.v0.1.json', {'version': VERSION, 'roles': ROLES})

MAPPINGS = []
for i, x in enumerate(FIELDS):
    MAPPINGS.append({'field_id': x['field_id'], 'app': x['app'], 'product': x['product'],
                     'category': x['category'], 'runtime_key': x['runtime_key'],
                     'canonical_key': x['canonical_key'], 'canonical_target': x['standard_field'],
                     'semantic_role': ROLE_MAP.get(x['field_id'], 'UNKNOWN'),
                     'mapping_type': x['mapping_type'], 'audit_classification': x['classification'],
                     'mapping_scope': 'GLOBAL' if x['classification']=='GLOBAL' else 'CATEGORY_OR_PRODUCT',
                     'status': 'LEGACY_PENDING_MAPPING' if x['product'] in LEGACY else 'OBSERVED_BASELINE',
                     'mandatory_enforcement': False,
                     'authority': [audit_ref('FIELD_INVENTORY.json','/fields/' + str(i))],
                     'source_revision': x['source_revision']})
collisions = defaultdict(list)
for m in MAPPINGS:
    if m['canonical_key'] != 'UNKNOWN':
        collisions[(m['app'], m['product'], m['canonical_target'])].append(m['field_id'])
ALIASES = [{'app': k[0], 'product': k[1], 'canonical_target': k[2], 'field_ids': ids,
            'relation': 'SEMANTIC_CONTAINER_NOT_STATE_MERGE',
            'authority': ['AUDIT-REPORT'], 'status': 'OBSERVED_BASELINE'}
           for k,ids in collisions.items() if len(ids)>1]
write('mappings/field-mapping-baseline.v0.1.json', {'version': VERSION, 'field_count': len(MAPPINGS),
      'fields': MAPPINGS, 'container_alias_groups': ALIASES,
      'policy': 'Mapped observation does not assert app compliance or permit state merging.'})

# Resolve exact UI/runtime keys only. Ambiguous / NON_UI effect rows stay pending.
INDEX = defaultdict(set)
for x in FIELDS:
    for key in {x['ui_field'], x['runtime_key']}:
        if key not in {'UNKNOWN', 'N/A'}:
            INDEX[(x['app'], x['product'], key)].add(x['field_id'])
def resolve(app, product, key):
    candidates = INDEX.get((app, product, key), set())
    return next(iter(candidates)) if len(candidates)==1 else None

EDGES, PENDING = [], []
for i, e in enumerate(read('RESET_DEPENDENCY_MATRIX.json')['edges']):
    u, v = resolve(e['app'],e['product'],e['upstream']), resolve(e['app'],e['product'],e['downstream'])
    ref = audit_ref('RESET_DEPENDENCY_MATRIX.json','/edges/' + str(i))
    if u and v and not e['precision'].startswith('FORMAL_RULE') and e['product'] not in LEGACY:
        EDGES.append({'edge_id': 'DEP-' + str(i).zfill(4), 'category':e['category'],
                      'product':e['product'], 'upstream':u, 'downstream':v,
                      'precision':e['precision'], 'status':'FORMAL_BOUNDARY',
                      'reset': RESET.copy(), 'exception_id': 'EX-VRAIL-DESIGN-GLASS' if e['precision']=='EXECUTED_REPRO_LGA_TO_LGC' else None,
                      'authority':[ref,'HUMAN-ADOPTION'], 'source_revision':REVISIONS[e['app']],
                      'meaning':'Reevaluation boundary; not exhaustive product predicate/AllowedValue authority.'})
    else:
        PENDING.append({'audit_edge_index':i, 'status':'PENDING_AUTHORITY',
                        'reason':'NON_UI/ambiguous effect target or product-rule predicate/default needs separate authority; not a selector reset graph.',
                        'resolved_upstream':u,'resolved_downstream':v,'authority':[ref]})
# A declared alias dependency can be cyclic. Quarantine every edge in that SCC;
# never remove one arbitrarily to manufacture a valid product reset graph.
graph=defaultdict(set)
for e in EDGES: graph[e['upstream']].add(e['downstream'])
def reachable(start, end):
    todo=[start]; visited=set()
    while todo:
        node=todo.pop()
        if node==end: return True
        if node not in visited:
            visited.add(node); todo.extend(graph[node]-visited)
    return False
cyclic=[e for e in EDGES if reachable(e['downstream'],e['upstream'])]
for e in cyclic:
    PENDING.append({'audit_edge_index':int(e['edge_id'].split('-')[1]), 'status':'PENDING_AUTHORITY',
                    'reason':'DECLARED_PARENT_CYCLE_NEEDS_AUTHORITY: reciprocal current metadata is not a formal acyclic selector-reset boundary.',
                    'resolved_upstream':e['upstream'],'resolved_downstream':e['downstream'],'authority':e['authority']})
EDGES=[e for e in EDGES if e not in cyclic]
PENDING.sort(key=lambda e:e['audit_edge_index'])
write('mappings/dependency-baseline.v0.1.json', {'version': VERSION,'edges':EDGES,'pending_edges':PENDING,
      'audit_edge_count':727, 'scope':'Exact structural reevaluation boundaries only.'})

# Exceptions are scoped records, not implicit implementation conditionals.
EXCEPTIONS = []
for i, e in enumerate(read('EXCEPTION_CANDIDATES.json')['exceptions']):
    eid = e['exception_id']
    status = 'TEMPORARY_EXCEPTION' if eid == 'EX-VRAIL-DESIGN-GLASS' else ('LEGACY_EXCEPTION' if eid=='EX-LEGACY-MIGRATION' else 'RETIRED')
    affected = [x['field_id'] for x in FIELDS if eid in x['exception_ids']]
    category = {'EX-CARPORT-CONTROL':'carport','EX-INNER-FINAL-DIMENSION':'interior_window',
                'EX-VRAIL-DESIGN-GLASS':'indoor_joinery','EX-LEGACY-MIGRATION':'indoor_joinery',
                'EX-OUTPUT-DESTINATION':'destination_specific','EX-PLACEHOLDER-SCOPE':'GLOBAL'}[eid]
    EXCEPTIONS.append({'exception_id':eid,'status':status,'scope':e['scope'],'category':category,
                       'product':['slide-vrail'] if eid=='EX-VRAIL-DESIGN-GLASS' else (sorted(LEGACY) if eid=='EX-LEGACY-MIGRATION' else []),
                       'field_id':affected,'standard_behavior':e['standard_behavior'],
                       'exception_behavior':e['current_behavior'],'reason':e['reason'],
                       'authority':[audit_ref('EXCEPTION_CANDIDATES.json','/exceptions/' + str(i)),'HUMAN-ADOPTION'],
                       'source_revision':REVISIONS,'impact':e['impact'],
                       'expiry_or_review_condition': {'review_by':'2026-11-03','event':'Before first indoor_joinery mandatory enforcement; separate product-rule/renderer/dependency authority review.'} if status=='TEMPORARY_EXCEPTION' else {'event':'Mapping completion before legacy module inclusion.' if status=='LEGACY_EXCEPTION' else 'Resolved by explicit category/global responsibility; historical identity only.'},
                       'remediation':'Separate V-rail reset Change Work; KEEP_VALID remains global. Never auto-renew.' if status=='TEMPORARY_EXCEPTION' else ('Canonical mapping and parity QA per module.' if status=='LEGACY_EXCEPTION' else 'No active waiver. See corresponding adopted rule/category/output contract.'),
                       'resolution': {'EX-CARPORT-CONTROL':'Category allowed_control_types',
                                      'EX-INNER-FINAL-DIMENSION':'Category semantic/presentation separation',
                                      'EX-OUTPUT-DESTINATION':'Destination applicability contract',
                                      'EX-PLACEHOLDER-SCOPE':'Global HR-2.1 adoption'}.get(eid,'QUARANTINED')})
write('registries/exceptions/exceptions.v0.1.json', {'version':VERSION,'exceptions':EXCEPTIONS})

# Original 5 current flows, not synthesized product catalog order.
for i, c in enumerate(FLOWS):
    if c['category_id'] in {'entrance_door','cover_method'}:
        write('registries/not-formalized/' + c['category_id'].replace('_','-') + '.v0.1.json',
              {'category_id':c['category_id'],'version':VERSION,'status':'NOT_FORMALIZED',
               'authority':[audit_ref('CATEGORY_FLOW_REGISTRY_DRAFT_v0.1.json','/flows/' + str(i)),'HUMAN-ADOPTION'],
               'reason':c['reason'], 'source_revision':REVISIONS, 'mandatory_enforcement':False})
        continue
    cat = c['category_id']
    rows = [x for x in FIELDS if x['category']==cat and x['product'] not in LEGACY]
    stages = []
    if cat=='indoor_joinery':
        stages = c['groups'].copy()
    elif cat=='interior_window':
        stages = c['semantic_stage_order'].copy()
    elif cat=='window':
        stages = c['groups'].copy()
    else:
        for x in rows:
            s=x['semantic_role']['semantic_stage']
            if s not in stages: stages.append(s)
    allowed = defaultdict(set)
    for x in rows:
        for t in arr(x['control_type']):
            allowed[ROLE_MAP[x['field_id']]].add(t)
    if cat=='carport':
        for key, values in allowed.items():
            if values & {'SELECT','RADIO'}: values.update({'SELECT','RADIO'})
    r = {'category_id':cat,'version':VERSION,'status':'FORMAL','groups':c['groups'],
         'group_order':c['group_order'],'semantic_stages':stages,
         'standard_fields':sorted({x['standard_field'] for x in rows if x['classification']!='PRODUCT'}),
         'field_order_contract':{'authority_kind':'CATEGORY_CONTRACT_NOT_PRODUCT_MASTER_ENUMERATION',
                                  'mode':'FIXED_PRODUCT_SEQUENCE' if cat in {'carport','indoor_joinery'} else 'STATE_DEPENDENT_CATEGORY_PRESENTATION',
                                  'product_sequences':{p:[resolve(next(x['app'] for x in rows if x['product']==p),p,k) for k in seq]
                                                       for p,seq in c['field_order'].items() if p not in LEGACY} if cat in {'carport','indoor_joinery'} else {},
                                  'audit_inventory_union_not_ui_order':{p:seq for p,seq in c['field_order'].items() if p not in LEGACY},
                                  'per_field_order_evidence':{x['field_id']:x['order'] for x in rows},
                                  'presentation_extension_order':c['groups'],
                                  'semantic_order_is_not_flat_render_order':True},
         'required_fields':[x for x in c['required_fields'] if x['field_id'].split(':')[1] not in LEGACY],
         'optional_fields':[x for x in c['optional_fields'] if (x['field_id'] if isinstance(x,dict) else x).split(':')[1] not in LEGACY],
         'dependency_edges':[e for e in EDGES if e['category']==cat],
         'reset_rules':{'global_default':RESET, 'product_rules_remain_product_authority':True},
         'extension_points':c['extension_points'],
         'allowed_control_types':{k:sorted(v) for k,v in allowed.items()},
         'known_exceptions':[e['exception_id'] for e in EXCEPTIONS if e['category']==cat and e['status']!='RETIRED'],
         'authority':[audit_ref('CATEGORY_FLOW_REGISTRY_DRAFT_v0.1.json','/flows/' + str(i)),'HUMAN-ADOPTION'],
         'source_revision':REVISIONS,'product_scope':sorted({x['product'] for x in rows}),
         'enforcement_status':'NOT_INSTALLED_IN_APPLICATION',
         'output_boundary':{'non_applicable':'EXCLUDE', 'hidden_selection':'EXCLUDE',
                            'identity_and_survey_context':'PRESERVE_SEPARATELY', 'destination_owned':True},
         'evidence_limits':c['evidence_limits']}
    if cat=='carport' and BODY_ADOPTION:
        r['allowed_control_types'][BODY_ADOPTION['role']['semantic_role_id']]=['RADIO','SELECT','SUMMARY']
    write('registries/category-flow/' + cat.replace('_','-') + '.v0.1.json', r)

# Current field controls are pinned, but these are not full app migrations.
CONTRACTS = []
for i, x in enumerate(FIELDS):
    if x['product'] in LEGACY or x['category']=='application_route':
        continue
    s=x['semantic_role']; controls=arr(x['control_type']); ct=controls[0]
    role=s['field_role']; kind='DERIVED' if 'DERIVED' in arr(role) and 'SELECTOR' not in arr(role) else 'PRODUCT_AUTHORITY'
    upstream=sorted({e['upstream'] for e in EDGES if e['downstream']==x['field_id']})
    current_exception='EX-VRAIL-DESIGN-GLASS' if 'EX-VRAIL-DESIGN-GLASS' in x['exception_ids'] else None
    CONTRACTS.append({'field_id':x['field_id'],'semantic_role':ROLE_MAP[x['field_id']],
                      'scope':{'app':x['app'],'product':x['product'],'kind':'CURRENT_AUDIT_BASELINE'},
                      'category':x['category'],'runtime_key':x['runtime_key'],'canonical_key':x['canonical_key'],
                      'display_label':x['display_label'],'control_type':ct,'allowed_control_types':controls,
                      'conditional_presentations':{'observed_types':controls,'source':x['fixed_value_behavior'],
                                                    'requires_contract_change':True},
                      'option_source':{'policy':'PRODUCT_AUTHORITY_PER_SELECTION','authority':audit_ref('FIELD_INVENTORY.json','/fields/'+str(i)),
                                       'observed_union_is_allowed_set':False},
                      'label_value_contract':{'separate':True,'raw_value_fallback':False,'official_code_label_requires_authority':True},
                      'group':{'kind':'SEMANTIC_STAGE','id':s['semantic_stage']},
                      'order':{'mode':'CATEGORY_AUTHORITY','evidence':x['order']},
                      'required':{'policy':'APPLICABLE_AND_PRODUCT_RULE','observation':x['required']},
                      'visibility':{'policy':'PRODUCT_AUTHORITY','non_applicable':'HIDE_AND_EXCLUDE'},
                      'applicability':{'policy':'PRODUCT_AUTHORITY','business_output':'EXCLUDE_IF_NON_APPLICABLE'},
                      'dependency':{'mode':'DECLARED_BOUNDARY','exhaustive':False},'upstream_fields':upstream,
                      'reset_behavior':RESET.copy(), 'formatter':{'policy':'CATEGORY_AUTHORITY','value_kind':kind},
                      'unit':{'policy':'SEPARATE_NUMBER_AND_UNIT','observation':x['unit']},
                      'output':{'policy':'APPLICABILITY_AND_DESTINATION','exclude_hidden_selection':True,'exclude_non_applicable':True},
                      'persistence':{'policy':'SELECTION_IDENTITY_WITH_SOURCE_AND_RUNTIME','invisible_context_separate':True},
                      'validation':{'policy':'PRODUCT_AUTHORITY','critical_unknown':'FORBIDDEN_IN_FORMAL'},
                      'default':{'policy':'PRODUCT_AUTHORITY_NO_UI_GUESS'},'empty_state':{'policy':'DISTINCT_FROM_ERROR_AND_CONFIRMATION',
                                  'placeholder_role':'ORDINARY_SELECT_PLACEHOLDER' if ct=='SELECT' else 'NOT_APPLICABLE',
                                  'placeholder':'選択してください' if ct=='SELECT' else None},
                      'error_state':{'policy':'CATEGORY_APP_ERROR_AUTHORITY'},
                      'authority':[audit_ref('FIELD_INVENTORY.json','/fields/'+str(i)),'HUMAN-ADOPTION'],
                      'source_revision':x['source_revision'],'exception_id':current_exception,'status':'PROVISIONAL',
                      'audit_observations':{'control_types':controls,'placeholder':x['placeholder'],'classification':x['classification'],
                                            'observation_coverage':x['observation_coverage']}})
write('fixtures/current-selection-baseline.v0.1.json', {'version':VERSION,'fields':CONTRACTS,
      'scope':'Schema-shaped audit baseline, not assertion of full per-field formal/app behavior adoption.'})
REFERENCE_IDS={'sash-app:SER-LIX-EW:window_type','sash-app:SER-LIXIL-INPLUS:window_type',
               'exterior-estimator:nesca:product_type','interior-estimator:standard:hinge_spec',
               'sash-app:SER-LIXIL-RECHENT-D3-NF:thermal_spec'}
for x in CONTRACTS:
    if x['field_id'] in REFERENCE_IDS:
        example=json.loads(json.dumps(x)); example['status']='FORMAL'
        example['scope']['kind']='REFERENCE_CONTRACT_NOT_INSTALLED'
        write('fixtures/formal/' + x['category'].replace('_','-') + '.json',example)

MODULES=[]
for (app,product), rows in __import__('itertools').groupby(sorted(FIELDS,key=lambda x:(x['app'],x['product'])),key=lambda x:(x['app'],x['product'])):
    xs=list(rows)
    MODULES.append({'module_id':app+':'+product,'app':app,'product':product,'field_count':len(xs),
                    'expected_adapter_coverage': sorted({x['observation_coverage'] for x in xs}),
                    'status':'LEGACY_PENDING_MAPPING' if product in LEGACY else ('APP_ROUTE_BASELINE' if product=='APP_ROUTE' else 'CURRENT'),
                    'authority':['AUDIT-REPORT'],'source_revision':REVISIONS[app]})
write('mappings/coverage-contract.v0.1.json', {'version':VERSION,'rule_id':'REGISTERED_UNIVERSE_COVERAGE',
      'registered_universe':MODULES,'resolver_universe':[x['module_id'] for x in MODULES if x['status']=='CURRENT'],
      'inventory_universe':[x['module_id'] for x in MODULES],'expected_field_count':581,
      'unknown_field_count':75,'legacy_excluded_count':85,
      'non_product_route_count':4,'adapter_coverage':dict(Counter(x['observation_coverage'] for x in FIELDS)),
      'enforcement_gates':[{'gate_id':'EXTERIOR_PRODUCTION_SHA_IDENTITY','app':'exterior-estimator',
                            'status':'BLOCKED_BEFORE_MANDATORY','expected_main_sha':REVISIONS['exterior-estimator'],
                            'evidence':None,'authority':['HUMAN-ADOPTION','AUDIT-REPORT']}],
      'application_enforcement':{'sash-app':False,'exterior-estimator':False,'interior-estimator':False}})
presentation_decision = ROOT / 'authority/presentation-resolution-adoption.v0.1.json'
if presentation_decision.exists():
    AUTH.append({'authority_id':'HUMAN-PRESENTATION-RESOLUTION','kind':'HUMAN_DECISION','status':'CURRENT',
                 'path':'authority/presentation-resolution-adoption.v0.1.json',
                 'revision':'presentation-resolution-2026-10-04',
                 'sha256':hashlib.sha256(presentation_decision.read_bytes()).hexdigest()})
if BODY_ADOPTION:
    body_path=ROOT/'authority/carport/body-class-adoption.v0.1.json'
    AUTH.append({'authority_id':'CARPORT-BODY-CLASS-ADOPTION-20261006','kind':'HUMAN_DECISION','status':'CURRENT','path':str(body_path.relative_to(ROOT)),'sha256':hashlib.sha256(body_path.read_bytes()).hexdigest(),'revision':'user-authorized-semantic-adoption-20261006'})
write('authority/authority-registry.v0.1.json',{'version':VERSION,'authorities':AUTH,'app_revisions':REVISIONS})
write('fixtures/snapshot-template.v0.1.json',{'repository':'Takuro-Kwkm/product-ui-contracts',
      'revision':'<40-character-commit-sha-required>','ui_standard':'0.1','category_flow':'carport@0.1',
      'status':'TEMPLATE_NOT_DISTRIBUTED','content_sha256':'<snapshot-byte-hash-required>'})
print(json.dumps({'rules':len(RULES),'formal_global_rules':sum(r['scope']=='GLOBAL' and r['status']=='FORMAL' for r in RULES),
                  'semantic_roles':len(ROLES),'mapping_fields':len(MAPPINGS),'provisional_selection_fields':len(CONTRACTS),
                  'dependency_boundaries':len(EDGES),'pending_product_effects':len(PENDING),'exceptions':len(EXCEPTIONS)},indent=2))
