"""Generic, read-only presentation contract reference model; no application imports."""
import copy
from itertools import combinations

from jsonschema import Draft202012Validator

CHOICE_CONTROLS = {'SELECT', 'RADIO', 'MULTI_SELECT', 'CARD_SELECT', 'MODULE_CHOICES',
                   'CHECKBOX_GROUP_WITH_HIDDEN_MULTIPLE_SELECT'}
ENTRY_CONTROLS = {'NUMBER', 'TEXT', 'TEXTAREA', 'CHECKBOX', 'DATE'}
FIXED_CONTROLS = {'SUMMARY', 'READONLY', 'READONLY_INPUT'}
CONTEXT_STATUSES = ['READY', 'EMPTY', 'BLOCKED', 'CONFIRMATION_REQUIRED', 'ERROR']

def obj(properties, required=None):
    return {'type': 'object', 'properties': properties,
            'required': list(properties) if required is None else required,
            'additionalProperties': False}

def presentation_schema():
    text = {'type': 'string', 'minLength': 1}
    count = obj({'min': {'type': 'integer', 'minimum': 0},
                 'max': {'anyOf': [{'type': 'integer', 'minimum': 0}, {'type': 'null'}]}})
    condition = obj({'candidate_count': count, 'applicable': {'type': 'boolean'}}, [])
    condition['minProperties'] = 1
    result = {'oneOf': [
        obj({'state': {'const': 'SELECTABLE'}, 'control_type': {'enum': sorted(CHOICE_CONTROLS | ENTRY_CONTROLS)}}),
        obj({'state': {'const': 'FIXED'}, 'control_type': {'enum': sorted(FIXED_CONTROLS)}}),
        obj({'state': {'const': 'CONTAINER'}, 'control_type': {'const': 'GROUP'}}),
        obj({'state': {'enum': ['NOT_APPLICABLE', 'EMPTY', 'MANUAL_CONFIRMATION', 'ERROR']},
             'control_type': {'type': 'null'}}),
    ]}
    rule = obj({'rule_id': text, 'when': condition, 'result': result})
    policy = obj({'version': {'const': '0.1'}, 'semantic_role': text,
                  'authority': {'type': 'array', 'items': text, 'minItems': 1, 'uniqueItems': True},
                  'default': result, 'fallback': result,
                  'rules': {'type': 'array', 'items': rule},
                  'overrides': {'type': 'array', 'items': rule}},
                 ['version', 'semantic_role', 'authority'])
    policy['anyOf'] = [{'required': [key]} for key in ['default', 'fallback']] + [
        {'required': [key], 'properties': {key: {'minItems': 1}}} for key in ['rules', 'overrides']]
    return policy

CONTEXT_SCHEMA = obj({'candidate_count': {'type': 'integer', 'minimum': 0},
                      'applicable': {'type': 'boolean'},
                      'resolution_status': {'enum': CONTEXT_STATUSES}})

def problem(code, path, message):
    return {'code': code, 'path': str(path), 'message': message}

def matches(condition, context):
    bounds = condition.get('candidate_count', {'min': 0, 'max': None})
    return (context['candidate_count'] >= bounds['min'] and
            (bounds['max'] is None or context['candidate_count'] <= bounds['max']) and
            ('applicable' not in condition or context['applicable'] == condition['applicable']))

def overlapping(left, right):
    if 'applicable' in left and 'applicable' in right and left['applicable'] != right['applicable']:
        return False
    a = left.get('candidate_count', {'min': 0, 'max': None})
    b = right.get('candidate_count', {'min': 0, 'max': None})
    return max(a['min'], b['min']) <= min(a['max'] if a['max'] is not None else float('inf'),
                                       b['max'] if b['max'] is not None else float('inf'))

def result_error(result, context):
    if (context['candidate_count'] == 0 and result['state'] == 'SELECTABLE' and
            result['control_type'] in CHOICE_CONTROLS):
        return 'ILLEGAL_ZERO_CANDIDATE_PRESENTATION'
    return None

def _resolve(policy, context):
    # Mandatory existing applicability/error boundaries cannot be overridden by UI policy.
    if not context['applicable']:
        return {'state': 'NOT_APPLICABLE', 'control_type': None}, 'APPLICABILITY_GUARD'
    guarded = {'EMPTY': 'EMPTY', 'BLOCKED': 'ERROR', 'ERROR': 'ERROR',
               'CONFIRMATION_REQUIRED': 'MANUAL_CONFIRMATION'}.get(context['resolution_status'])
    if guarded:
        return {'state': guarded, 'control_type': None}, 'STATUS_GUARD'
    for level in ['overrides', 'rules']:
        candidates = [r for r in policy.get(level, []) if matches(r['when'], context)]
        if len(candidates) > 1:
            raise ValueError('PRESENTATION_RULE_CONFLICT')
        if candidates:
            return candidates[0]['result'], level + ':' + candidates[0]['rule_id']
    for level in ['default', 'fallback']:
        if level in policy:
            return policy[level], level
    raise ValueError('UNRESOLVED_PRESENTATION')

def validate_policy(policy, semantic_role=None, allowed_controls=None):
    errors = [problem('INVALID_PRESENTATION_SCHEMA', '/'.join(map(str, e.absolute_path)), e.message)
              for e in Draft202012Validator(presentation_schema()).iter_errors(policy)]
    if errors:
        return errors
    if semantic_role is not None and policy['semantic_role'] != semantic_role:
        errors.append(problem('PRESENTATION_SEMANTIC_MISMATCH', 'semantic_role', 'Semantic identity cannot be reassigned by presentation'))
    rules = policy.get('rules', []) + policy.get('overrides', [])
    ids = [r['rule_id'] for r in rules]
    if len(ids) != len(set(ids)):
        errors.append(problem('DUPLICATE_PRESENTATION_RULE', 'rule_id', 'Rule identities must be unique across levels'))
    for rule in rules:
        bounds = rule['when'].get('candidate_count')
        if bounds and bounds['max'] is not None and bounds['min'] > bounds['max']:
            errors.append(problem('INVALID_CANDIDATE_RANGE', rule['rule_id'], 'Minimum exceeds maximum'))
        if rule['when'].get('applicable') is False:
            errors.append(problem('UNREACHABLE_PRESENTATION_RULE', rule['rule_id'], 'Applicability guard already hides this state'))
    for level in ['overrides', 'rules']:
        for left, right in combinations(policy.get(level, []), 2):
            if overlapping(left['when'], right['when']):
                errors.append(problem('PRESENTATION_RULE_CONFLICT', level, left['rule_id'] + ' overlaps ' + right['rule_id']))
    results = [r['result'] for r in rules] + [policy[k] for k in ['default', 'fallback'] if k in policy]
    for result in results:
        if allowed_controls is not None and result['control_type'] is not None and result['control_type'] not in allowed_controls:
            errors.append(problem('PRESENTATION_CATEGORY_CONTROL', result['control_type'], 'Resolved control needs Category role permission'))
    if errors:
        return errors
    # Every predicate is an interval or boolean. Boundaries partition the unbounded
    # integer domain into equivalent cells; this is complete coverage, not sampling.
    counts = {0}
    for rule in rules:
        bounds = rule['when'].get('candidate_count')
        if bounds:
            counts.add(bounds['min'])
            if bounds['min'] > 0:
                counts.add(bounds['min'] - 1)
            if bounds['max'] is not None:
                counts.update([bounds['max'], bounds['max'] + 1])
    for count in sorted(counts):
        context = {'candidate_count': count, 'applicable': True, 'resolution_status': 'READY'}
        try:
            result, origin = _resolve(policy, context)
            code = result_error(result, context)
            if code:
                errors.append(problem(code, origin, 'Zero choices cannot render an ordinary choice control'))
        except ValueError as error:
            errors.append(problem(str(error), 'candidate_count=' + str(count), 'No default/fallback or matching rule'))
    return errors

def resolve_presentation(policy, context, semantic_role=None, allowed_controls=None):
    """Return a decision only. Never select, reset, format, persist or render a value."""
    errors = validate_policy(policy, semantic_role, allowed_controls)
    if errors:
        raise ValueError(errors[0]['code'])
    if not Draft202012Validator(CONTEXT_SCHEMA).is_valid(context):
        raise ValueError('INVALID_PRESENTATION_CONTEXT')
    result, origin = _resolve(policy, context)
    return {'semantic_role': policy['semantic_role'], **copy.deepcopy(result), 'resolved_by': origin}
