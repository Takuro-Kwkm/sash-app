"""Create standalone Draft 2020-12 JSON Schemas with local definitions."""
import json
from pathlib import Path
from presentation import presentation_schema

ROOT = Path(__file__).resolve().parents[1]
S = {'type':'string','minLength':1}
SHA = {'type':'string','pattern':'^[a-f0-9]{40}$'}
H = {'type':'string','pattern':'^[a-f0-9]{64}$'}
STRINGS = {'type':'array','items':S,'uniqueItems':True}
AUTH = {**STRINGS,'minItems':1}
CONTROLS = ['SELECT','RADIO','NUMBER','TEXT','TEXTAREA','CHECKBOX','MULTI_SELECT','SUMMARY',
            'GROUP','CARD_SELECT','READONLY','READONLY_INPUT','DATE','MODULE_CHOICES',
            'CHECKBOX_GROUP_WITH_HIDDEN_MULTIPLE_SELECT']
C = {'enum':CONTROLS}
OBJ = {'type':'object'}

def object_schema(properties, required=None, additional=False):
    return {'type':'object','properties':properties,'required':list(properties) if required is None else required,
            'additionalProperties':additional}

def array(items, minimum=0):
    return {'type':'array','items':items,'minItems':minimum}

def schema(name, shape):
    shape.update({'$schema':'https://json-schema.org/draft/2020-12/schema',
                  '$id':'https://product-ui-contracts.local/schemas/'+name+'.schema.json'})
    (ROOT / 'schemas').mkdir(exist_ok=True)
    (ROOT / 'schemas' / (name+'.schema.json')).write_text(json.dumps(shape,ensure_ascii=False,indent=2)+'\n')

RESET = object_schema({'on_upstream_change':{'const':'REEVALUATE'},
                      'valid':{'enum':['KEEP_VALID','REPLACE_STANDARD']},
                      'invalid':{'enum':['CLEAR_RESELECT','CLEAR','RESELECT']},
                      'non_applicable':{'const':'HIDE_AND_EXCLUDE'}})
RULEPROPS = {'rule_id':S,'version':{'const':'0.1'},'scope':S,'semantic_target':S,
             'status':{'enum':['FORMAL','CATEGORY_ONLY','PROVISIONAL','UNKNOWN','NOT_FORMALIZED']},
             **{k:OBJ for k in ['control_contract','presentation_contract','placeholder_contract','label_contract',
                               'value_contract','required_contract','visibility_contract','applicability_contract',
                               'unit_contract','formatter_contract','output_contract','persistence_contract','exception_policy']},
             'reset_contract':RESET,'authority':AUTH,'source_revision':{'type':'object','additionalProperties':SHA},
             'audit_status':S,'interaction_behavior':S}
schema('ui-standard', object_schema({'version':{'const':'0.1'},'rules':array(object_schema(RULEPROPS,[k for k in RULEPROPS if k!='interaction_behavior']),1)}))

EDGE = object_schema({'edge_id':S,'category':S,'product':S,'upstream':S,'downstream':S,
                      'precision':S,'status':{'const':'FORMAL_BOUNDARY'},'reset':RESET,
                      'exception_id':{'type':['string','null']},'authority':AUTH,'source_revision':SHA,'meaning':S})
FLOWPROPS = {'category_id':{'enum':['carport','indoor_joinery','window','interior_window','entrance_renovation']},
             'version':{'const':'0.1'},'status':{'const':'FORMAL'},'groups':{**STRINGS,'minItems':1},
             'group_order':{'type':'array','items':{'type':'integer','minimum':1},'uniqueItems':True,'minItems':1},
             'semantic_stages':{**STRINGS,'minItems':1},'standard_fields':STRINGS,
             'field_order_contract':object_schema({'authority_kind':{'const':'CATEGORY_CONTRACT_NOT_PRODUCT_MASTER_ENUMERATION'},
                   'mode':{'enum':['FIXED_PRODUCT_SEQUENCE','STATE_DEPENDENT_CATEGORY_PRESENTATION']},
                   'product_sequences':{'type':'object','additionalProperties':STRINGS},
                   'audit_inventory_union_not_ui_order':{'type':'object','additionalProperties':STRINGS},
                   'per_field_order_evidence':{'type':'object','additionalProperties':{}},
                   'presentation_extension_order':STRINGS,'semantic_order_is_not_flat_render_order':{'const':True}}),
             'required_fields':array(object_schema({'field_id':S,'rule':{}},additional=False)),
             'optional_fields':STRINGS,'dependency_edges':array(EDGE),
             'reset_rules':object_schema({'global_default':RESET,'product_rules_remain_product_authority':{'const':True}}),
             'extension_points':STRINGS,'allowed_control_types':{'type':'object','minProperties':1,'additionalProperties':{**array(C,1),'uniqueItems':True}},
             'known_exceptions':STRINGS,'authority':AUTH,'source_revision':{'type':'object','additionalProperties':SHA},
             'product_scope':{**STRINGS,'minItems':1},'enforcement_status':{'const':'NOT_INSTALLED_IN_APPLICATION'},
             'output_boundary':object_schema({'non_applicable':{'const':'EXCLUDE'},'hidden_selection':{'const':'EXCLUDE'},
                   'identity_and_survey_context':{'const':'PRESERVE_SEPARATELY'},'destination_owned':{'const':True}}),
             'evidence_limits':S}
schema('category-flow',object_schema(FLOWPROPS))

FIELD = {'field_id':S,'semantic_role':S,
         'scope':object_schema({'app':{'enum':['sash-app','exterior-estimator','interior-estimator']},'product':S,'kind':S}),
         'category':S,'runtime_key':S,'canonical_key':S,
         'display_label':{'oneOf':[S,{'type':'array','items':S,'minItems':1}]},
         'control_type':{'enum':CONTROLS+['UNKNOWN']},
         'allowed_control_types':{**array({'enum':CONTROLS+['UNKNOWN']},1),'uniqueItems':True},
         'conditional_presentations':object_schema({'observed_types':array(C,1),'source':{},'requires_contract_change':{'const':True}}),
         'option_source':object_schema({'policy':{'enum':['PRODUCT_AUTHORITY_PER_SELECTION','UNKNOWN']},'authority':S,'observed_union_is_allowed_set':{'const':False}}),
         'label_value_contract':object_schema({'separate':{'type':'boolean'},'raw_value_fallback':{'type':'boolean'},'official_code_label_requires_authority':{'type':'boolean'}}),
         'group':object_schema({'kind':{'enum':['SEMANTIC_STAGE','PRESENTATION_GROUP']},'id':S}),
         'order':object_schema({'mode':{'enum':['CATEGORY_AUTHORITY','UNKNOWN']},'evidence':{}}),
         'required':object_schema({'policy':{'enum':['APPLICABLE_AND_PRODUCT_RULE','UNKNOWN']},'observation':{}}),
         'visibility':object_schema({'policy':{'enum':['PRODUCT_AUTHORITY','UNKNOWN']},'non_applicable':{'enum':['HIDE_AND_EXCLUDE','UNKNOWN']}}),
         'applicability':object_schema({'policy':{'enum':['PRODUCT_AUTHORITY','UNKNOWN']},'business_output':{'enum':['EXCLUDE_IF_NON_APPLICABLE','UNKNOWN']}}),
         'dependency':object_schema({'mode':{'enum':['DECLARED_BOUNDARY','NONE','UNKNOWN']},'exhaustive':{'type':'boolean'}}),
         'upstream_fields':STRINGS,'reset_behavior':RESET,
         'formatter':object_schema({'policy':{'enum':['CATEGORY_AUTHORITY','UNKNOWN']},'value_kind':{'enum':['DERIVED','PRODUCT_AUTHORITY','UNKNOWN']}}),
         'unit':object_schema({'policy':{'enum':['SEPARATE_NUMBER_AND_UNIT','UNKNOWN']},'observation':{}}),
         'output':object_schema({'policy':{'enum':['APPLICABILITY_AND_DESTINATION','UNKNOWN']},'exclude_hidden_selection':{'type':'boolean'},'exclude_non_applicable':{'type':'boolean'}}),
         'persistence':object_schema({'policy':{'enum':['SELECTION_IDENTITY_WITH_SOURCE_AND_RUNTIME','UNKNOWN']},'invisible_context_separate':{'type':'boolean'}}),
         'validation':object_schema({'policy':{'enum':['PRODUCT_AUTHORITY','UNKNOWN']},'critical_unknown':{'const':'FORBIDDEN_IN_FORMAL'}}),
         'default':object_schema({'policy':{'enum':['PRODUCT_AUTHORITY_NO_UI_GUESS','UNKNOWN']}}),
         'empty_state':object_schema({'policy':{'enum':['DISTINCT_FROM_ERROR_AND_CONFIRMATION','UNKNOWN']},
                                     'placeholder_role':{'enum':['ORDINARY_SELECT_PLACEHOLDER','NOT_APPLICABLE','UNKNOWN']},'placeholder':{'type':['string','null']}}),
         'error_state':object_schema({'policy':{'enum':['CATEGORY_APP_ERROR_AUTHORITY','UNKNOWN']}}),
         'authority':AUTH,'source_revision':{'oneOf':[SHA,{'const':'UNKNOWN'}]},'exception_id':{'type':['string','null']},
         'status':{'enum':['FORMAL','PROVISIONAL','DRAFT','LEGACY_PENDING_MAPPING','UNKNOWN']},
         'audit_observations':OBJ}
FIELD['presentation_resolution'] = presentation_schema()
f_schema=object_schema(FIELD,[k for k in FIELD if k not in {'conditional_presentations','audit_observations','presentation_resolution'}])
critical=['field_id','semantic_role','scope','category','runtime_key','canonical_key','display_label','control_type',
          'allowed_control_types','option_source','group','order','required','visibility','applicability','dependency',
          'reset_behavior','formatter','unit','output','persistence','validation','default','empty_state','error_state','authority','source_revision']
# Recursive UNKNOWN bans in critical formal structures, including nested policy values.
f_schema['$defs']={'noUnknown':{'not':{'enum':['UNKNOWN','N/A','']},
    'allOf':[{'if':{'type':'object'},'then':{'properties':{'observation':{},'evidence':{}},'additionalProperties':{'$ref':'#/$defs/noUnknown'}}},
             {'if':{'type':'array'},'then':{'items':{'$ref':'#/$defs/noUnknown'}}}]}}
f_schema['allOf']=[{'if':{'properties':{'status':{'const':'FORMAL'}},'required':['status']},
                     'then':{'properties':{k:{'allOf':[{'$ref':'#/$defs/noUnknown'}]} for k in critical}}}]
schema('selection-contract',f_schema)
schema('presentation-resolution',presentation_schema())

E = object_schema({'exception_id':S,'status':{'enum':['FORMAL_EXCEPTION','TEMPORARY_EXCEPTION','LEGACY_EXCEPTION','PENDING_REVIEW','RETIRED']},
                  'scope':S,'category':S,'product':STRINGS,'field_id':STRINGS,'standard_behavior':S,
                  'exception_behavior':S,'reason':S,'authority':AUTH,'source_revision':{'type':'object','additionalProperties':SHA},
                  'impact':S,'expiry_or_review_condition':object_schema({'review_by':{'type':'string','format':'date'},'event':S},['event']),
                  'remediation':S,'resolution':S})
E['allOf']=[{'if':{'properties':{'status':{'const':'TEMPORARY_EXCEPTION'}}},'then':{'properties':{'expiry_or_review_condition':{'required':['review_by']}}}}]
schema('exception',object_schema({'version':{'const':'0.1'},'exceptions':array(E)}))
schema('selection-baseline',object_schema({'version':{'const':'0.1'},'fields':array({'type':'object'},1),'scope':S}))
schema('not-formalized',object_schema({'category_id':{'enum':['entrance_door','cover_method']},'version':{'const':'0.1'},
                                     'status':{'const':'NOT_FORMALIZED'},'authority':AUTH,'reason':S,
                                     'source_revision':{'type':'object','additionalProperties':SHA},'mandatory_enforcement':{'const':False}}))
schema('dependency-baseline',object_schema({'version':{'const':'0.1'},'edges':array(EDGE),
        'pending_edges':array(object_schema({'audit_edge_index':{'type':'integer','minimum':0},'status':{'const':'PENDING_AUTHORITY'},
                'reason':S,'resolved_upstream':{'type':['string','null']},'resolved_downstream':{'type':['string','null']},'authority':AUTH})),
        'audit_edge_count':{'type':'integer','minimum':1},'scope':S}))
schema('snapshot',object_schema({'repository':{'const':'Takuro-Kwkm/product-ui-contracts'},'revision':SHA,
        'ui_standard':{'const':'0.1'},'category_flow':{'type':'string','pattern':'^(carport|indoor_joinery|window|interior_window|entrance_renovation)@0\\.1$'},
        'content_sha256':H}))
MAPROW=object_schema({'field_id':S,'app':S,'product':S,'category':S,'runtime_key':S,'canonical_key':S,
        'canonical_target':S,'semantic_role':S,'mapping_type':{'enum':['exact match','semantic match','product specific','ambiguous']},
        'audit_classification':{'enum':['GLOBAL','CATEGORY','PRODUCT','EXCEPTION_CANDIDATE','UNKNOWN']},
        'mapping_scope':{'enum':['GLOBAL','CATEGORY_OR_PRODUCT']},'status':{'enum':['OBSERVED_BASELINE','LEGACY_PENDING_MAPPING','FORMAL']},
        'mandatory_enforcement':{'type':'boolean'},'authority':AUTH,'source_revision':SHA})
schema('field-mapping',object_schema({'version':{'const':'0.1'},'field_count':{'type':'integer','minimum':1},'fields':array(MAPROW,1),
        'container_alias_groups':array(object_schema({'app':S,'product':S,'canonical_target':S,'field_ids':{**STRINGS,'minItems':2},
          'relation':{'const':'SEMANTIC_CONTAINER_NOT_STATE_MERGE'},'authority':AUTH,'status':{'const':'OBSERVED_BASELINE'}})),'policy':S}))
schema('semantic-role',object_schema({'version':{'const':'0.1'},'roles':array(object_schema({'semantic_role_id':S,'category':S,
        'semantic_stage':S,'semantic_slot':S,'canonical_target':S,'status':{'const':'OBSERVED_BASELINE'},'authority':AUTH}),1)}))
MOD=object_schema({'module_id':S,'app':S,'product':S,'field_count':{'type':'integer','minimum':1},'expected_adapter_coverage':{**STRINGS,'minItems':1},
        'status':{'enum':['LEGACY_PENDING_MAPPING','APP_ROUTE_BASELINE','CURRENT']},'authority':AUTH,'source_revision':SHA})
schema('coverage',object_schema({'version':{'const':'0.1'},'rule_id':{'const':'REGISTERED_UNIVERSE_COVERAGE'},
        'registered_universe':array(MOD,1),'resolver_universe':{**STRINGS,'minItems':1},'inventory_universe':{**STRINGS,'minItems':1},
        'expected_field_count':{'type':'integer','minimum':1},'unknown_field_count':{'type':'integer','minimum':0},
        'legacy_excluded_count':{'type':'integer','minimum':0},'non_product_route_count':{'type':'integer','minimum':0},
        'adapter_coverage':{'type':'object','additionalProperties':{'type':'integer','minimum':0}},
        'enforcement_gates':array(object_schema({'gate_id':S,'app':S,'status':{'enum':['BLOCKED_BEFORE_MANDATORY','VERIFIED']},
                'expected_main_sha':SHA,'evidence':{'type':['string','object','null']},'authority':AUTH}),1),
        'application_enforcement':object_schema({app:{'type':'boolean'} for app in ['sash-app','exterior-estimator','interior-estimator']})}))
AP=object_schema({'authority_id':S,'kind':{'enum':['AUDIT_SNAPSHOT','HUMAN_DECISION','DOCUMENT_IDENTITY']},
        'status':{'const':'CURRENT'},'path':S,'pointer':S,'sha256':H,'revision':S,'url':S,'title':S,'file_id':S,
        'content_access':{'const':'AUDIT_ATTESTED_HASH_ONLY'}},['authority_id','kind','status','sha256','revision'])
AP['allOf']=[{'if':{'properties':{'kind':{'const':'DOCUMENT_IDENTITY'}}},'then':{'required':['url','title','file_id','content_access']},
             'else':{'required':['path']}}]
schema('authority',object_schema({'version':{'const':'0.1'},'authorities':array(AP,1),'app_revisions':{'type':'object','minProperties':3,'additionalProperties':SHA}}))
schema('active-manifest',object_schema({'version':{'const':'0.1'},'status':{'const':'ACTIVE'},'resolution_policy':{'const':'MANIFEST_FIRST'},
        'snapshot_date':{'type':'string','format':'date'},'source_manifest':S,'current':{'type':'object','minProperties':1,'additionalProperties':S},
        'superseded':{'type':'object','additionalProperties':STRINGS},'app_revisions':{'type':'object','minProperties':3,'additionalProperties':SHA},
        'freshness':{'const':'PINNED_AUDIT_SNAPSHOT_NOT_LIVE_MANIFEST'}}))
print('Generated 14 schemas')
