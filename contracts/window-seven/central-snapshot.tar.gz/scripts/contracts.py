"""Local contract validation. Does not fetch, execute, or mutate application code."""
import copy
import datetime as dt
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker
from presentation import validate_policy, resolve_presentation
from formal_promotion import validate_evidence, validate_promotion
import carport_authority
import body_class_adoption

ROOT = Path(__file__).resolve().parents[1]
CONTROL_TYPES = {'SELECT','RADIO','NUMBER','TEXT','TEXTAREA','CHECKBOX','MULTI_SELECT','SUMMARY',
                 'GROUP','CARD_SELECT','READONLY','READONLY_INPUT','DATE','MODULE_CHOICES',
                 'CHECKBOX_GROUP_WITH_HIDDEN_MULTIPLE_SELECT'}
FORMAL_CATEGORIES = {'carport','indoor_joinery','window','interior_window','entrance_renovation'}
BASE_RESET = {'on_upstream_change':'REEVALUATE','valid':'KEEP_VALID','invalid':'CLEAR_RESELECT','non_applicable':'HIDE_AND_EXCLUDE'}
LEGACY_PRODUCTS = {'parent','pet','bifold','closet'}

def read(root, path):
    return json.loads((root / path).read_text())

def load_bundle(root=ROOT):
    return {'root':str(root), 'ui':read(root,'registries/ui-standard/ui-standard.v0.1.json'),
            'flows':[json.loads(p.read_text()) for p in sorted((root/'registries/category-flow').glob('*.json'))],
            'unknown_flows':[json.loads(p.read_text()) for p in sorted((root/'registries/not-formalized').glob('*.json'))],
            'exceptions':read(root,'registries/exceptions/exceptions.v0.1.json'),
            'mapping':read(root,'mappings/field-mapping-baseline.v0.1.json'),
            'roles':read(root,'mappings/semantic-role-registry.v0.1.json'),
            'dependencies':read(root,'mappings/dependency-baseline.v0.1.json'),
            'coverage':read(root,'mappings/coverage-contract.v0.1.json'),
            'fields':read(root,'fixtures/current-selection-baseline.v0.1.json')['fields'],
            'references':[json.loads(p.read_text()) for p in sorted((root/'fixtures/formal').glob('*.json'))],
            'authority':read(root,'authority/authority-registry.v0.1.json'),
            'manifest':read(root,'authority/active-manifest.v0.1.json'),
            'presentation_fixtures':[json.loads(p.read_text()) for p in sorted((root/'fixtures/presentation').glob('*.json'))],
            'promotion_policy':read(root,'registries/formal-promotion/governance.v0.1.json'),
            'field_evidence':read(root,'authority/field-evidence-acceptance.v0.1.json'),
            'field_promotions':read(root,'authority/field-promotion-approvals.v0.1.json')}

def selection_records(b):
    return b['fields'] + b['references'] + [x['contract'] for x in b.get('presentation_fixtures', [])]

def issue(code, path, message):
    return {'code':code,'path':str(path),'message':message}

def unique(records, key, code):
    return [issue(code,key,'Duplicate identity: '+str(k)) for k,n in Counter(x.get(key) for x in records).items() if n>1]

def validate_schema(b):
    root=Path(b['root']); errors=[]; validators={}
    for p in sorted((root/'schemas').glob('*.schema.json')):
        try:
            s=json.loads(p.read_text()); Draft202012Validator.check_schema(s)
            validators[p.name.removesuffix('.schema.json')]=Draft202012Validator(s,format_checker=FormatChecker())
        except Exception as e:
            errors.append(issue('INVALID_SCHEMA',p,str(e)))
    targets=[('ui-standard',b['ui']),('exception',b['exceptions']),('dependency-baseline',b['dependencies']),
             ('field-mapping',b['mapping']),('semantic-role',b['roles']),('coverage',b['coverage']),
             ('authority',b['authority']),('active-manifest',b['manifest'])]
    targets += [('category-flow',x) for x in b['flows']]+[('not-formalized',x) for x in b['unknown_flows']]
    targets += [('selection-contract',x) for x in selection_records(b)]
    targets += [('presentation-resolution',x['presentation_resolution']) for x in selection_records(b) if 'presentation_resolution' in x]
    targets += [('formal-promotion-governance',b['promotion_policy']),('evidence-acceptance',b['field_evidence']),
                ('formal-promotion',b['field_promotions'])]
    for name,x in targets:
        if name not in validators:
            errors.append(issue('MISSING_SCHEMA',name,'Validator schema missing')); continue
        for e in validators[name].iter_errors(x):
            errors.append(issue('SCHEMA',name+'/'+str(x.get('field_id',x.get('category_id','registry')))+'/'+ '/'.join(map(str,e.absolute_path)),e.message))
    return errors

def validate_mapping(b):
    rows=b['mapping']['fields']; errors=unique(rows,'field_id','DUPLICATE_FIELD_ID')
    errors += unique(b['roles']['roles'],'semantic_role_id','DUPLICATE_ROLE_ID')
    roles={r['semantic_role_id']:r for r in b['roles']['roles']}
    aliases=b['mapping']['container_alias_groups']; groups=defaultdict(list)
    audited={x['field_id']:x for x in read(Path(b['root']),'authority/audit/FIELD_INVENTORY.json')['fields']}
    for m in rows:
        fid=m['field_id']; unknown=m.get('canonical_key')=='UNKNOWN'
        source=audited.get(fid)
        separately_adopted = body_class_adoption.mapping_is_adopted(b, m)
        if not separately_adopted and (not source or any(m.get(k)!=source.get(k) for k in ['app','product','category','runtime_key','canonical_key','mapping_type'])):
            errors.append(issue('AUDIT_MAPPING_IDENTITY',fid,'Baseline differs from pinned audit; separate mapping authority/adoption required'))
        if source and m.get('canonical_target')!=source['standard_field'] and not separately_adopted:
            errors.append(issue('AUDIT_MAPPING_IDENTITY',fid,'Canonical target differs from audit'))
        if unknown:
            if m.get('status')!='LEGACY_PENDING_MAPPING' or m.get('mapping_type')!='ambiguous' or m.get('mandatory_enforcement'):
                errors.append(issue('AMBIGUOUS_FORMAL_MAPPING',fid,'UNKNOWN may only remain quarantined legacy ambiguous mapping'))
            if m.get('semantic_role')!='UNKNOWN' or m.get('canonical_target')!='UNKNOWN':
                errors.append(issue('GUESSED_LEGACY_MAPPING',fid,'Unknown canonical mapping cannot acquire an invented role/target'))
            continue
        if not m.get('canonical_target') or m['canonical_target'] in {'UNKNOWN','N/A'}:
            errors.append(issue('MISSING_CANONICAL_TARGET',fid,'Mapped field needs canonical target'))
        role=roles.get(m.get('semantic_role'))
        if not role:
            errors.append(issue('MISSING_SEMANTIC_ROLE',fid,'Unknown semantic role identity'))
        elif role['category']!=m.get('category') or role['canonical_target']!=m.get('canonical_target'):
            errors.append(issue('INVALID_SEMANTIC_MAPPING',fid,'Category/role/canonical target identity mismatch'))
        if m.get('mapping_scope')=='GLOBAL' and m.get('audit_classification')!='GLOBAL':
            errors.append(issue('INVALID_GLOBAL_MAPPING',fid,'No audit authority for cross-category Global synonym'))
        if m.get('status')=='FORMAL' and m.get('mapping_type')=='ambiguous':
            errors.append(issue('AMBIGUOUS_FORMAL_MAPPING',fid,'Ambiguous mapping cannot be formal'))
        groups[(m['app'],m['product'],m['canonical_target'])].append(fid)
    for (app,product,target), ids in groups.items():
        if len(ids)>1 and not any(a['app']==app and a['product']==product and a['canonical_target']==target and
                                 set(a['field_ids'])==set(ids) and a['relation']=='SEMANTIC_CONTAINER_NOT_STATE_MERGE' for a in aliases):
            errors.append(issue('SEMANTIC_COLLISION',target,'Unapproved multiple states sharing canonical target'))
    for f in selection_records(b):
        if not f.get('semantic_role') or f['semantic_role'] not in roles:
            errors.append(issue('MISSING_SEMANTIC_ROLE',f.get('field_id'),'Field has no registered semantic role'))
    return errors

def validate_selection_contract(b):
    errors=unique(b['fields'],'field_id','DUPLICATE_FIELD_ID')
    errors+=unique(b['references'],'field_id','DUPLICATE_REFERENCE_FIELD_ID')
    baseline={f['field_id']:f for f in b['fields']}
    mapping={m['field_id']:m for m in b['mapping']['fields']}
    for f in selection_records(b):
        fid=f.get('field_id'); m=mapping.get(fid)
        if not m: errors.append(issue('UNMAPPED_FIELD',fid,'Field absent from baseline')); continue
        if (f.get('category'),f.get('runtime_key'),f.get('canonical_key'),f.get('semantic_role')) != (m['category'],m['runtime_key'],m['canonical_key'],m['semantic_role']):
            errors.append(issue('FIELD_IDENTITY_MISMATCH',fid,'Field identity must agree with canonical baseline'))
        if f.get('status')=='FORMAL' and (m['canonical_key']=='UNKNOWN' or m['product'] in LEGACY_PRODUCTS):
            errors.append(issue('LEGACY_FORMALIZATION',fid,'Legacy module cannot be silently promoted'))
        ct=f.get('control_type')
        if ct not in CONTROL_TYPES:
            errors.append(issue('UNKNOWN_CONTROL_TYPE',fid,str(ct)))
        if ct not in f.get('allowed_control_types',[]):
            errors.append(issue('CONTROL_NOT_ALLOWED',fid,'Pinned current control absent from field allowed set'))
        observed=f.get('audit_observations',{}).get('control_types')
        if observed and (ct!=observed[0] or f.get('allowed_control_types')!=observed):
            errors.append(issue('CONTROL_CONTRACT_CHANGE',fid,'Current control differs from fixed audited type/set'))
        if f in b['references'] and fid not in baseline:
            errors.append(issue('MISSING_REFERENCE_BASELINE',fid,'Reference has no current baseline'))
    return errors

def validate_dependency(b):
    errors=[]; fields={f['field_id']:f for f in b['fields']}; edges=b['dependencies']['edges']; graph=defaultdict(set)
    errors+=unique(edges,'edge_id','DUPLICATE_DEPENDENCY_ID')
    for e in edges:
        u,v=e.get('upstream'),e.get('downstream')
        for k,target in [('upstream',u),('downstream',v)]:
            if target not in fields: errors.append(issue('MISSING_'+k.upper()+'_TARGET',e.get('edge_id'),str(target)))
        if u in fields and v in fields:
            if fields[u]['scope']['product']!=fields[v]['scope']['product'] or fields[u]['category']!=fields[v]['category']:
                errors.append(issue('CROSS_PRODUCT_DEPENDENCY',e['edge_id'],'Dependency cannot join independent products/categories'))
            graph[u].add(v)
    visiting=set(); done=set()
    def visit(n):
        if n in visiting:
            errors.append(issue('DEPENDENCY_CYCLE',n,'Selector reevaluation graph contains a cycle')); return
        if n in done: return
        visiting.add(n)
        for child in sorted(graph[n]): visit(child)
        visiting.remove(n); done.add(n)
    for n in sorted(fields): visit(n)
    expected=defaultdict(set)
    for e in edges: expected[e['downstream']].add(e['upstream'])
    for f in b['fields']:
        u=f.get('upstream_fields',[])
        for target in u:
            if target not in fields: errors.append(issue('MISSING_UPSTREAM_TARGET',f['field_id'],str(target)))
        if set(u)!=expected[f['field_id']]: errors.append(issue('DEPENDENCY_DECLARATION_MISMATCH',f['field_id'],'Field and dependency graph upstream sets disagree'))
    return errors

def exception_matches(e, field):
    return bool(e and e['status'] in {'FORMAL_EXCEPTION','TEMPORARY_EXCEPTION','LEGACY_EXCEPTION'} and
                field['field_id'] in e['field_id'] and e['category']==field['category'] and
                (not e['product'] or field['scope']['product'] in e['product']))

def validate_reset(b):
    errors=[]; exceptions={e['exception_id']:e for e in b['exceptions']['exceptions']}
    for f in selection_records(b):
        fid=f['field_id']; reset=f.get('reset_behavior')
        if f.get('upstream_fields') and not reset:
            errors.append(issue('MISSING_RESET_BEHAVIOR',fid,'Dependent field needs reset semantics')); continue
        if not reset: continue
        if reset.get('on_upstream_change')!='REEVALUATE' or reset.get('invalid') not in {'CLEAR','RESELECT','CLEAR_RESELECT'} or reset.get('non_applicable')!='HIDE_AND_EXCLUDE':
            errors.append(issue('INVALID_RESET_ENUM',fid,'Reset contradicts adopted reevaluation contract'))
        if reset.get('valid')!='KEEP_VALID':
            if reset.get('valid')!='REPLACE_STANDARD': errors.append(issue('INVALID_RESET_ENUM',fid,'Unknown valid-value reset enum'))
            if not exception_matches(exceptions.get(f.get('exception_id')),f):
                errors.append(issue('DEVIATION_WITHOUT_EXCEPTION',fid,'Valid-value replacement requires scoped active exception'))
        if f.get('visibility',{}).get('non_applicable')=='HIDE_AND_EXCLUDE' and not f.get('output',{}).get('exclude_non_applicable'):
            errors.append(issue('HIDDEN_EXCLUDED_CONTRADICTION',fid,'Non-applicable field cannot enter business output'))
    for e in b['dependencies']['edges']:
        if e.get('reset')!=BASE_RESET:
            errors.append(issue('DEPENDENCY_RESET_CONTRADICTION',e['edge_id'],'Boundary reset must use global branch semantics; special implementation remains explicit exception'))
    return errors

def validate_ui_standard(b):
    errors=unique(b['ui']['rules'],'rule_id','DUPLICATE_RULE_ID')
    rules={r['rule_id']:r for r in b['ui']['rules']}
    expected={'UI-LABEL-VALUE','UI-APPLICABILITY','UI-REEVALUATE','UI-OUTPUT-SCOPE','UI-RELOAD-IDENTITY','UI-DERIVED',
              'UI-SELECT-PLACEHOLDER','UI-UNIT','UI-FLOW-AUTHORITY','UI-KEEP-VALID','UI-CLEAR-INVALID','UI-HIDE-EXCLUDE',
              'UI-MANIFEST-FIRST','UI-REGISTERED-UNIVERSE-COVERAGE'}
    for rid in expected:
        if rid not in rules or rules[rid]['status']!='FORMAL' or rules[rid]['scope']!='GLOBAL':
            errors.append(issue('MISSING_FORMAL_GLOBAL_RULE',rid,'Explicitly adopted Global rule missing or downgraded'))
    for rid in {'UI-REQUIRED-MARKER','UI-DARK-PRESENTATION','UI-CONTROL-KIND','UI-ERROR-ROLE'}:
        if rid in rules and rules[rid]['status']=='FORMAL' and rules[rid]['scope']=='GLOBAL':
            errors.append(issue('UNADOPTED_GLOBAL_RULE',rid,'Cannot promote unadopted presentation/copy boundary'))
    ph=rules.get('UI-SELECT-PLACEHOLDER',{}).get('placeholder_contract',{})
    if ph.get('role')!='ORDINARY_SELECT_PLACEHOLDER' or ph.get('text')!='選択してください' or set(ph.get('excluded_roles',[]))!={'VALIDATION','ERROR','EMPTY_RESULT','CONFIRMATION'}:
        errors.append(issue('INVALID_PLACEHOLDER_CONTRACT','UI-SELECT-PLACEHOLDER','Placeholder responsibilities/copy differ from HR-2.1'))
    for f in selection_records(b):
        fid=f['field_id']; label=f.get('label_value_contract',{})
        if not label.get('separate') or label.get('raw_value_fallback') or not label.get('official_code_label_requires_authority'):
            errors.append(issue('INVALID_LABEL_VALUE_CONTRACT',fid,'Raw internal value must not be fallback label'))
        labels=f.get('display_label',[]); labels=labels if isinstance(labels,list) else [labels]
        if f.get('runtime_key') in labels:
            errors.append(issue('RAW_RUNTIME_EXPOSURE_CANDIDATE',fid,'Field label equals runtime key; require reviewed official-label authority'))
        if f.get('control_type')=='SELECT':
            empty=f.get('empty_state',{})
            if empty.get('placeholder_role')!='ORDINARY_SELECT_PLACEHOLDER' or empty.get('placeholder')!='選択してください':
                errors.append(issue('INVALID_ORDINARY_SELECT_PLACEHOLDER',fid,'Only ordinary SELECT placeholder uses adopted text'))
    return errors

def validate_category_flow(b):
    errors=unique(b['flows'],'category_id','DUPLICATE_CATEGORY_ID'); flows={c['category_id']:c for c in b['flows']}
    if set(flows)!=FORMAL_CATEGORIES:
        errors.append(issue('FORMAL_CATEGORY_UNIVERSE','flows','Exactly 5 adopted categories required'))
    if {x['category_id'] for x in b['unknown_flows']}!={'entrance_door','cover_method'} or any(x.get('status')!='NOT_FORMALIZED' or x.get('mandatory_enforcement') for x in b['unknown_flows']):
        errors.append(issue('UNKNOWN_CATEGORY_FORMALIZATION','unknown_flows','Unproved categories must remain not formalized'))
    roles={r['semantic_role_id']:r for r in b['roles']['roles']}; fields={f['field_id']:f for f in b['fields']}
    source_flows={c['category_id']:c for c in read(Path(b['root']),'authority/audit/CATEGORY_FLOW_REGISTRY_DRAFT_v0.1.json')['flows']}
    for c in b['flows']:
        cid=c['category_id']
        source=source_flows.get(cid,{})
        if c['groups']!=source.get('groups') or c['group_order']!=source.get('group_order'):
            errors.append(issue('AUDIT_FLOW_IDENTITY',cid,'Category group order differs from adopted current audit authority'))
        if c['group_order']!=list(range(1,len(c['groups'])+1)):
            errors.append(issue('ORDER_CONTRADICTION',cid,'Group order must be exactly ordered unique contiguous positions'))
        if c['field_order_contract']['presentation_extension_order']!=c['groups']:
            errors.append(issue('ORDER_CONTRADICTION',cid,'Presentation order differs from declared group sequence'))
        scoped={f['field_id'] for f in b['fields'] if f['category']==cid}
        for product,seq in c['field_order_contract']['product_sequences'].items():
            expected=[f['field_id'] for f in b['fields'] if f['category']==cid and f['scope']['product']==product]
            if set(seq)!=set(expected) or len(seq)!=len(set(seq)):
                errors.append(issue('PRODUCT_ORDER_COVERAGE',product,'Fixed sequence must cover every product field exactly once'))
            audit=c['field_order_contract']['audit_inventory_union_not_ui_order'].get(product)
            mapped=[fields[i]['field_id'].split(':',2)[2] for i in seq if i in fields]
            source_order=source.get('field_order',{})
            if mapped!=audit or not isinstance(source_order,dict) or mapped!=source_order.get(product):
                errors.append(issue('ORDER_CONTRADICTION',product,'Fixed product order contradicts pinned category authority sequence'))
        for required in c['required_fields']:
            if required['field_id'] not in scoped: errors.append(issue('FLOW_FIELD_REFERENCE',cid,'Unknown/cross-category required field'))
        for fid in c['optional_fields']:
            if fid not in scoped: errors.append(issue('FLOW_FIELD_REFERENCE',cid,'Unknown/cross-category optional field'))
        if cid=='indoor_joinery' and (len(c['semantic_stages'])!=21 or set(c['product_scope'])!={'standard','slide-vrail'}):
            errors.append(issue('INDOOR_SCOPE_VIOLATION',cid,'Formal authority only standard door and V-rail; 21 semantic stages'))
        if cid=='entrance_renovation' and c['product_scope']!=['SER-LIXIL-RECHENT-D3-NF']:
            errors.append(issue('ENTRANCE_SCOPE_VIOLATION',cid,'Rechent R8 cannot authorize new-construction entrance_door'))
        actual=[e for e in b['dependencies']['edges'] if e['category']==cid]
        if c['dependency_edges']!=actual:
            errors.append(issue('FLOW_DEPENDENCY_MISMATCH',cid,'Category and central dependency baseline disagree'))
        for rid,cts in c['allowed_control_types'].items():
            if rid not in roles or roles[rid]['category']!=cid: errors.append(issue('UNKNOWN_SEMANTIC_ROLE',cid,str(rid)))
            if not cts or any(t not in CONTROL_TYPES for t in cts): errors.append(issue('UNKNOWN_CONTROL_TYPE',cid,str(cts)))
            if cid=='carport' and set(cts)&{'SELECT','RADIO'} and not {'SELECT','RADIO'}<=set(cts):
                errors.append(issue('CARPORT_CONTROL_SET',rid,'Category interactive slot permits both SELECT and RADIO'))
    for f in selection_records(b):
        c=flows.get(f.get('category')); role=roles.get(f.get('semantic_role')); group=f.get('group',{})
        if not c: errors.append(issue('UNKNOWN_CATEGORY',f['field_id'],str(f.get('category')))); continue
        allowed=c['semantic_stages'] if group.get('kind')=='SEMANTIC_STAGE' else c['groups']
        if group.get('id') not in allowed: errors.append(issue('UNKNOWN_GROUP',f['field_id'],str(group.get('id'))))
        if role and (role['semantic_stage']!=group.get('id') and group.get('kind')=='SEMANTIC_STAGE'):
            errors.append(issue('CATEGORY_STAGE_VIOLATION',f['field_id'],'Field stage contradicts semantic role'))
        if f.get('control_type') not in c['allowed_control_types'].get(f.get('semantic_role'),[]):
            errors.append(issue('CATEGORY_CONTROL_VIOLATION',f['field_id'],'Category slot does not permit pinned field control'))
    return errors

def validate_exceptions(b, today=None):
    today=today or dt.datetime.now(dt.timezone.utc).date()
    errors=unique(b['exceptions']['exceptions'],'exception_id','DUPLICATE_EXCEPTION_ID')
    exceptions={e['exception_id']:e for e in b['exceptions']['exceptions']}; allids={m['field_id'] for m in b['mapping']['fields']}
    for e in exceptions.values():
        for fid in e['field_id']:
            if fid not in allids: errors.append(issue('UNKNOWN_EXCEPTION_FIELD',e['exception_id'],fid))
        if e['status']=='TEMPORARY_EXCEPTION':
            try:
                expiry=dt.date.fromisoformat(e['expiry_or_review_condition']['review_by'])
                if today>=expiry: errors.append(issue('EXPIRED_TEMPORARY_EXCEPTION',e['exception_id'],'Review required; expiry must not auto-renew'))
            except (KeyError,ValueError): errors.append(issue('MISSING_TEMPORARY_EXPIRY',e['exception_id'],'Concrete review date required'))
        if e['exception_id']=='EX-VRAIL-DESIGN-GLASS' and e['status']!='TEMPORARY_EXCEPTION':
            errors.append(issue('PERMANENT_VRAIL_EXCEPTION',e['exception_id'],'HR-2.4 forbids permanent adoption'))
    for f in selection_records(b):
        if f.get('exception_id') and not exception_matches(exceptions.get(f['exception_id']),f):
            errors.append(issue('INVALID_EXCEPTION_REFERENCE',f['field_id'],'Exception is absent/retired/outside field/product/category scope'))
    for c in b['flows']:
        for eid in c['known_exceptions']:
            if eid not in exceptions or exceptions[eid]['status']=='RETIRED' or exceptions[eid]['category']!=c['category_id']:
                errors.append(issue('INVALID_FLOW_EXCEPTION_REFERENCE',c['category_id'],str(eid)))
    for d in b['dependencies']['edges']:
        eid=d.get('exception_id')
        if eid and (eid not in exceptions or d['downstream'] not in exceptions[eid]['field_id'] or exceptions[eid]['status']=='RETIRED'):
            errors.append(issue('INVALID_DEPENDENCY_EXCEPTION',d['edge_id'],str(eid)))
    return errors

def validate_authority(b, check_bytes=True):
    errors=unique(b['authority']['authorities'],'authority_id','DUPLICATE_AUTHORITY_ID')
    auth={a['authority_id']:a for a in b['authority']['authorities']}; manifest=b['manifest']; root=Path(b['root'])
    if manifest.get('status')!='ACTIVE' or manifest.get('resolution_policy')!='MANIFEST_FIRST':
        errors.append(issue('AUTHORITY_MANIFEST_FIRST','manifest','Active CURRENT manifest resolution required'))
    current=auth.get(manifest.get('current',{}).get('sash_ui_standard'),{})
    if current.get('title')!='Sash UI Standard CURRENT v2.1':
        errors.append(issue('SUPERSEDED_AUTHORITY','sash_ui_standard','v1.8/v1.9 must not supersede manifest-resolved v2.1'))
    if manifest.get('source_manifest') not in auth:
        errors.append(issue('UNKNOWN_AUTHORITY','source_manifest','Manifest must resolve known source identity'))
    pinned=b['authority']['app_revisions']
    if manifest.get('app_revisions')!=pinned:
        errors.append(issue('AUTHORITY_REVISION_MISMATCH','manifest','App snapshot revisions disagree'))
    def walk(x,path):
        if isinstance(x,dict):
            if 'authority' in x:
                refs=x['authority']; refs=[refs] if isinstance(refs,str) else refs
                if not refs: errors.append(issue('MISSING_AUTHORITY',path,'Authority required'))
                for ref in refs:
                    if ref not in auth or auth[ref].get('status')!='CURRENT': errors.append(issue('UNKNOWN_AUTHORITY',path,str(ref)))
            if 'source_revision' in x:
                revisions=x['source_revision']
                if isinstance(revisions,dict):
                    if not revisions or any(k not in pinned or pinned[k]!=v for k,v in revisions.items()):
                        errors.append(issue('AUTHORITY_REVISION_MISMATCH',path,'Unpinned app revision'))
                elif revisions not in pinned.values(): errors.append(issue('AUTHORITY_REVISION_MISMATCH',path,str(revisions)))
            for k,v in x.items():
                # These preserve raw audit annotations, not resolvable authority IDs.
                if k not in {'observation','evidence','audit_observations','per_field_order_evidence'}:
                    walk(v,path+'/'+k)
        elif isinstance(x,list):
            for i,v in enumerate(x): walk(v,path+'/'+str(i))
    for key in ['ui','flows','unknown_flows','exceptions','mapping','roles','fields','references','dependencies','coverage','presentation_fixtures']:
        walk(b.get(key, []),key)
    for r in b['ui']['rules']:
        if not r.get('authority'): errors.append(issue('MISSING_AUTHORITY',r['rule_id'],'Formal rule authority required'))
    hash_cache={}; document_cache={}
    for a in auth.values():
        if a.get('kind')=='DOCUMENT_IDENTITY' and (not a.get('file_id') or not a.get('sha256')):
            errors.append(issue('UNPINNED_DOCUMENT_IDENTITY',a['authority_id'],'Document ID and audit content hash required'))
        if check_bytes and a.get('path'):
            p=(root/a['path']).resolve()
            if not p.is_relative_to(root.resolve()) or not p.exists(): errors.append(issue('MISSING_AUTHORITY_FILE',a['authority_id'],str(a['path']))); continue
            if p not in hash_cache: hash_cache[p]=hashlib.sha256(p.read_bytes()).hexdigest()
            if hash_cache[p]!=a.get('sha256'):
                errors.append(issue('AUTHORITY_CONTENT_MISMATCH',a['authority_id'],'Source bytes differ from pinned identity'))
            if a.get('pointer'):
                try:
                    if p not in document_cache: document_cache[p]=json.loads(p.read_text())
                    value=document_cache[p]
                    for token in a['pointer'].lstrip('/').split('/'):
                        token=token.replace('~1','/').replace('~0','~')
                        value=value[int(token)] if isinstance(value,list) else value[token]
                except (ValueError,KeyError,TypeError,IndexError): errors.append(issue('UNKNOWN_AUTHORITY_POINTER',a['authority_id'],a['pointer']))
    return errors

def validate_coverage(b):
    errors=[]; c=b['coverage']; mappings=b['mapping']['fields']; root=Path(b['root'])
    audit=read(root,'authority/audit/FIELD_INVENTORY.json')['fields']; registered=c['registered_universe']
    errors+=unique(registered,'module_id','DUPLICATE_MODULE_ID')
    reg={x['module_id']:x for x in registered}; resolver=set(c['resolver_universe']); inventory=set(c['inventory_universe'])
    actual=Counter(m['app']+':'+m['product'] for m in mappings)
    source=Counter(m['app']+':'+m['product'] for m in audit)
    if set(reg)!=set(source) or inventory!=set(reg) or set(actual)!=inventory or not resolver<=inventory or resolver!={x['module_id'] for x in registered if x['status']=='CURRENT'}:
        errors.append(issue('REGISTERED_UNIVERSE_OMISSION','coverage','Registered/resolver/inventory/audit universes disagree'))
    if len(mappings)!=c['expected_field_count'] or c['expected_field_count']!=len(audit) or b['mapping']['field_count']!=len(mappings):
        errors.append(issue('FIELD_COUNT_MISMATCH','coverage','Expected audit and mapped logical counts disagree'))
    for mid,m in reg.items():
        if m.get('field_count',0)<=0 or actual[mid]!=m.get('field_count') or source[mid]!=m.get('field_count'):
            errors.append(issue('ZERO_OR_MISSING_FIELDS',mid,'Stage-only or incomplete inventory cannot pass'))
        observed=sorted({x['observation_coverage'] for x in audit if x['app']+':'+x['product']==mid})
        if m['expected_adapter_coverage']!=observed:
            errors.append(issue('ADAPTER_COVERAGE_MISMATCH',mid,'Adapter evidence coverage differs from audit'))
    counts=dict(Counter(x['observation_coverage'] for x in audit))
    if c['adapter_coverage']!=counts: errors.append(issue('ADAPTER_COVERAGE_MISMATCH','coverage','Aggregate adapters disagree'))
    unknown=sum(m['canonical_key']=='UNKNOWN' for m in mappings)
    legacy=sum(m['product'] in LEGACY_PRODUCTS for m in mappings)
    if unknown!=75 or unknown!=c['unknown_field_count'] or legacy!=85 or legacy!=c['legacy_excluded_count']:
        errors.append(issue('UNKNOWN_LEGACY_COUNT','coverage','75 UNKNOWN/85 legacy exclusions must remain distinct'))
    if any(m.get('mandatory_enforcement') for m in mappings if m['product'] in LEGACY_PRODUCTS):
        errors.append(issue('LEGACY_ENFORCEMENT','coverage','Legacy modules outside mandatory scope'))
    productids={m['field_id'] for m in mappings if m['product'] not in LEGACY_PRODUCTS|{'APP_ROUTE'}}
    if {f['field_id'] for f in b['fields']}!=productids:
        errors.append(issue('FIELD_CONTRACT_COVERAGE','coverage','Every current primary product field needs a schema-shaped baseline'))
    gate=next((g for g in c['enforcement_gates'] if g['gate_id']=='EXTERIOR_PRODUCTION_SHA_IDENTITY'),None)
    if not gate or gate['expected_main_sha']!=b['authority']['app_revisions']['exterior-estimator']:
        errors.append(issue('MISSING_ENFORCEMENT_GATE','exterior','Production->main identity gate must remain pinned'))
    if c['application_enforcement'].get('exterior-estimator') and (not gate or gate['status']!='VERIFIED' or not gate.get('evidence')):
        errors.append(issue('EXTERIOR_ENFORCEMENT_GATE','exterior','Mandatory app enforcement requires live Production correspondence evidence'))
    if any(c['application_enforcement'].values()):
        errors.append(issue('APPLICATION_MIGRATION_OUT_OF_SCOPE','coverage','Foundation installs no app enforcement'))
    if len(b['dependencies']['edges'])+len(b['dependencies']['pending_edges'])!=b['dependencies']['audit_edge_count'] or b['dependencies']['audit_edge_count']!=727:
        errors.append(issue('DEPENDENCY_EVIDENCE_COVERAGE','dependencies','All 727 audit edges must be resolved or explicitly quarantined'))
    return errors

def validate_output(b):
    errors=[]
    for f in selection_records(b):
        o=f.get('output',{})
        if not o.get('exclude_hidden_selection') or not o.get('exclude_non_applicable'):
            errors.append(issue('OUTPUT_APPLICABILITY_VIOLATION',f['field_id'],'Hidden/non-applicable selection must not appear in business rows'))
        if f.get('persistence',{}).get('invisible_context_separate') is not True:
            errors.append(issue('CONTEXT_STORAGE_BOUNDARY',f['field_id'],'Non-applicable business rows must not erase unrelated identity/survey storage'))
    return errors

def validate_presentation(b):
    errors = []
    flows = {f['category_id']: f for f in b['flows']}
    authorities = {a['authority_id'] for a in b['authority']['authorities'] if a['status'] == 'CURRENT'}
    for field in selection_records(b):
        if 'presentation_resolution' not in field:
            continue
        policy = field['presentation_resolution']
        allowed = flows.get(field['category'], {}).get('allowed_control_types', {}).get(field['semantic_role'], [])
        errors.extend(validate_policy(policy, field['semantic_role'], allowed))
        if isinstance(policy, dict):
            default = policy.get('default')
            if isinstance(default, dict) and default.get('control_type') != field['control_type']:
                errors.append(issue('PRESENTATION_DEFAULT_CONTROL', field['field_id'], 'Default must retain the audited primary control'))
            refs = policy.get('authority', [])
            for ref in refs if isinstance(refs, list) else []:
                if ref not in authorities:
                    errors.append(issue('UNKNOWN_PRESENTATION_AUTHORITY', field['field_id'], str(ref)))
            results = [policy[k] for k in ['default', 'fallback'] if isinstance(policy.get(k), dict)]
            for level in ['rules', 'overrides']:
                if isinstance(policy.get(level), list):
                    results.extend(r.get('result', {}) for r in policy[level] if isinstance(r, dict))
            if any(isinstance(r, dict) and r.get('control_type') == 'SELECT' for r in results):
                empty = field.get('empty_state', {})
                if empty.get('placeholder_role') != 'ORDINARY_SELECT_PLACEHOLDER' or empty.get('placeholder') != '選択してください':
                    errors.append(issue('PRESENTATION_SELECT_PLACEHOLDER', field['field_id'], 'Conditional ordinary Select retains the existing global placeholder contract'))
    for fixture in b.get('presentation_fixtures', []):
        field = fixture['contract']
        policy = field.get('presentation_resolution')
        if not policy or not fixture.get('cases'):
            errors.append(issue('MISSING_PRESENTATION_REPRODUCTION', fixture.get('fixture_id'), 'Contract and nonempty cases required'))
            continue
        for case in fixture['cases']:
            try:
                resolved = resolve_presentation(policy, case['context'], field['semantic_role'])
                if any(resolved.get(k) != v for k, v in case['expected'].items()) or resolved['semantic_role'] != field['semantic_role']:
                    errors.append(issue('PRESENTATION_FIXTURE_PARITY', fixture['fixture_id'], case['case_id']))
            except (ValueError, KeyError) as error:
                errors.append(issue('PRESENTATION_FIXTURE_RESOLUTION', fixture['fixture_id'], str(error)))
    return errors

def select_reset(previous, allowed_values, applicable=True, exception=None):
    """Normative reference transition, not a product resolver or application patch."""
    if not applicable: return {'action':'HIDE_AND_EXCLUDE','value':None}
    if previous in allowed_values: return {'action':'KEEP_VALID','value':copy.deepcopy(previous)}
    return {'action':'CLEAR_RESELECT','value':None}

def business_output(rows, destination):
    """Selection rows only; identity/survey context uses a separate contract."""
    return [copy.deepcopy(r) for r in rows if r.get('applicable') and r.get('visible') and destination in r.get('destinations',[])]

def check_output_rows(rows, destination):
    return [issue('OUTPUT_APPLICABILITY_VIOLATION',r.get('field_id'),'Non-applicable/hidden/wrong-destination selection row in business output')
            for r in rows if not r.get('applicable') or not r.get('visible') or destination not in r.get('destinations',[])]

def check_option_labels(options, known_authority_ids):
    errors=[]
    for option in options:
        if option.get('kind')=='INTERNAL_VALUE' and option.get('label')==option.get('value'):
            if not option.get('official_label') or option.get('authority') not in known_authority_ids:
                errors.append(issue('RAW_RUNTIME_EXPOSURE_CANDIDATE',option.get('value'),'Internal value used as label without official-label evidence'))
    return errors

def reload_selection(snapshot, source_identity):
    if snapshot.get('identity')!=source_identity: raise ValueError('RELOAD_IDENTITY_MISMATCH')
    return copy.deepcopy(snapshot['selection'])

def resolve_authority(manifest, authorities, responsibility, cached_hint=None):
    """Cached hints/comments never select authority; no live-document claims."""
    if manifest.get('status')!='ACTIVE' or manifest.get('resolution_policy')!='MANIFEST_FIRST':
        raise ValueError('AUTHORITY_MANIFEST_FIRST')
    ref=manifest['current'][responsibility]
    matches=[a for a in authorities if a['authority_id']==ref and a['status']=='CURRENT']
    if len(matches)!=1: raise ValueError('UNKNOWN_AUTHORITY')
    return copy.deepcopy(matches[0])

def validate_evidence_acceptance(b):
    return validate_evidence(b['field_evidence'], b['root'])

def validate_carport_authority(b):
    return carport_authority.validate(b['root'], fields=b['fields'])

def validate_formal_promotion(b):
    # Trusted origin is determined by the snapshot container, never a Field flag.
    records=[(f,'APPLICATION_FIELD') for f in b['fields']]
    records += [(f,'CONTRACT_REFERENCE') for f in b['references']]
    records += [(x['contract'],'APPLICATION_FIELD') for x in b.get('presentation_fixtures',[])]
    gates={name:fn(b) for name,fn in VALIDATORS.items() if name not in {'evidence-acceptance','formal-promotion'}}
    return validate_promotion(b['promotion_policy'],b['field_evidence'],b['field_promotions'],records,b['root'],
                              gates,{m['field_id']:m for m in b['mapping']['fields']},
                              exception_records=b['exceptions']['exceptions'])

LAYERS={
    'schema':['SCHEMA'], 'mapping':['STATIC','UNIT TEST'], 'selection-contract':['SCHEMA','STATIC','UNIT TEST'],
    'dependency':['STATIC','UNIT TEST'], 'reset':['SCHEMA','STATIC','UNIT TEST','BROWSER TEST'],
    'ui-standard':['SCHEMA','STATIC','UNIT TEST','BROWSER TEST'], 'category-flow':['SCHEMA','STATIC','UNIT TEST','BROWSER TEST'],
    'exceptions':['SCHEMA','STATIC','UNIT TEST'], 'authority':['STATIC','UNIT TEST'],
    'coverage':['STATIC','UNIT TEST'], 'output':['STATIC','UNIT TEST','BROWSER TEST'],
    'presentation-resolution':['SCHEMA','STATIC','UNIT TEST'],
    'evidence-acceptance':['SCHEMA','STATIC','UNIT TEST'], 'formal-promotion':['SCHEMA','STATIC','UNIT TEST']}
VALIDATORS={'schema':validate_schema,'mapping':validate_mapping,'selection-contract':validate_selection_contract,
            'dependency':validate_dependency,'reset':validate_reset,'ui-standard':validate_ui_standard,
            'category-flow':validate_category_flow,'exceptions':validate_exceptions,'authority':validate_authority,
            'coverage':validate_coverage,'output':validate_output,
            'presentation-resolution':validate_presentation,
            'evidence-acceptance':validate_evidence_acceptance,'formal-promotion':validate_formal_promotion,
            'carport-authority':validate_carport_authority}

def validate_bundle(b, only=None):
    results={name:fn(b) for name,fn in VALIDATORS.items() if only is None or name==only}
    return {'status':'FAIL' if any(results.values()) else 'PASS',
            'error_count':sum(len(v) for v in results.values()),'validators':results,
            'browser_tests':'CONTRACT_ONLY_NOT_RUN','layers':LAYERS}
