import json
from pathlib import Path
from carport_authority import schemas
root=Path(__file__).resolve().parents[1]
for name,schema in schemas().items():
 (root/'schemas'/f'{name}.schema.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2)+'\n')
