import subprocess
import sys
from pathlib import Path

sys.exit(subprocess.call([sys.executable, str(Path(__file__).with_name('validate.py')),
                          '--only', 'formal-promotion', *sys.argv[1:]]))
