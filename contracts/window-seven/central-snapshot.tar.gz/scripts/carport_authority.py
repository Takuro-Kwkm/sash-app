"""Opt-in normative carport responsibility/derivation/semantic authority.

Manufacturer facts and application behavior never originate in these contracts.
Old observed mapping and accepted promotion history are preserved.
"""
import json
from pathlib import Path
from jsonschema import Draft202012Validator
from formal_promotion import resolve_ref

PATHS={'responsibility':'registries/carport/field-responsibility.v0.1.json','derivation':'registries/carport/derivation.v0.1.json','semantic':'registries/carport/semantic-mapping.v0.1.json'}
RESP_REQUIRED=['canonical_key','canonical_field_id','canonical_meaning','semantic_role','owner','input_actor','confirmation_actor','applicability','required_condition','default_state','reset_condition','dependency','output_responsibility','quotation_inclusion','quotation_exclusion','persistence_responsibility','unknown_behavior','hold_behavior','lifecycle_scope','units','allowed_values','value_binding_policy']
DERIVE_REQUIRED=['field_id','product','source_inputs','source_authority','units','table_formula','lookup_precedence','variant_applicability','reinforcement_rules','conflict_precedence','missing_data_behavior','unknown_behavior','hold_behavior','invalidation_rules','output_scope','lifecycle_scope','result_provenance_required','current_runtime_certification']

def load(root):
 root=Path(root)
 return {k:json.loads((root/p).read_text()) for k,p in PATHS.items()}|{'manifest':json.loads((root/'authority/carport/manifest.v0.1.json').read_text())}

def schemas():
 string={'type':'string','minLength':1,'pattern':'\\S'}
 def row(required):return {'type':'object','required':required,'properties':{k:({'type':'string','minLength':1} if k not in ['default_state','dependency','quotation_exclusion','allowed_values','units','source_inputs','lookup_precedence','result_provenance_required','current_runtime_certification','allowed_mapping','prohibited_mapping','derivation','application_change_required'] else {}) for k in required},'additionalProperties':True}
 def doc(contract,r):return {'$schema':'https://json-schema.org/draft/2020-12/schema','type':'object','required':['contract_id','version','status','category','rules','source_authorities'],'properties':{'contract_id':{'const':contract},'version':{'const':'0.1'},'status':{'const':'FORMAL'},'category':{'const':'carport'},'rules':{'type':'array','minItems':1,'items':r},'source_authorities':{'type':'array','minItems':1}},'additionalProperties':True}
 return {'carport-responsibility':doc('CARPORT_FIELD_RESPONSIBILITY_CONTRACT',row(RESP_REQUIRED)),
 'carport-derivation':doc('CARPORT_DERIVATION_CONTRACT',row(DERIVE_REQUIRED)),
 'carport-semantic':doc('CARPORT_SEMANTIC_MAPPING_CONTRACT',row(['field_id','product','source_meaning','canonical_meaning','identity','allowed_mapping','prohibited_mapping','derivation','application_change_required','historical_rejections','promotion_current_mapping']))}

def validate(root, data=None, fields=()):
 root=Path(root);data=data or load(root);errors=[]
 def fail(code,path,message):errors.append({'code':code,'path':path,'message':message})
 for name,contract in [('responsibility','CARPORT_FIELD_RESPONSIBILITY_CONTRACT'),('derivation','CARPORT_DERIVATION_CONTRACT'),('semantic','CARPORT_SEMANTIC_MAPPING_CONTRACT')]:
  d=data[name]
  for err in Draft202012Validator(schemas()['carport-'+name]).iter_errors(d):fail('CARPORT_AUTHORITY_SCHEMA',PATHS[name]+'/'+str(list(err.absolute_path)),err.message)
  for source in d.get('source_authorities',[]):
   try:
    if source['path'].startswith(('src/','test-results/')):raise ValueError('Runtime/UI cannot create normative authority')
    resolve_ref(root,source)
   except (ValueError,KeyError,OSError) as e:fail('CARPORT_AUTHORITY_SOURCE',PATHS[name],str(e))
 manifest=data['manifest']
 if manifest.get('status')!='ACTIVE' or manifest.get('adoption')!='EXPLICIT_FIXED_SNAPSHOT_ONLY':fail('CENTRAL_AUTHORITY_BYPASS','manifest','Explicit central snapshot adoption required')
 for identity in manifest.get('contracts',{}).values():
  try:resolve_ref(root,identity)
  except (ValueError,OSError,KeyError) as e:fail('CARPORT_AUTHORITY_HASH','manifest',str(e))
 rules=data['responsibility']['rules'];rule_map={x['canonical_field_id']:x for x in rules}
 if len(rules)!=len(rule_map):fail('DUPLICATE_RESPONSIBILITY','responsibility','Define a shared concept only once')
 bindings=data['responsibility'].get('bindings',[]);seen=set();field_map={x['field_id']:x for x in fields}
 for b in bindings:
  key=b.get('field_id','');rule=rule_map.get(b.get('canonical_field_id'));field=field_map.get(key)
  if key in seen:fail('DUPLICATE_BINDING',key,'One rule binding per Field')
  seen.add(key)
  if not rule or b.get('owner')!='SALES_OPERATIONS' or rule.get('owner')!='SALES_OPERATIONS':fail('WRONG_RESPONSIBILITY_OWNER',key,'Business field owned by sales operations')
  if field and (field['scope']['product']!=b['product'] or field['semantic_role']!=b['semantic_role'] or 'carport:'+field['canonical_key']!=b['canonical_field_id']):fail('RESPONSIBILITY_SCOPE',key,'Field/product/role binding mismatch')
 for rule in rules:
  if rule.get('input_actor')!='SALES_OPERATOR' or not rule.get('confirmation_actor') or 'NO_DEFAULT_TRUE_OR_ZERO' not in rule.get('unknown_behavior',''):fail('RESPONSIBILITY_ACTOR_OR_UNKNOWN',rule.get('canonical_field_id',''),'Actors and unconfirmed behavior must be explicit')
  if not isinstance(rule.get('default_state'),dict) or rule['default_state'].get('evidence_state')!='UNCONFIRMED':fail('RESPONSIBILITY_DEFAULT',rule.get('canonical_field_id',''),'No implicit verified defaults')
 for rule in data['derivation']['rules']:
  if not all(rule.get(k) for k in DERIVE_REQUIRED if k!='current_runtime_certification') or rule.get('current_runtime_certification') is not False:fail('INCOMPLETE_DERIVATION',rule.get('field_id',''),'Complete scoped derivation authority; no certification from runtime')
  if rule.get('table_formula')!='EXACT_SCOPED_ROW_LOOKUP; NO_INFERRED_CAPACITY_OR_LINEAR_PERFORMANCE_INTERPOLATION':fail('UNSUPPORTED_DERIVATION',rule.get('field_id',''),'No inferred formula')
  if rule.get('source_authority','').startswith(('Runtime','UI')):fail('RUNTIME_AS_AUTHORITY',rule.get('field_id',''),'Runtime/UI are consumers')
 for rule in data['semantic']['rules']:
  if rule.get('source_meaning')=='base_body_class' and rule.get('canonical_meaning')=='vehicle_capacity' and (rule.get('identity')!='NON_IDENTITY' or not rule.get('application_change_required')):fail('BODY_CAPACITY_FALSE_EQUIVALENCE',rule.get('field_id',''),'Different concepts require application change')
  if 'alias_only' not in rule.get('prohibited_mapping',[]):fail('SEMANTIC_ALIAS_ONLY',rule.get('field_id',''),'An alias supplies no equivalence proof')
 import body_class_adoption
 return errors+body_class_adoption.validate(root,fields)

def evidence_binding_errors(candidate, data, root, fields):
 """Independent semantic/authority review before any Human activation."""
 errors=[];fid=candidate['field_id'];claim=candidate['claim'];product=candidate['product']
 field=next((x for x in fields if x['field_id']==fid),None)
 if not field or field['scope']['product']!=product:errors.append('WRONG_PRODUCT_SCOPE')
 if candidate.get('source_class') in ['VERIFIED_RUNTIME_BEHAVIOR','UI_OBSERVATION'] or candidate['source_ref']['path'].startswith(('src/','test-results/')):errors.append('RUNTIME_UI_AS_AUTHORITY')
 if candidate.get('source_status')!='CURRENT':errors.append('STALE_SOURCE')
 try:resolve_ref(root,candidate['source_ref'])
 except (ValueError,KeyError,OSError,IndexError):errors.append('SOURCE_HASH_OR_POINTER')
 if claim=='FIELD_RESPONSIBILITY':
  matches=[b for b in data['responsibility']['bindings'] if b['field_id']==fid and b['product']==product]
  if len(matches)!=1 or matches[0]['owner']!='SALES_OPERATIONS':errors.append('WRONG_RESPONSIBILITY_OWNER')
  if candidate.get('central_contract_id')!='CARPORT_FIELD_RESPONSIBILITY_CONTRACT':errors.append('CENTRAL_AUTHORITY_BYPASS')
 if claim=='DERIVATION_AUTHORITY':
  matches=[r for r in data['derivation']['rules'] if r['field_id']==fid and r['product']==product]
  if len(matches)!=1 or not all(matches[0].get(k) for k in DERIVE_REQUIRED if k!='current_runtime_certification'):errors.append('INCOMPLETE_DERIVATION')
  if candidate.get('central_contract_id')!='CARPORT_DERIVATION_CONTRACT':errors.append('CENTRAL_AUTHORITY_BYPASS')
 if candidate.get('mapping_method')=='ALIAS_ONLY' or candidate.get('body_capacity_identity'):errors.append('BODY_CAPACITY_FALSE_EQUIVALENCE')
 return errors
