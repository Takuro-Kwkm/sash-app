"""Compare individual passing identities; a larger total alone proves no preservation."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
previous = json.loads((ROOT / 'docs/evidence/promotion-previous-156-tests.json').read_text())
current = json.loads(Path(sys.argv[1]).read_text())
missing = sorted(set(previous['passed']) - set(current['passed']))
result = {'previous_test_count': len(previous['passed']), 'preserved_pass_count': len(previous['passed']) - len(missing),
          'missing_or_not_passing': missing, 'status': 'PASS' if not missing and current['status'] == 'PASS' else 'FAIL'}
print(json.dumps(result, indent=2))
if len(sys.argv) > 2:
    Path(sys.argv[2]).write_text(json.dumps(result, indent=2) + '\n')
sys.exit(0 if result['status'] == 'PASS' else 1)
