import sys
import runpy
from pathlib import Path
sys.argv[1:1] = ["--only", "output"]
runpy.run_path(str(Path(__file__).with_name("validate.py")), run_name="__main__")
