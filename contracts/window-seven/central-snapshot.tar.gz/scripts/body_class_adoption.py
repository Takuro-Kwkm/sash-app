"""Exact, opt-in semantic adoption; old audit and rejected payloads are immutable."""
import json
from pathlib import Path
from formal_promotion import digest, resolve_ref
PATH='authority/carport/body-class-adoption.v0.1.json'

def load(root):
    path=Path(root)/PATH
    return json.loads(path.read_text()) if path.exists() else None

def mapping_is_adopted(bundle, row):
    adoption=load(bundle['root'])
    if not adoption:return False
    matches=[b for b in adoption['bindings'] if b['field_id']==row.get('field_id')]
    if len(matches)!=1:return False
    binding=matches[0]
    field=next((f for f in bundle['fields'] if f['field_id']==row['field_id']),None)
    if not field:return False
    if digest({k:v for k,v in field.items() if k!='status'})!=binding['adopted_runtime_identity_sha256']:return False
    keys=['field_id','app','product','category','runtime_key','canonical_key','canonical_target','semantic_role','mapping_type']
    return all(row.get(k)==binding[k] for k in keys)

def validate(root, fields=()):
    adoption=load(root)
    if not adoption:return []
    errors=[]
    def fail(code,message):errors.append({'code':code,'path':PATH,'message':message})
    if adoption.get('contract_id')!='CARPORT_BODY_CLASS_SEMANTIC_ADOPTION' or adoption.get('status')!='FORMAL':fail('BODY_CLASS_ADOPTION_AUTHORITY','Wrong contract identity')
    expected={'exterior-estimator:nesca:vehicle_capacity':'base_body_class','exterior-estimator:fugo:vehicle_capacity':'car_capacity'}
    if {b['field_id']:b['runtime_key'] for b in adoption['bindings']}!=expected or len(adoption['bindings'])!=2:fail('BODY_CLASS_ADOPTION_SCOPE','Exactly the two authorized legacy selectors required')
    for ref in adoption['source_authorities']:
        try:resolve_ref(root,ref)
        except (OSError,ValueError,KeyError):fail('BODY_CLASS_ADOPTION_SOURCE','Normative source bytes/pointer mismatch')
    for b in adoption['bindings']:
        old=b['before_contract'];new=b['adopted_provisional_contract']
        if digest(old)!=b['before_sha256'] or digest({k:v for k,v in new.items() if k!='status'})!=b['adopted_runtime_identity_sha256']:fail('BODY_CLASS_ADOPTION_HASH','Contract digest mismatch')
        if new.get('canonical_key')!='body_class' or b['canonical_target']!='carport.body_class' or new.get('status')!='PROVISIONAL':fail('BODY_CAPACITY_FALSE_EQUIVALENCE','This adoption is body class only; no completed capacity or promotion')
        if {k:v for k,v in old.items() if k not in ['canonical_key','semantic_role']}!={k:v for k,v in new.items() if k not in ['canonical_key','semantic_role']}:fail('BODY_CLASS_ADOPTION_OVERREACH','Only canonical meaning and role may change')
        field=next((f for f in fields if f['field_id']==b['field_id']),None)
        if field and field['canonical_key']=='body_class' and digest({k:v for k,v in field.items() if k!='status'})!=b['adopted_runtime_identity_sha256']:fail('BODY_CLASS_APPLICATION_DRIFT','Application field differs from adopted exact payload')
    return errors
