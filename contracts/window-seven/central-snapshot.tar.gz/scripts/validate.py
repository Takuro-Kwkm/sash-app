import argparse
import json
import sys
from pathlib import Path
from contracts import ROOT, VALIDATORS, load_bundle, validate_bundle

parser=argparse.ArgumentParser(description='Validate local product UI contract snapshot')
parser.add_argument('--root',type=Path,default=ROOT)
parser.add_argument('--only',choices=list(VALIDATORS))
parser.add_argument('--report',type=Path)
args=parser.parse_args()
try:
    result=validate_bundle(load_bundle(args.root),args.only)
except Exception as error:
    result={'status':'FAIL','error_count':1,'fatal':str(error)}
serialized=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
if args.report:
    args.report.parent.mkdir(parents=True,exist_ok=True)
    args.report.write_text(serialized)
print(serialized)
sys.exit(0 if result['status']=='PASS' else 1)
