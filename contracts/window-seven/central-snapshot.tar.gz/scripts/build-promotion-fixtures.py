"""Reproduce reference certifications and adversarial governance fixtures.

Never promotes application baseline fields. Reference certificates attest only
the already adopted normative handoff examples, not manufacturer product facts.
"""
import copy
import hashlib
import json
import tempfile
from pathlib import Path
from formal_promotion import (VERSION, SOURCE_CLASSES, STRONG, COMMON, CLAIM_SOURCES, GATES, digest,
                             acceptance_payload, approval_payload, schemas, CLASSIFICATION, runtime_identity)

ROOT = Path(__file__).resolve().parents[1]

def write(root, path, value):
    p = root / path; p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def ref(root, path, pointer=''):
    return {'path': path, 'pointer': pointer, 'sha256': hashlib.sha256((root / path).read_bytes()).hexdigest()}

def certify(root, fields, mappings, purpose, source_specs, fact_kind, prefix):
    """Explicit fixture builder; callers supply scoped source and review decisions.

    App callers live only under tests/temp roots, never the central adoption data.
    """
    authorities = []; evidence = []; dossiers = []
    review_id = prefix + '-ACCEPTANCE-REVIEW'; approval_id = prefix + '-PROMOTION-REVIEW'
    acceptance_path = 'authority/' + prefix.lower() + '-evidence-decisions.v0.1.json'
    approval_path = 'authority/' + prefix.lower() + '-promotion-decisions.v0.1.json'
    for source_id, source_class, source_ref, claims in source_specs:
        authorities.append({'authority_id': source_id, 'kind': 'EVIDENCE_SOURCE', 'status': 'CURRENT',
                            'identity': source_ref, 'source_classes': [source_class], 'purposes': [purpose]})
    for i, f in enumerate(fields):
        fid = f['field_id']; classification = CLASSIFICATION[mappings[fid]['mapping_type']]
        eids = []
        for j, (source_id, source_class, source_ref, claims) in enumerate(source_specs):
            eid = prefix + '-E-' + str(i) + '-' + str(j); eids.append(eid)
            evidence.append({'evidence_id': eid, 'source_class': source_class, 'source_authority': source_id,
                             'source_identifier': source_id, 'document_version': VERSION,
                             'page_or_section': source_ref['pointer'] or 'whole document; scoped review below',
                             'captured_date': '2026-10-04', 'verification_state': 'VERIFIED', 'status': 'ACCEPTED',
                             'source_ref': source_ref, 'scope': {'field_id': fid, 'category': f['category'], 'purpose': purpose},
                             'claims': claims, 'review': {'authority_id': review_id, 'decision_id': eid + '-ACCEPT',
                                                       'decision_ref': {}}})
        previous = copy.deepcopy(f)
        if purpose == 'APPLICATION_FIELD': previous['status'] = 'PROVISIONAL'
        dossier = {'dossier_id': prefix + '-D-' + str(i), 'field_id': fid, 'category': f['category'],
                   'purpose': purpose, 'fact_kind': fact_kind, 'mapping_classification': classification,
                   'mapping_rationale': 'Registered mapping identity and adopted semantic/contract responsibilities; scoped evidence review.',
                   'evidence_ids': eids, 'approval_id': prefix + '-A-' + str(i), 'contract_sha256': digest(f),
                   'transition': {'from': previous['status'], 'to': 'FORMAL',
                                  'operation': 'REFERENCE_CERTIFICATION' if purpose == 'CONTRACT_REFERENCE' else 'STATUS_TRANSITION',
                                  'reason': 'Certify adopted schema reference only.' if purpose == 'CONTRACT_REFERENCE' else 'SYNTHETIC TEST promotion; not application adoption.',
                                  'previous_contract': previous, 'previous_contract_sha256': digest(previous)}}
        if classification == 'PRODUCT_SPECIFIC':
            dossier['product_specific'] = {'reason': 'Distinct scoped product responsibility.',
                                          'why_global_role_insufficient': 'Global identity alone does not describe this scoped concept.',
                                          'owner': approval_id, 'source': source_specs[0][0],
                                          'status': 'REVIEWED', 'review_condition': 'Reevaluate on source or semantic meaning change.'}
        dossiers.append(dossier)
    decisions = [{'decision_id': e['review']['decision_id'], 'status': 'APPROVED', 'payload': acceptance_payload(e)} for e in evidence]
    write(root, acceptance_path, {'version': VERSION,
          'scope': 'SCHEMA_REFERENCE_CERTIFICATION_NOT_PRODUCT_FACT_OR_APP_ADOPTION' if purpose == 'CONTRACT_REFERENCE' else 'SYNTHETIC_TEST_ONLY',
          'basis': 'Existing explicit Human Review and fixed audit; no new manufacturer evidence inferred.', 'decisions': decisions})
    for i, e in enumerate(evidence): e['review']['decision_ref'] = ref(root, acceptance_path, '/decisions/' + str(i))
    authorities.append({'authority_id': review_id, 'kind': 'REVIEW_AUTHORITY', 'status': 'CURRENT',
                        'identity': ref(root, acceptance_path), 'source_classes': [], 'purposes': [purpose]})
    approvals = []
    for d in dossiers:
        selected = [e for e in evidence if e['evidence_id'] in d['evidence_ids']]
        approvals.append({'approval_id': d['approval_id'], 'field_id': d['field_id'], 'category': d['category'],
                          'purpose': purpose, 'status': 'APPROVED', 'contract_sha256': d['contract_sha256'],
                          'evidence_sha256': digest(selected), 'dossier_sha256': digest(d),
                          'review': {'authority_id': approval_id, 'decision_id': d['approval_id'] + '-APPROVE', 'decision_ref': {}}})
    write(root, approval_path, {'version': VERSION,
          'scope': 'SCHEMA_REFERENCE_CERTIFICATION_NOT_PRODUCT_FACT_OR_APP_ADOPTION' if purpose == 'CONTRACT_REFERENCE' else 'SYNTHETIC_TEST_ONLY',
          'decisions': [{'decision_id': a['review']['decision_id'], 'status': 'APPROVED', 'payload': approval_payload(a)} for a in approvals]})
    for i, a in enumerate(approvals): a['review']['decision_ref'] = ref(root, approval_path, '/decisions/' + str(i))
    authorities.append({'authority_id': approval_id, 'kind': 'REVIEW_AUTHORITY', 'status': 'CURRENT',
                        'identity': ref(root, approval_path), 'source_classes': [], 'purposes': [purpose]})
    return {'version': VERSION, 'authorities': authorities, 'evidence': evidence}, {'version': VERSION, 'approvals': approvals, 'dossiers': dossiers, 'blockers': []}

def main():
    policy = {'version': VERSION, 'package_version': '0.3.0', 'states': ['PROVISIONAL', 'FORMAL'],
              'common_claims': COMMON, 'source_classes': SOURCE_CLASSES, 'product_fact_sources': STRONG,
              'claim_source_classes': CLAIM_SOURCES,
              'validator_gates': GATES, 'mapping_claims': {'EXACT': ['MAPPING'], 'SEMANTIC': ['MAPPING', 'MEANING_EQUIVALENCE'],
                                                       'PRODUCT_SPECIFIC': ['MAPPING', 'PRODUCT_SPECIFIC_IDENTITY']},
              'lifecycle': [['PROVISIONAL', 'FORMAL'], ['FORMAL', 'PROVISIONAL']],
              'reference_scope': 'SCHEMA_REFERENCE_ONLY_NOT_APPLICATION_ADOPTION'}
    write(ROOT, 'registries/formal-promotion/governance.v0.1.json', policy)
    for name, shape in schemas().items():
        shape.update({'$schema': 'https://json-schema.org/draft/2020-12/schema',
                      '$id': 'https://product-ui-contracts.local/schemas/' + name + '.schema.json'})
        write(ROOT, 'schemas/' + name + '.schema.json', shape)
    fields = [json.loads(p.read_text()) for p in sorted((ROOT / 'fixtures/formal').glob('*.json'))]
    mappings = {m['field_id']: m for m in json.loads((ROOT / 'mappings/field-mapping-baseline.v0.1.json').read_text())['fields']}
    specs = [('ADOPTED-CONTRACT-AUTHORITY', 'CONTRACT_AUTHORITY', ref(ROOT, 'authority/human-review-adoption.v0.1.json'), COMMON),
             ('FIXED-AUDITED-MAPPING', 'AUDITED_MAPPING', ref(ROOT, 'authority/audit/FIELD_INVENTORY.json'),
              ['SEMANTIC_IDENTITY', 'MAPPING', 'MEANING_EQUIVALENCE', 'PRODUCT_SPECIFIC_IDENTITY'])]
    evidence, promotion = certify(ROOT, fields, mappings, 'CONTRACT_REFERENCE', specs, 'REFERENCE_CONTRACT', 'REFERENCE-CERTIFICATION')
    write(ROOT, 'authority/field-evidence-acceptance.v0.1.json', evidence)
    write(ROOT, 'authority/field-promotion-approvals.v0.1.json', promotion)
    negatives = [
        ('FORMAL-WITHOUT-EVIDENCE', 'no_evidence', 'PROMOTION_SCHEMA'),
        ('FORMAL-INSUFFICIENT-EVIDENCE', 'insufficient', 'FORMAL_EVIDENCE_NOT_ACCEPTED'),
        ('FORMAL-CONFLICTING-EVIDENCE', 'conflicting', 'UNRESOLVED_PROMOTION_BLOCKER'),
        ('MALFORMED-EVIDENCE', 'malformed', 'PROMOTION_SCHEMA'),
        ('INVALID-APPROVAL', 'invalid_approval', 'INVALID_PROMOTION_APPROVAL'),
        ('UNRESOLVED-BLOCKER', 'blocker', 'UNRESOLVED_PROMOTION_BLOCKER'),
        ('ILLEGAL-TRANSITION', 'illegal_transition', 'ILLEGAL_PROMOTION_TRANSITION'),
        ('UNKNOWN-EVIDENCE-CLASS', 'unknown_class', 'PROMOTION_SCHEMA'),
        ('INVALID-EVIDENCE-REFERENCE', 'invalid_reference', 'INVALID_EVIDENCE_REFERENCE'),
        ('UNVERIFIED-ACCEPTED-EVIDENCE', 'unverified', 'EVIDENCE_NOT_VERIFIED'),
        ('SELF-DECLARED-FORMAL', 'self_declaration', 'FORMAL_PROMOTION_REQUIRED'),
        ('MAPPING-UNRESOLVED', 'mapping', 'PROMOTION_MAPPING_MISMATCH'),
        ('SEMANTIC-GATE-FAILED', 'semantic_gate', 'PROMOTION_GATE_FAILED'),
        ('EXCEPTION-GATE-FAILED', 'exception_gate', 'PROMOTION_GATE_FAILED'),
        ('PRESENTATION-GATE-FAILED', 'presentation_gate', 'PROMOTION_GATE_FAILED'),
        ('DEPENDENCY-GATE-FAILED', 'dependency_gate', 'PROMOTION_GATE_FAILED'),
        ('UNKNOWN-PROMOTION-STATE', 'unknown_state', 'PROMOTION_SCHEMA'),
        ('PRODUCT-HARDCODE', 'product_hardcode', 'PROMOTION_SCHEMA'),
        ('RUNTIME-AS-PRODUCT-FACT', 'runtime_fact', 'INSUFFICIENT_PRODUCT_FACT_AUTHORITY'),
        ('REFERENCE-AS-APPLICATION', 'reference_application', 'PROMOTION_SCOPE_MISMATCH'),
        ('MISSING-SEMANTIC-EQUIVALENCE', 'semantic_evidence', 'FORMAL_REQUIREMENTS_UNMET'),
        ('MISSING-PRODUCT-SPECIFIC-REASON', 'specific_reason', 'PRODUCT_SPECIFIC_PROMOTION_GOVERNANCE'),
        ('WRONG-EVIDENCE-SCOPE', 'scope', 'EVIDENCE_SCOPE_MISMATCH'),
        ('STALE-APPROVAL', 'stale_approval', 'INVALID_PROMOTION_APPROVAL'),
        ('STALE-CONTRACT', 'stale_contract', 'FORMAL_PROMOTION_REQUIRED'),
        ('STALE-SOURCE-HASH', 'source_hash', 'INVALID_EVIDENCE_REFERENCE'),
        ('HIDDEN-CONFLICT', 'hidden_conflict', 'UNRESOLVED_PROMOTION_BLOCKER'),
        ('DUPLICATE-EVIDENCE', 'duplicate_evidence', 'DUPLICATE_EVIDENCE_ID'),
        ('DUPLICATE-DOSSIER', 'duplicate_dossier', 'DUPLICATE_PROMOTION_DOSSIER'),
        ('UNAPPROVED-EVIDENCE', 'acceptance', 'INVALID_EVIDENCE_ACCEPTANCE'),
        ('SEMANTIC-CHANGE-DURING-PROMOTION', 'semantic_change', 'PROMOTION_CONTRACT_MUTATION'),
        ('MISSING-RUNTIME-PARITY', 'runtime_missing', 'FORMAL_REQUIREMENTS_UNMET')]
    write(ROOT, 'fixtures/promotion-negative.v0.1.json', {'version': VERSION,
          'cases': [{'fixture_id': fid, 'mutation': mutation, 'expected_error': code} for fid, mutation, code in negatives]})
    # Positive fixture contains all cached artifacts; real adoption registries never
    # include its fictional official source or fictional review decisions.
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory); field = copy.deepcopy(fields[0])
        field.update(field_id='fixture-app:generic-item:choice', status='FORMAL')
        field['scope'] = {'app': 'fixture-app', 'product': 'generic-item', 'kind': 'APPLICATION_FIELD'}
        mapped = {k: field[k] for k in ['field_id', 'category', 'semantic_role', 'runtime_key', 'canonical_key']}
        mapped.update(app=field['scope']['app'], product=field['scope']['product'], mapping_type='exact match')
        mapping = {field['field_id']: mapped}
        write(root, 'fixtures/synthetic-authority.json', {'scope': 'SYNTHETIC_TEST_ONLY',
              'official_fact': 'fictional choice', 'meaning': 'fixture semantic meaning', 'rules': 'fixture responsibility'})
        write(root, 'fixtures/synthetic-runtime.json', {'scope': 'SYNTHETIC_TEST_ONLY', 'field_id': field['field_id'],
              'runtime_identity_sha256': runtime_identity(field), 'runtime_parity': 'PASS', 'flow_parity': 'PASS'})
        claims = COMMON + ['PRODUCT_FACT', 'FIELD_RESPONSIBILITY', 'DERIVATION_AUTHORITY', 'MEANING_EQUIVALENCE', 'PRODUCT_SPECIFIC_IDENTITY']
        specs = [('SYNTHETIC-OFFICIAL', 'OFFICIAL_PRIMARY_SOURCE', ref(root, 'fixtures/synthetic-authority.json'), claims),
                 ('SYNTHETIC-RUNTIME', 'VERIFIED_RUNTIME_BEHAVIOR', ref(root, 'fixtures/synthetic-runtime.json'), ['RUNTIME_PARITY'])]
        evidence, promotions = certify(root, [field], mapping, 'APPLICATION_FIELD', specs, 'PRODUCT_FACT', 'SYNTHETIC')
        write(ROOT, 'fixtures/promotion-positive.v0.1.json', {'version': VERSION,
              'scope': 'SYNTHETIC_TEST_ONLY_NOT_PRODUCT_EVIDENCE', 'field': field, 'mapping': mapping,
              'evidence': evidence, 'promotions': promotions,
              'files': {str(p.relative_to(root)): json.loads(p.read_text()) for p in sorted(root.rglob('*.json'))},
              'cases': [{'case_id': 'A', 'state': 'PROVISIONAL', 'action': 'REMOVE_FORMAL_RECORDS', 'expected': 'VALID'},
                        {'case_id': 'B', 'state': 'FORMAL', 'action': 'COMPLETE_ACCEPTED_EVIDENCE_AND_APPROVAL', 'expected': 'VALID'},
                        {'case_id': 'C', 'state': 'FORMAL', 'action': 'INSUFFICIENT_EVIDENCE', 'expected': 'BLOCKED'},
                        {'case_id': 'D', 'state': 'FORMAL', 'action': 'ADD_ACCEPTED_EVIDENCE_AND_APPROVAL', 'expected': 'ELIGIBLE'}]})
    print(json.dumps({'reference_certifications': len(fields), 'application_promotions': 0, 'negative_fixtures': len(negatives)}))

if __name__ == '__main__': main()
