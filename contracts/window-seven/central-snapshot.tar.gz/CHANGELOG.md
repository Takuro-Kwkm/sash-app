# Changelog

## Carport Field Closure Authority 0.1 — 2026-10-06

- Add category-level responsibility rules with 39 Field bindings, three exact-source derivation responsibilities, and body-class/capacity non-identity authority.
- Add explicit content-bound central manifest, three schemas, a normative validator and 13 adversarial/positive tests.
- Preserve Selection/Governance v0.1, Foundation 0.3.0 policy, observed audit mapping and all previous Evidence/Promotion records. Consumer adoption requires a separately pinned merged snapshot; manufacturer facts and Human Evidence/Promotion decisions remain separate.

## 0.3.0 — 2026-10-04 (PR candidate; merge not authorized)

- Add generic Evidence Acceptance / Field Formal Promotion Governance v0.1, three standalone schemas, independent content-bound evidence decisions and promotion approvals.
- PROVISIONAL requires no additional evidence. FORMAL requires accepted scoped evidence, approved status-only transition, mapping-class-specific proof, Runtime/Flow evidence for application Fields, and all existing validator gates.
- Preserve existing 492 PROVISIONAL contracts and five FORMAL schema reference contracts byte-for-byte. Add explicit reference-only certificates; they cannot authorize application adoption or manufacturer product facts.
- Add 32 named adversarial fixtures, machine-readable positive A–D fixtures, stronger reference/approval/Runtime identity tests, and individual preservation checks for all 156 previous tests.
- **BREAKING (validator acceptance, 0.x next MINOR):** a new APPLICATION_FIELD claiming FORMAL without a separately registered, scoped evidence decision and promotion approval now fails. No Selection / Presentation schema property changes; old snapshot bytes/validators remain unchanged.
- Migration: review and merge this central PR separately; explicitly adopt its new fixed snapshot, preserve provisional status, add authoritative evidence/approval records, migrate consumer status-baseline guards, then reevaluate each Field. Never auto-adopt central main.
- Exterior PR #19 audit preserved on main; Exterior 101 Field statuses/mappings are unchanged. Product Master / Runtime / UI / Production mutations are zero. Production identity remains UNVERIFIED.

## 0.2.0 — 2026-10-04 (PR candidate)

- Add opt-in Presentation Resolution v0.1 and standalone/embedded Draft 2020-12 schema; Selection API v0.1 existing contracts remain valid.
- Keep semantic identity and audited primary Control unchanged; resolve state-dependent Presentation through explicit generic rules.
- Define applicability/status guards, override/rule/default/fallback precedence, interval conflicts, complete candidate-domain coverage and Category permission validation.
- Reject zero-choice Select, unknown conditions/modes, hardcoded product/Field predicates, unresolved state, malformed policy and illegal combinations.
- Add FOUNDATION_GAP-001 minimal Fugo fixture, 20 negative fixtures and preservation checks for every original 110 Test ID.
- No baseline Field migration, Formal promotion, app Runtime/UI change, Product Master change, merge or deploy. Exterior Pilot remains BLOCKED until merge and a separate fixed-snapshot Pilot rerun.
- MINOR package release for backward-compatible opt-in feature; no BREAKING change to existing v0.1 contracts. Older fixed snapshots do not understand the new opt-in property.

## 0.1.0 — 2026-10-03

- Fixed audit authority: REGISTRY_DESIGN_READY PASS, 581 Fields, three pinned main SHAs.
- Explicit Human Review adoption: 14 Global Formal rules, 5 Formal Category flows.
- 13 Draft 2020-12 JSON Schemas, 291 observed semantic roles, 581 Mapping baseline.
- 492 provisional current Field contracts and 5 Formal reference contracts; no app migration.
- 648 exact dependency boundaries, 79 pending source records; retain all 727 observations.
- 6 Exception records: 1 Temporary V-rail reset, 1 Legacy, 4 Retired responsibility/adoption candidates.
- 11 validators, adversarial fixtures, unit behavior checks, CI foundation and fixed snapshot contract.
- 75 UNKNOWN, 85 Legacy exclusions, 2 not-formalized Categories and Exterior enforcement evidence gate retained.
- Initial central contract API. No existing application breaking change, Runtime/UI patch, merge or deploy.

All later breaking schema/role/flow/reset/control changes must use an explicit BREAKING entry, affected scope and migration instructions, including during 0.x.
