# Product UI Contracts Foundation v0.1

営業見積用のサッシ・エクステリア・インテリア3アプリが参照する、機械可読UI契約の中央Authority。採用元は固定監査snapshotと2026-10-03の明示的Human Review判断。既存アプリのRenderer・Runtime・UI・Productionを変更するRepositoryではない。

メーカー公式資料 → Product Master / Product Fact → Selection Contract → UI Standard + Category Flow + Exceptions → Renderer / Flow Engine → Application UI → CI / Browser QA の責務を分ける。

| 所有者 | 責務 |
|---|---|
| Product Master / Product Fact | 商品の候補・仕様・AllowedValue・製作範囲。価格/BOM等の製品事実もここに属する |
| Selection Contract | Fieldの意味、Runtime/Canonical対応、監査Control固定と任意のPresentation解決、依存、UIへの引渡し |
| UI Standard | ラベル/値、Placeholder、再評価、保持/除外、単位、保存Identity等の共通責務 |
| Category Flow | Category内のsemantic stage、順序、拡張点、依存境界、許可Control |
| Exception Registry | 標準との差異、対象、Authority、期限、改善方法 |
| Renderer | Contractを描画する。商品候補やFlowを列挙順から発明しない |

## 実行方法

Python **3.12.14**、依存は `requirements.txt` に全固定。JSON SchemaはDraft 2020-12。Schema 17件、Validator 14件。Selection / Presentation API v0.1を維持。Formal Promotion Governance v0.1を追加し、Foundation packageは0.3.0候補。

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python scripts/validate.py
.venv/bin/python scripts/run-tests.py test-results/unit-tests.json
```

個別検証は `scripts/validate-schema.py`、`validate-ui-standard.py`、`validate-category-flow.py`、`validate-selection-contract.py`、`validate-dependency.py`、`validate-reset.py`、`validate-exceptions.py`、`validate-authority.py`、`validate-mapping.py`、`validate-coverage.py`、`validate-output.py`、`validate-presentation-resolution.py`。すべてFAIL時は非0 exit。JSON結果は `--report PATH` で保存できる。

再生成は次の順。既存監査を再実行する処理ではなく、元bundleを変更せず正規化する処理である。

```sh
.venv/bin/python scripts/build-foundation.py
.venv/bin/python scripts/build-schemas.py
.venv/bin/python scripts/build-negative-fixtures.py
.venv/bin/python scripts/build-presentation-fixtures.py
.venv/bin/python scripts/build-promotion-fixtures.py
git diff --exit-code -- authority registries mappings fixtures schemas
```

CIはValidation、Unit/Negative Tests、再生成差分を検査する。3アプリにCIやRendererを追加しない。中央Repositoryの保護ブランチ設定・必須チェック設定は別の運用作業であり、このFoundationが設定済みとは扱わない。

## Authorityと採用Scope

`authority/audit/` は実取得した前工程bundleの内容。元FILE_MANIFESTのSHA256を維持する。各正式Rule・Flow・MappingはAuditのJSON Pointerと元bytesのSHA256へ接続し、`authority/human-review-adoption.v0.1.json` を採用判断として追加する。

`authority/active-manifest.v0.1.json` がAuthority resolverの起点。**Manifest First**を強制する。Sash UI StandardはCURRENT v2.1。cached filename、source comment、旧v1.8/v1.9による上書きは禁止。Runtime UI common v1.8は別責務の資料Identityとして保持されるが、UI Standard v2.1の代用にはしない。このManifestは監査時点の固定snapshotであり、ライブDrive Manifestの再取得結果ではない。Drive資料は監査の取得済み内容hashを引き継ぎ、本Repositoryに原文が全て格納されているとは主張しない。

Global正式Ruleは14件。普通のSelect Placeholderは「選択してください」。validation/error/empty result/confirmationの文言は対象外。上流変更は再評価 → validならKEEP_VALID → invalidならCLEAR/RESELECT → 非該当ならHIDE_AND_EXCLUDE。Required glyph、Fixed presentation、Dark Mode詳細はCategory/App責務を保持する。未採用Draft Ruleを一括FORMAL化しない。

正式Category Flowは `carport`、`indoor_joinery`、`window`、`interior_window`、`entrance_renovation` の5件。`entrance_door` / `cover_method` は `registries/not-formalized/` に隔離する。リシェントR8は新築玄関ドアのAuthorityにならない。内窓のsemantic SIZEと、Option後のfinal dimension presentationを区別する。

Carportの19親slotと室内建具の21stageは監査のCurrent Authorityを引き継ぐ。CarportのSelect/Radio差はCategory許可Control Setで表現し、個別Fieldは現在のControlを固定する。Readonly/derived SUMMARY等の観測状態は明示的に保持し、Categoryが両方を許可してもRuntimeが任意に切り替えてよい意味にはしない。

`semantic_stages` はCategoryの意味上のstage集合。`groups` / `group_order` は実際のpresentation責務。stage集合を単純にソートして全Fieldの画面順序を捏造しない。Carport・室内建具の固定product sequenceは正式Current順序を検査する。Window/内窓/玄関改修のField unionを固定画面順と誤認せず、現行Category contractとstate依存のorder evidenceを保持する。

## Formal / Draft / Legacy / Unknown

| 状態 | 意味 |
|---|---|
| FORMAL | 明示採用済みの規範。Critical identity/policyのUNKNOWNをSchemaで禁止 |
| CATEGORY_ONLY | Category/App内に責務を留める。Globalな一種類へ統一しない |
| PROVISIONAL / DRAFT | Schema-shaped候補。完全な商品別Authority/実機適合確認の代わりにはならない |
| OBSERVED_BASELINE | 監査で観測したMapping/role。正式な全Field移行・完全な依存モデル適合を意味しない |
| LEGACY_PENDING_MAPPING | Mappingや段階移行が未完。mandatory enforcement外 |
| UNKNOWN / NOT_FORMALIZED | Authority不足。推測で穴埋めしない |

581 Mappingを保存。75 UNKNOWNはそのまま保持。初回Scopeは標準ドア・Vレールなので、既存4Legacy Moduleの85Field全体（UNKNOWN75 + 観測Mapping10）を強制適用対象外にする。Routing4Fieldは棚卸しに含めるが、Product Field移行対象には含めない。

492のPrimary Product Fieldは `fixtures/current-selection-baseline.v0.1.json` に **PROVISIONAL** として保持。5Categoryに1件ずつの正式参照Contractは `fixtures/formal/` にある。これはSchemaと規範引渡しの参照例であり、アプリへ導入済みとは扱わない。Formal Fieldの `observation` / `evidence` は不確実性を引き継ぐ非規範的metadataであり、政策・IdentityのUNKNOWNを許す抜け道にしない。

727依存レコードは648の正確なselector再評価境界と79の確認待ちレコードに分離。79には68の製品ルール/部品/NON_UI effect、9の未解決参照、2のインプラス gas↔cavity_fill相互参照metadataを含む。循環metadataを片方だけ削除して製品の完全なDAGと主張しない。隔離したAuthorityを別Workで解決してから採用する。境界は製品候補や条件式の完全な複製ではない。

## Registryの変更方法

1. ACTIVE ManifestからAuthorityを解決し、commit SHA / document identity / bytes hash / pointerを固定する。
2. 更新理由とHuman Review採用を記録する。正式候補と観測候補を混同しない。
3. Schema・Registry・Semantic Role・Mapping・必要なFixtureを同じPRで更新する。
4. ValidatorとNegative Testsを実行し、破壊的変更はCHANGELOGに明示する。
5. レビュー後に中央Repositoryへ採用する。各アプリ配布は独立のMigration Gate。

Category追加時はCurrent Product/UI Authority、group/order、stage、Field universe、依存境界、許可Control、拡張点を揃える。似たLabelだけでMappingを作らない。Authority不足ならNOT_FORMALIZEDを保持する。

Exception追加時はID、対象Field/商品/Category、標準と例外の挙動、理由、Authority、影響、期限またはレビュー条件、remediationを揃える。暗黙if文による逸脱は禁止。VレールGlass ResetはTEMPORARY_EXCEPTIONで、**2026-11-03 または最初の室内建具mandatory enforcement前**に別Change Workで再評価する。期限当日からCIはFAILする。期限を自動更新しない。6記録のうち1Temporary、1Legacy、4Retired。Retiredは責務分離・採用判断によって解消した履歴でありactive waiverには使えない。

## Coverage / Output / Browser

REGISTERED_UNIVERSE_COVERAGEは20登録単位（14Primary Product、4Legacy、2App Routing）、Resolver universe、Inventory universe、各Moduleの正のField数、adapter evidence種類、総581Fieldを照合する。Stageだけ正しくても0FieldならFAIL。D-001の4商品・90Field omissionを通さない。

非該当・非表示Selectionはbusiness outputから除外する。納入/施工・見積/Surveyなどdestination責務を維持する。非表示identityや別workflowのSurvey contextを全storageから削除する契約にはしない。内部値=表示文字の一致だけではRaw Value露出を断定しない。公式コードラベルには明示的なAuthorityを必要とする。

SCHEMA / STATIC / UNIT TESTを実装。Browser Testは `docs/browser-test-contract.v0.1.json` の契約のみで、3アプリの全面QA改修・Browser再検証は含まれない。Exterior最新Production→固定mainSHA対応はmandatory enforcement前のBLOCKED Gateとして残す。Foundation作成自体のBlockerではない。

## Versioning / Breaking Change Policy

Registry API versionは0.1、package/Foundation releaseは0.3.0候補（既存Authorityは0.2.0）。PATCHは意味を変えないcopy/authority metadata修正、MINORは後方互換のRule/Category追加、MAJORはsemantic role、Flow順序、Reset semantics、mandatory property変更。0.x期間の破壊的変更は次MINORを使い、CHANGELOGに **BREAKING**、対象、移行方法を必ず書く。Control変更もContract変更としてレビューする。

## Snapshot distribution

Appは中央latest/mainを直接読む構造にしない。以下のような固定Revision metadataとsnapshot bytes SHA256を持つ。

```json
{
  "repository": "Takuro-Kwkm/product-ui-contracts",
  "revision": "<40-character commit SHA>",
  "ui_standard": "0.1",
  "category_flow": "carport@0.1",
  "content_sha256": "<64-character snapshot byte SHA256>"
}
```

`schemas/snapshot.schema.json` はfloating latest/main/HEADを拒否する。中央更新だけで3アプリを同時変更しない。次Migration候補は、別WorkでのVレールReset Authority解決、Exterior Production対応証拠取得、各アプリへ固定snapshotをshadow validation導入、Legacy4ModuleのCanonical Mapping確定。その後にRenderer/CI enforcementを段階採用する。

## Presentation Resolution v0.1（Foundation 0.2.0）

`presentation_resolution`はSelection Contractの任意property。Semantic Field Identity・runtime/canonical key・監査Control・保存Identityは保持し、結果としてのPresentationを分離する。既存492 baseline Fieldと5 Formal参照Contractを一括移行しない。旧Snapshotは変更せず、新しい固定Revisionを明示採用したFieldのみopt-inする。

必須のapplicability/status guard → explicit override → conditional rule → default → fallbackの順に解決する。同一priorityの重複は結果が同じでもFAIL。候補0件でordinary choice controlへ進む定義、未定義状態、未登録Control、Category許可外、Identity変更、商品/Field名predicateを拒否する。解決器はPresentation decisionを返すだけで、候補生成・自動選択・reset・render・保存を行わない。

仕様と使用例は[Schema/Resolution仕様](docs/presentation-resolution.v0.1.md)、検証責務は[Validator仕様](docs/presentation-validation.md)、Gapと次Workは[Closure Report](docs/FOUNDATION_GAP_001_PRESENTATION_RESOLUTION_REPORT.md)。フーゴFixtureは中央Contractの最小再現であり、Exterior Runtimeをコピー/実行していない。Exterior PilotはPR Merge、新固定Snapshot採用、実Runtimeとの再検証までBLOCKEDを保持する。Production identity UNVERIFIEDは別Enforcement Gateのまま。

これは後方互換の機能追加のためFoundation packageのMINORを0.2.0にする。既存Registry/Selection API v0.1の必須property・旧Control検証を変更しない。旧Validatorへ新propertyを渡せるというforward compatibilityは主張しない。新Presentation opt-inには新SnapshotとValidatorが必要。

## Field Formal Promotion Governance v0.1（Foundation 0.3.0）

Evidence Acceptance / Promotion Approval / status-only lifecycleは[Governance仕様](docs/formal-promotion-governance.v0.1.md)を参照。`validate-evidence-acceptance.py` / `validate-formal-promotion.py` を通常Validator/CIに追加。FORMAL自己申告を拒否し、PROVISIONALには追加Evidence要件を課さない。5参照ContractのCertificationは未導入Scopeだけを維持し、実アプリFieldの承認に流用できない。中央PRのMerge・新SHAのアプリ採用・Exteriorの再Promotionは別Work。
