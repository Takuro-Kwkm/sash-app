"""Isolated execution acceptance data, explicitly never a manufacturer baseline."""
import copy
import json
import tempfile
from pathlib import Path
from harness.core import read_json, sha, write_json
from harness.current_authority import compatibility
from product_master.build import build
from product_master.identity import digest
from product_master.validators.validate import validate


def inputs(root, checkout, destination):
    root, checkout, dest = map(Path, (root, checkout, destination))
    dest.mkdir(parents=True, exist_ok=True)
    profile = read_json(checkout / 'contracts/production/product-master-build-profile.v1.json')
    contract = profile['contracts']['registry_bootstrap']
    label = 'ISOLATED TEST Fixture Window' if 'sash' in profile['profile_id'] else 'ISOLATED TEST Fixture Product'
    candidate = 'NEW-CANDIDATE-' + sha(label.encode())[:24]
    header = contract.get('identity_columns', ['manufacturer', 'series']) + ['package_version']
    if 'master_status' not in header and 'sash' in profile['profile_id']:
        header.append('master_status')
    values = {k: 'EXISTING_' + k for k in header}
    write_json(dest / 'registry-observation.json', {'structuredContent': {'id': contract['authority_id'],
               'content': ','.join(header) + '\n' + ','.join(values[k] for k in header) + '\n'}})
    template = read_json(root / 'product_master/fixtures/new-product.json')
    field = copy.deepcopy(template['fields'][0])
    field.update(product_id=candidate, field_id='fixture_variant', label='Isolated fixture variant', semantic_role='fixture_variant',
                 source=['FIXTURE_SOURCE'], evidence_id=['FIXTURE_EVIDENCE'], notes='ISOLATED TEST; no manufacturer fact')
    field['selectable_values'] = [{'value': k, 'label': k, 'evidence_ids': ['FIXTURE_EVIDENCE'], 'when': True} for k in ('ALPHA', 'BETA')]
    source_bytes = b'ISOLATED TEST SOURCE. Variants ALPHA and BETA. No live product identity or fact.'
    (dest / 'fixture-source.txt').write_bytes(source_bytes)
    source = copy.deepcopy(template['sources'][0])
    source.update(source_id='FIXTURE_SOURCE', manufacturer='ISOLATED TEST', product_id=candidate, identity='isolated-test-source',
                  version='fixture-v1', location='fixture-source.txt', applicability='ISOLATED_1_FIELD_EXECUTION_FIXTURE',
                  content_identifier={'kind': 'SHA256_BYTES', 'value': sha(source_bytes)})
    evidence = copy.deepcopy(template['evidence'][0])
    evidence.update(evidence_id='FIXTURE_EVIDENCE', source_id=source['source_id'], source_identity=source['identity'],
                    source_version=source['version'], source_location=source['location'], content_identifier=source['content_identifier'],
                    supporting_fact='ISOLATED TEST: variants ALPHA and BETA', applicable_fields=[field['field_id']],
                    applicability=source['applicability'], claims=[{'field_id': field['field_id'], 'claim': 'field_fact', 'value': None}]
                    + [{'field_id': field['field_id'], 'claim': 'option', 'value': k} for k in ('ALPHA', 'BETA')])
    package = {**template, 'product': {'product_id': candidate, 'manufacturer': 'ISOLATED TEST', 'name': label,
               'category': profile['repository'].split('/')[-1], 'revision': 'fixture-v1'},
               'scope': {'scope_id': 'ISOLATED_1_FIELD_EXECUTION_FIXTURE', 'purpose': 'Isolated pipeline acceptance only',
                         'required_fields': [field['field_id']], 'excluded': ['Live manufacturer facts', 'FORMAL', 'Runtime', 'Release']},
               'sources': [source], 'fields': [field], 'evidence': [evidence], 'constraints': [], 'gaps': [],
               'handoff_tests': [{'case_id': 'valid', 'before': {'fixture_variant': 'ALPHA'}, 'changes': {}, 'expected_valid': True,
                                  'expected_output': {'fixture_variant': 'ALPHA'}},
                                 {'case_id': 'invalid', 'before': {'fixture_variant': 'INVALID'}, 'changes': {}, 'expected_valid': False,
                                  'expected_output': {'fixture_variant': 'INVALID'}},
                                 {'case_id': 'missing', 'before': {}, 'changes': {}, 'expected_valid': False, 'expected_output': {}}]}
    obs = {'target': candidate, 'candidate_state': 'QA_READY', 'context': {'registry_state': 'ABSENT', 'intent': 'build', 'dry_run': True},
           'facts': {k: v for k, v in package.items() if k not in ('work_type', 'lifecycle_status')}}
    package = build(obs, {'product_id': candidate, 'master_state': 'ABSENT'})
    qa = validate(package)
    assert qa['status'] == 'PASS', qa
    write_json(dest / 'observations.json', obs)
    write_json(dest / 'executed-scope-qa.json', qa)
    write_json(dest / 'project-qa.json', {'package_sha256': digest(package), 'status': 'PASS',
                'scope_review_ref': str(dest / 'executed-scope-qa.json'), 'fixture': True})
    write_json(dest / 'source-inputs.json', [{'source_id': source['source_id'], 'identity': source['identity'],
               'version': source['version'], 'path': str(dest / 'fixture-source.txt')}])
    (dest / 'governance.txt').write_text('ISOLATED TEST authority. No production Governance substitution.\n')
    write_json(dest / 'governance.json', {'fixture': {'path': str(dest / 'governance.txt'),
               'sha256': sha((dest / 'governance.txt').read_bytes()), 'status': 'CURRENT', 'authority_id': 'ISOLATED_TEST', 'version': '1'}})
    return {'instruction': label + 'の商品マスターを作成してくれ',
            **{k.replace('-', '_'): str(dest / (k + '.json')) for k in
               ('registry-observation', 'observations', 'source-inputs', 'project-qa', 'governance')}}


def exercise(root, checkout, destination=None):
    from product_master.execution import execute
    from harness.workflow import inspect, events
    def run_case(dest):
        data = inputs(root, checkout, dest / 'inputs')
        work = dest / 'work'
        kwargs = dict(root=root, checkout=checkout, work_root=work, fixture=True, **data)
        first = execute(**kwargs, stop_after='BUILD')
        assert first['state'] == 'IN_PROGRESS' and first['completed_gates'] == ['BUILD'], first
        before = events(work)[0]
        result = execute(**kwargs)
        assert result['state'] == 'COMPLETED', result
        assert events(work)[0] == before
        spec = read_json(work / 'spec.json')
        assert inspect(root, work, spec)[0]['state'] == 'COMPLETED'
        proof = read_json(work / 'candidate-readback.json')
        assert proof['status'] == 'PASS' and proof['sha256'] == sha(Path(proof['path']).read_bytes())
        assert read_json(work / 'qa/qa-ready.json')['result'] == 'PASS_CANDIDATE'
        assert read_json(work / 'human-review-packet.json')['status'] == 'PREPARED_NOT_APPROVED'
        assert read_json(work / 'resume-index.json')['operation'] == 'INSPECT_ONLY'
        assert (Path(read_json(work / 'resume-index.json')['checkpoint_path']) / 'checkpoint-manifest.json').is_file()
        return {**result, 'candidate_readback': proof}
    if destination:
        dest = Path(destination); dest.mkdir(parents=True, exist_ok=True)
        return run_case(dest)
    with tempfile.TemporaryDirectory() as tmp:
        return run_case(Path(tmp))
