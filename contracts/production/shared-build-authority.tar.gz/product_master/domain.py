"""Product-specific planning and impact analysis, carried forward from builder v1."""
from product_master.identity import digest
def plan(c):
    intent=c.get('intent','build'); state=c.get('registry_state','UNAVAILABLE')
    work=None; blockers=[]
    if state not in ('PRESENT','ABSENT'): blockers.append('CURRENT_REGISTRY_UNVERIFIED')
    elif state=='PRESENT' and not c.get('existing_master'): blockers.append('CURRENT_MASTER_UNVERIFIED')
    elif intent=='qa':work='QA ONLY'
    elif intent=='evidence':work='EVIDENCE CLOSURE'
    elif state=='ABSENT':work='NEW BUILD'
    elif intent=='change' or c.get('source_delta')=='CHANGED':work='CHANGE WORK'
    elif c.get('source_delta')=='UNCHANGED':work='CARRY-FORWARD'
    else:blockers.append('SOURCE_COMPARISON_REQUIRED')
    return {'work_type':work,'blockers':blockers,'next_action':'INSPECT_MISSING_AUTHORITY_OR_COMPARE_SOURCE' if blockers else 'EXECUTE_SCOPED_WORK','target_gate':c.get('target_gate','QA_READY'),'working_ref':c.get('working_ref'),'dry_run':c.get('dry_run',False)}
def diff(before,after):
    a={x['field_id']:x for x in before.get('fields',[])};b={x['field_id']:x for x in after.get('fields',[])}
    added=sorted(b.keys()-a.keys());removed=sorted(a.keys()-b.keys());changed=sorted(k for k in a.keys()&b.keys() if a[k]!=b[k]);unchanged=sorted(k for k in a.keys()&b.keys() if a[k]==b[k])
    impacted=set(added+removed+changed)
    # Also include source/rule changes even when field text stays identical.
    srca={x['source_id']:x for x in before.get('sources',[])};srcb={x['source_id']:x for x in after.get('sources',[])}
    sources={k for k in srca.keys()|srcb.keys() if srca.get(k)!=srcb.get(k)}
    ev_a={x['evidence_id']:x for x in before.get('evidence',[])};ev_b={x['evidence_id']:x for x in after.get('evidence',[])}
    for k in ev_a.keys()|ev_b.keys():
        old,new=ev_a.get(k),ev_b.get(k)
        if old!=new or any(e and e['source_id'] in sources for e in (old,new)):
            for e in (old,new):
                if e:impacted.update(e['applicable_fields'])
    rules_a={x['rule_id']:x for x in before.get('constraints',[])};rules_b={x['rule_id']:x for x in after.get('constraints',[])}
    for k in rules_a.keys()|rules_b.keys():
        if rules_a.get(k)!=rules_b.get(k):
            for r in (rules_a.get(k),rules_b.get(k)):
                if r:impacted.update(r['field_ids'])
    while True:
        new=impacted|{k for k,v in b.items() if set(v.get('dependency',[]))&impacted}
        if new==impacted:break
        impacted=new
    return {'before_hash':digest(before),'after_hash':digest(after),'added':added,'removed':removed,'changed':changed,'unchanged':unchanged,'changed_sources':sorted(sources),'qa_impact':sorted(impacted),'rows':[{'field_id':k,'before':a.get(k),'after':b.get(k)} for k in sorted(set(added+removed+changed))]}
