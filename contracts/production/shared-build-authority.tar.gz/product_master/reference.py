"""Isolated 3-field fixture kit for executable reference verification, never a live registry."""
from pathlib import Path
from harness.core import fingerprint, read_json, sha, write_json

ROOT = Path(__file__).resolve().parents[1]

def reference(destination, skill_root=None):
    root = Path(destination).resolve()
    root.mkdir(parents=True, exist_ok=True)
    target = 'lixil.carport_sc'
    master = read_json(ROOT / 'product_master/fixtures/new-product.json')
    observations = {'target': target, 'candidate_state': 'QA_READY', 'context': {'registry_state': 'ABSENT', 'target_gate': 'QA_READY', 'dry_run': True},
                    'facts': {k: v for k, v in master.items() if k not in ('work_type', 'lifecycle_status')}}
    write_json(root / 'observations.json', observations)
    write_json(root / 'registry.json', {'registry_id': 'isolated-reference-products', 'version': '1', 'status': 'CURRENT',
               'products': [{'product_id': target, 'aliases': ['カーポートSC テスト'], 'master_state': 'ABSENT', 'scope': 'ISOLATED_3_FIELD_FIXTURE'}]})
    routing = {'status': 'CURRENT', 'routes': [{'work_skill': 'product-master-builder', 'triggers': ['Product Master', '商品マスター'],
                 'default_gate': 'QA_READY', 'gate_triggers': {'QA_READY': ['QA_READY'], 'FORMAL_CANDIDATE': ['FORMAL候補']}}]}
    write_json(root / 'routing.json', routing)
    def ref(path):
        path = Path(path)
        return {'path': str(path), 'sha256': sha(path.read_bytes())}
    steps = [
        {'id': 'BUILD', 'kind': 'build', 'needs': [], 'script': ref(ROOT / 'product_master/build.py'),
         'args': ['--observations', '{input}', '--registry', '{registry}', '--out', '{work}/master.json', '--plan-out', '{work}/plan.json'],
         'output': '{work}/master.json', 'side_outputs': ['{work}/plan.json']},
        {'id': 'QA', 'kind': 'validator', 'needs': ['BUILD'], 'script': ref(ROOT / 'product_master/validators/validate.py'),
         'args': ['{work}/master.json', '--out', '{work}/qa.json'], 'output': '{work}/qa.json', 'result_path': ['status'], 'expected_result': 'PASS'},
        {'id': 'QA_READY', 'kind': 'validator', 'needs': ['QA'], 'script': ref(ROOT / 'product_master/evaluate_gate.py'),
         'args': ['--qa', '{work}/qa.json', '--gate', 'QA_READY', '--out', '{work}/qa-ready.json'],
         'output': '{work}/qa-ready.json', 'result_path': ['result'], 'expected_result': 'PASS_CANDIDATE'},
        {'id': 'STORAGE', 'kind': 'storage', 'needs': ['QA_READY'], 'source': '{work}/master.json', 'destination': '{workflow_id}/master.json'},
        {'id': 'QA_STORAGE', 'kind': 'storage', 'needs': ['QA_READY'], 'source': '{work}/qa.json', 'destination': '{workflow_id}/qa.json'},
        {'id': 'GATE_STORAGE', 'kind': 'storage', 'needs': ['QA_READY'], 'source': '{work}/qa-ready.json', 'destination': '{workflow_id}/qa-ready.json'},
        {'id': 'REGISTRY', 'kind': 'registry-output', 'needs': ['STORAGE', 'QA_STORAGE', 'GATE_STORAGE'], 'source': '{work}/master.json',
         'destination': 'reference-registry.json', 'entry_keys': ['product', 'lifecycle_status', 'scope']}]
    definition = {'workflow_id': 'builder-reference-profile', 'version': '2.0', 'status': 'CURRENT', 'work_skill': 'product-master-builder',
                  'scope': 'REFERENCE_FIXTURE; does not replace any project official gate', 'steps': steps,
                  'targets': {'QA_READY': ['REGISTRY']}}
    write_json(root / 'workflow.json', definition)
    authority = {**ref(root / 'workflow.json'), 'authority_id': 'reference-workflow-contract', 'authority_type': 'WORKFLOW',
                 'repository': 'ISOLATED_FIXTURE', 'version': '2.0', 'status': 'CURRENT', 'scope_axis': 'PROJECT_CURRENT', 'resolution_source': 'isolated reference profile'}
    write_json(root / 'authority-index.json', {'status': 'CURRENT', 'entries': [authority]})
    source = {**ref(root / 'observations.json'), 'source_id': 'fixture-observations', 'identity': 'ISOLATED_3_FIELD_REGRESSION_FIXTURE',
              'version': '1', 'status': 'CURRENT', 'role': 'CURRENT_ADOPTED', 'product_id': target}
    spec = {'workflow_id': 'builder-v2-reference', 'work_skill': 'product-master-builder', 'target': target, 'target_gate': 'QA_READY',
            'skill_root': str(Path(skill_root).resolve()) if skill_root else 'NOT_REQUIRED_BY_CENTRAL_DOMAIN_ADAPTER',
            'authority_index': ref(root / 'authority-index.json'), 'authorities': [authority], 'registry': ref(root / 'registry.json'), 'sources': [source],
            'workflow': ref(root / 'workflow.json'), 'input': ref(root / 'observations.json'), 'storage_root': str(root / 'saved'),
            'runtime_refs': [ref(ROOT / p) for p in ('harness/workflow.py', 'harness/resolvers.py', 'harness/artifacts.py',
                             'harness/core.py', 'product_master/domain.py', 'product_master/identity.py', 'product_master/schemas/work-package.schema.json')]}
    write_json(root / 'spec.json', spec)
    return root, spec, routing
