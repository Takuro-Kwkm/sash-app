#!/usr/bin/env python3
"""Domain builder for reviewed observations. Fact extraction stays with Work Skill."""
import argparse
import copy
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from product_master.domain import plan
from harness.core import write_json

def build(observations, registry_entry=None):
    if registry_entry is not None:
        if observations['context'].get('registry_state') != registry_entry.get('master_state') or observations['target'] != registry_entry.get('product_id'):
            raise ValueError('Observation planning context contradicts the resolved registry')
    selection = plan(observations['context'])
    if selection['blockers']:
        raise ValueError(', '.join(selection['blockers']))
    facts = observations['facts']
    if selection['work_type'] in ('CARRY-FORWARD', 'QA ONLY'):
        master = copy.deepcopy(observations['existing_master'])
    else:
        master = {key: copy.deepcopy(facts[key]) for key in ('schema_version', 'product', 'scope', 'sources', 'fields', 'evidence', 'constraints', 'gaps', 'handoff_tests', 'provenance')}
        master['work_type'] = selection['work_type']
        master['lifecycle_status'] = observations['candidate_state']
    if master['product']['product_id'] != observations['target']:
        raise ValueError('Observed target and native master differ')
    return master

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--observations', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--registry', required=True)
    p.add_argument('--plan-out')
    args = p.parse_args()
    observations = json.loads(Path(args.observations).read_text())
    registry = json.loads(Path(args.registry).read_text())
    entries = [r for r in registry['products'] if r['product_id'] == observations['target']]
    if len(entries) != 1:
        raise ValueError('Exactly one inspected product row required')
    master = build(observations, entries[0])
    write_json(args.out, master)
    if args.plan_out:
        write_json(args.plan_out, {'target': observations['target'], **plan(observations['context']),
                   'master_bytes_preserved': observations['context'].get('intent') == 'qa' or plan(observations['context'])['work_type'] == 'CARRY-FORWARD'})

if __name__ == '__main__':
    main()
