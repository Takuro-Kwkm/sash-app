"""Production builder adapter. DAG, journal, storage and Resume stay in v2.

Sources and extraction are supplied by the Work Skill as reviewed observations.
An incomplete acquisition is a persisted pending Work, never a QA pass.
"""
import argparse
import importlib.util
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from harness.core import fingerprint, read_json, require, sha, write_json
from harness.current_authority import acquire, compatibility, inspect_binding
from harness.workflow import run, inspect, events
from harness.production import persist_checkpoint
from product_master.build import build


def ref(path):
    path = Path(path).resolve()
    require(path.is_file() and not path.is_symlink(), 'REFERENCE_MISSING', str(path), 'INITIALIZATION')
    return {'path': str(path), 'sha256': sha(path.read_bytes())}


def native_module(checkout, name):
    spec = importlib.util.spec_from_file_location('native_builder', Path(checkout) / name)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def freeze_acquisition(work_root, descriptors, product_id):
    """Persist actual retrieved official bytes before fact extraction is ready."""
    captured = []
    for d in read_json(descriptors):
        require(all(d.get(k) for k in ('source_id','identity','manufacturer','product_id','version','scope',
                                      'locator','content_sha256','authority','acquisition_ref','path'))
                and d['product_id'] == product_id and d['authority'] in ('manufacturer_official', 'project_authority'),
                'SOURCE_IDENTITY', 'Complete acquired Source identity required', 'ACQUISITION')
        data = Path(d['path']).read_bytes()
        require(sha(data) == d['content_sha256'], 'SOURCE_IDENTITY', 'Acquired bytes mismatch', 'ACQUISITION')
        path = Path(work_root) / 'inputs/acquired-sources' / (sha(d['source_id'].encode()) + '.bin')
        require(not path.is_symlink() and (not path.exists() or path.read_bytes() == data),
                'SOURCE_CHANGED', 'Source changed; create a successor', 'ACQUISITION')
        path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)
        captured.append({**{k:v for k,v in d.items() if k!='path'}, 'path':str(path)})
    require(captured, 'SOURCE_ACQUISITION_REQUIRED', 'No official bytes captured', 'ACQUISITION')
    identity = Path(work_root) / 'acquisition-identity.json'
    require(not identity.exists() or read_json(identity) == captured,
            'SOURCE_CHANGED', 'Immutable acquisition identity changed; successor required', 'ACQUISITION')
    write_json(identity, captured)
    return captured


def start(root, checkout, instruction, registry_observation, work_root, fixture=False):
    """Freeze Current and native absence observation before official acquisition."""
    root, checkout, work_root = map(lambda p: Path(p).resolve(), (root, checkout, work_root))
    require(not work_root.is_relative_to(root) and not work_root.is_relative_to(checkout),
            'OUTPUT_PATH', 'External isolated working area required', 'INITIALIZATION')
    bootstrap = work_root / 'bootstrap.json'
    if bootstrap.exists():
        saved = read_json(bootstrap)
        require(saved['instruction'] == instruction and saved['registry_observation'] == ref(registry_observation),
                'WORK_CHANGED', 'Bootstrap inputs changed; successor required', 'RESUME')
        binding = read_json(work_root / 'current-authority-binding.json')
        inspect_binding(binding)
        for r in saved['native_refs'].values():
            require(sha(Path(r['path']).read_bytes()) == r['sha256'], 'IMMUTABLE_WORK_CHANGED',
                    'Native profile implementation changed; restore or create successor', 'RESUME')
        r = saved['consumer_adoption']
        require(sha(Path(r['path']).read_bytes()) == r['sha256'], 'IMMUTABLE_WORK_CHANGED',
                'Consumer adoption changed after Work start', 'RESUME')
        return Path(binding['snapshot_root']), saved, binding
    if fixture:
        proof = compatibility(root, checkout)
        binding = {'selector': 'ISOLATED_TEST_AUTHORITY', 'snapshot_root': str(root), 'current_head': 'ISOLATED_TEST',
                   'authority_hashes': {p: sha((root / p).read_bytes()) for p in
                                        ('registries/current-architecture.v2.json', 'registries/skill-authority.v2.json')},
                   'compatibility': proof, 'resume_policy': 'KEEP_IMMUTABLE_BINDING'}
        binding['binding_sha256'] = fingerprint(binding)
        work_root.mkdir(parents=True, exist_ok=False)
        write_json(work_root / 'current-authority-binding.json', binding)
        snapshot = root
    else:
        snapshot, binding = acquire(root, checkout, work_root)
    pointer = read_json(checkout / 'contracts/production/current-architecture.json')
    profile = read_json(checkout / pointer['new_product_build_profile']['path'])
    require(profile['mode'] == 'NEW_PRODUCT_MASTER_BUILD', 'PLANNING_ONLY_BLOCKER', 'Actual build profile required', 'INITIALIZATION')
    planner = native_module(checkout, profile['refs']['native_planner']['path'])
    planned = planner.plan(snapshot, instruction, registry_observation, work_root)
    require(planned['status'] == 'PASS', 'BOOTSTRAP_REQUIRED', 'Native absence planning failed', 'INITIALIZATION')
    saved = {'instruction': instruction, 'repository': profile['repository'], 'profile_id': profile['profile_id'],
             'registry_observation': ref(registry_observation), 'route': planned['route'],
             'registry_bootstrap_candidate': planned['registry_bootstrap_candidate'],
             'source_requests': planned['source_requests'], 'authority_binding_sha256': binding['binding_sha256'],
             'consumer_adoption': ref(checkout / 'contracts/production/current-authority-adoption.json'),
             'native_refs': {k: {**v, 'path': str(checkout / v['path'])} for k, v in profile['refs'].items() if v['owner'] == 'native'},
             'fixture': fixture}
    write_json(bootstrap, saved)
    write_json(work_root / 'source-requests.json', {'state': 'SOURCE_ACQUISITION_REQUIRED', 'requests': saved['source_requests']})
    write_json(work_root / 'resume-index.json', {'state': 'SOURCE_ACQUISITION_REQUIRED', 'bootstrap': ref(bootstrap),
               'authority_binding': ref(work_root / 'current-authority-binding.json'),
               'operation': 'RESUME_PENDING_ONLY', 'formal_writes': 0})
    return snapshot, saved, binding


def execute(root, checkout, instruction, registry_observation, work_root,
            observations=None, source_inputs=None, project_qa=None, governance=None, fixture=False, stop_after=None):
    snapshot, bootstrap, binding = start(root, checkout, instruction, registry_observation, work_root, fixture)
    work_root = Path(work_root).resolve()
    spec_path = work_root / 'spec.json'
    if spec_path.exists():
        spec = read_json(spec_path)
        inspect_binding(binding)
        state, _, _ = inspect(snapshot, work_root, spec)
        if state['state'] == 'COMPLETED':
            packet = read_json(work_root / 'human-review-packet.json')
            require(packet['payload_sha256'] == fingerprint({k:v for k,v in packet.items() if k!='payload_sha256'}),
                    'REVIEW_PACKET_CHANGED', 'Fixed Human Review Packet changed', 'RESUME')
            return {**state, 'status': 'PASS', 'operation': 'INSPECT_ONLY', 'mode': 'NEW_PRODUCT_MASTER_BUILD',
                    'work_root': str(work_root), 'product_master_created': True, 'formal_writes': 0, 'fixture': bootstrap['fixture']}
    elif not all((observations, source_inputs, project_qa, governance)):
        captured = freeze_acquisition(work_root, source_inputs, bootstrap['route']['product_id']) if source_inputs else []
        state = 'SOURCE_ACQUIRED_FACT_EXTRACTION_REQUIRED' if captured else 'SOURCE_ACQUISITION_REQUIRED'
        write_json(work_root / 'resume-index.json', {'state':state, 'bootstrap':ref(work_root / 'bootstrap.json'),
                   'authority_binding':ref(work_root / 'current-authority-binding.json'),
                   'source_identity':ref(work_root / 'acquisition-identity.json') if captured else None,
                   'operation':'RESUME_PENDING_ONLY', 'formal_writes':0})
        snapshot_hash = fingerprint({p.relative_to(work_root).as_posix():sha(p.read_bytes()) for p in work_root.rglob('*')
                                   if p.is_file() and '.git' not in p.parts and not p.name.startswith('.')})
        persist_checkpoint(snapshot, work_root, bootstrap, work_root.parent / (work_root.name + '-savepoints') / snapshot_hash)
        return {'status': 'WORK_STARTED', 'state': state, 'mode': 'NEW_PRODUCT_MASTER_BUILD',
                'work_root': str(work_root), 'source_requests': bootstrap['source_requests'],
                'source_acquisition': captured, 'current_authority_binding': binding, 'product_master_created': False, 'formal_writes': 0}
    else:
        obs = read_json(observations)
        candidate_id = bootstrap['route']['product_id']
        row = bootstrap['registry_bootstrap_candidate']['products'][0]
        require(obs['target'] == candidate_id and obs['context']['registry_state'] == 'ABSENT'
                and obs['candidate_state'] in ('DRAFT', 'PROVISIONAL', 'QA_READY'),
                'BUILD_SCOPE', 'Only a bound new candidate before Human Formal decision', 'INITIALIZATION')
        require(bool(obs['facts']['provenance']['dry_run']) == bool(fixture),
                'FIXTURE_BOUNDARY', 'Fixture inputs cannot become production QA', 'INITIALIZATION')
        package = build(obs, row)
        descriptors = read_json(source_inputs)
        acquisition = work_root / 'acquisition-identity.json'
        if acquisition.exists():
            frozen = read_json(acquisition)
            for d in descriptors:
                prior = [x for x in frozen if x['source_id'] == d['source_id']]
                require(len(prior) == 1 and sha(Path(d['path']).read_bytes()) == prior[0]['content_sha256']
                        and d['identity'] == prior[0]['identity'] and d['version'] == prior[0]['version'],
                        'SOURCE_CHANGED', 'Extracted Source differs from frozen acquisition', 'INITIALIZATION')
        source_refs = []
        identities = []
        require({s['source_id'] for s in descriptors} == {s['source_id'] for s in package['sources']},
                'SOURCE_IDENTITY', 'All and only declared sources must have actual bytes', 'INITIALIZATION')
        for s in package['sources']:
            d = next(d for d in descriptors if d['source_id'] == s['source_id'])
            data = Path(d['path']).read_bytes()
            require(d['identity'] == s['identity'] and d['version'] == s['version']
                    and sha(data) == s['content_identifier']['value'],
                    'SOURCE_IDENTITY', 'Actual Source bytes/identity differ', 'INITIALIZATION')
            require(fixture or (d.get('authority') == s['authority'] and d.get('scope') == s['applicability']
                    and d.get('locator') == s['location'] and d.get('acquisition_ref')),
                    'SOURCE_ACQUISITION_REQUIRED', 'Captured official acquisition provenance required', 'INITIALIZATION')
            path = work_root / 'inputs/sources' / (sha(s['source_id'].encode()) + '.bin')
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            source_refs.append({**ref(path), 'source_id': s['source_id'], 'identity': s['identity'], 'version': s['version'],
                                'status': 'CURRENT', 'role': 'PRIMARY_OFFICIAL', 'product_id': candidate_id})
            identities.append({**d, 'captured_path': str(path), 'content_sha256': sha(data)})
        write_json(work_root / 'source-identity.json', identities)
        inputs = work_root / 'inputs'
        write_json(inputs / 'observations.json', obs)
        scope_qa = read_json(project_qa)
        from product_master.identity import digest
        require(scope_qa.get('package_sha256') == digest(package) and scope_qa.get('status') == 'PASS',
                'NATIVE_PROJECT_QA_REQUIRED', 'Same candidate business Scope review required', 'INITIALIZATION')
        review_path = Path(scope_qa['scope_review_ref'])
        review = read_json(review_path)
        require(review.get('package_sha256') == digest(package) and review.get('status') == 'PASS',
                'NATIVE_PROJECT_QA_REQUIRED', 'Executed Scope QA report is absent or stale', 'INITIALIZATION')
        write_json(inputs / 'scope-review.json', review)
        scope_qa['scope_review_ref'] = str(inputs / 'scope-review.json')
        write_json(inputs / 'project-qa.json', scope_qa)
        write_json(inputs / 'registry.json', {'registry_id': 'WORK_LOCAL_BOOTSTRAP', 'version': '1', 'status': 'CURRENT', 'products': [row]})
        authority_refs = []
        governing = read_json(governance)
        contract = read_json(bootstrap['native_refs']['native_schema']['path'])
        require(fixture or set(contract['governance']).issubset(governing),
                'NATIVE_GOVERNANCE_REQUIRED', 'Acquire ACTIVE manifest, dictionary and business Scope governance', 'INITIALIZATION')
        for key, d in governing.items():
            original = Path(d['path'])
            data = original.read_bytes()
            require(sha(data) == d['sha256'] and d.get('status') in ('CURRENT', 'ACTIVE'),
                    'NATIVE_GOVERNANCE_REQUIRED', 'Governance bytes/status unverified', 'INITIALIZATION')
            require(fixture or d.get('authority_id') == contract['governance'][key]['id'],
                    'NATIVE_GOVERNANCE_REQUIRED', 'Wrong native governance identity', 'INITIALIZATION')
            dest = inputs / ('governance-' + sha(key.encode()) + '.bin')
            dest.write_bytes(data)
            authority_refs.append({**ref(dest), 'authority_id': d['authority_id'], 'authority_type': key,
                    'repository': bootstrap['repository'], 'version': d['version'], 'status': d['status'],
                    'scope_axis': 'PROJECT_CURRENT', 'resolution_source': d.get('acquisition_ref', 'ISOLATED_TEST')})
        require(authority_refs, 'NATIVE_GOVERNANCE_REQUIRED', 'No governing authority captured', 'INITIALIZATION')
        stages = [
            {'id': 'BUILD', 'kind': 'build', 'needs': [], 'script': ref(snapshot / 'product_master/build.py'),
             'args': ['--observations', '{input}', '--registry', '{registry}', '--out', '{work}/candidate/product-master.json'],
             'output': '{work}/candidate/product-master.json'},
            {'id': 'DOMAIN_QA', 'kind': 'validator', 'needs': ['BUILD'], 'script': ref(snapshot / 'product_master/validators/validate.py'),
             'args': ['{work}/candidate/product-master.json', '--out', '{work}/qa/domain-qa.json'],
             'output': '{work}/qa/domain-qa.json', 'result_path': ['status'], 'expected_result': 'PASS'},
            {'id': 'NATIVE_QA', 'kind': 'validator', 'needs': ['DOMAIN_QA'],
             'script': ref(bootstrap['native_refs']['native_validator']['path']),
             'args': ['--harness-root', str(snapshot), '--package', '{work}/candidate/product-master.json',
                      '--project-qa', str(inputs / 'project-qa.json'), '--out', '{work}/qa/native-qa.json'],
             'output': '{work}/qa/native-qa.json', 'result_path': ['status'], 'expected_result': 'PASS'},
            {'id': 'QA_READY', 'kind': 'validator', 'needs': ['NATIVE_QA'], 'script': ref(snapshot / 'product_master/evaluate_gate.py'),
             'args': ['--qa', '{work}/qa/native-qa.json', '--gate', 'QA_READY', '--out', '{work}/qa/qa-ready.json'],
             'output': '{work}/qa/qa-ready.json', 'result_path': ['result'], 'expected_result': 'PASS_CANDIDATE'}]
        outputs = [('CANDIDATE_SAVE', 'candidate/product-master.json'), ('QA_SAVE', 'qa/native-qa.json'),
                   ('GATE_SAVE', 'qa/qa-ready.json'), ('SOURCE_SAVE', 'source-identity.json'), ('EVIDENCE_SAVE', 'inputs/observations.json')]
        for name, path in outputs:
            stages.append({'id': name, 'kind': 'storage', 'needs': ['QA_READY'], 'source': '{work}/' + path,
                           'destination': '{workflow_id}/' + path})
        workflow = {'status': 'CURRENT', 'work_skill': 'product-master-builder', 'version': '2.0', 'steps': stages,
                    'targets': {'QA_READY': [n for n, _ in outputs]}}
        write_json(work_root / 'workflow.json', workflow)
        write_json(work_root / 'authority-index.json', {'status': 'CURRENT', 'entries': authority_refs})
        spec = {'workflow_id': candidate_id, 'work_skill': 'product-master-builder', 'target': candidate_id,
                'target_gate': 'QA_READY', 'skill_root': str(snapshot / 'work_skills/product-master-builder'),
                'input': ref(inputs / 'observations.json'), 'registry': ref(inputs / 'registry.json'),
                'authority_index': ref(work_root / 'authority-index.json'), 'authorities': authority_refs,
                'workflow': ref(work_root / 'workflow.json'), 'sources': source_refs,
                'storage_root': str(work_root / 'saved'), 'current_authority_binding': ref(work_root / 'current-authority-binding.json'),
                'runtime_refs': [ref(snapshot / p) for p in binding['compatibility']['semantic_hashes']]
                              + [ref(inputs / 'project-qa.json'), ref(inputs / 'scope-review.json'), ref(work_root / 'bootstrap.json'),
                                 ref(work_root / 'source-identity.json')] + [ref(v['path']) for v in bootstrap['native_refs'].values()]}
        write_json(spec_path, spec)
    for directory in ('candidate', 'qa'):
        (work_root / directory).mkdir(exist_ok=True)
    # This is the existing shared engine, not a repository-specific runner.
    result = run(snapshot, work_root, spec, stop_after=stop_after)
    if result['state'] == 'COMPLETED':
        saved = Path(spec['storage_root']) / spec['workflow_id'] / 'candidate/product-master.json'
        original = work_root / 'candidate/product-master.json'
        # Independent read route after storage receipt, in addition to save_verified.
        with saved.open('rb') as stream:
            readback = sha(stream.read())
        require(readback == sha(original.read_bytes()), 'CANDIDATE_READBACK', 'Saved candidate changed', 'STORAGE')
        write_json(work_root / 'candidate-readback.json', {'status': 'PASS', 'path': str(saved), 'sha256': readback})
        packet = {'status': 'PREPARED_NOT_APPROVED', 'product_id': spec['target'],
                  'candidate': ref(saved), 'qa': ref(work_root / 'qa/native-qa.json'),
                  'source_identity': ref(work_root / 'source-identity.json'), 'work_spec': ref(spec_path),
                  'formal_state': 'HUMAN_DECISION_REQUIRED', 'formal_transaction': bootstrap['route']['profile']['contracts']['formal_persistence'],
                  'registry_update': 'ONLY_AFTER_ADMITTED_FORMAL_TRANSACTION'}
        packet['payload_sha256'] = fingerprint(packet)
        write_json(work_root / 'human-review-packet.json', packet)
    snapshot_hash = fingerprint({p.relative_to(work_root).as_posix(): sha(p.read_bytes())
                               for p in work_root.rglob('*') if p.is_file() and not p.name.startswith('.')
                               and not p.name.endswith('.lock') and p.name != 'resume-index.json'})
    checkpoint_path = work_root.parent / (work_root.name + '-savepoints') / snapshot_hash
    write_json(work_root / 'resume-index.json', {'state': result['state'], 'spec': ref(spec_path),
               'completed_gates': result['completed_gates'], 'pending_gates': result['pending_gates'],
               'operation': 'INSPECT_ONLY' if result['state'] == 'COMPLETED' else 'RESUME_PENDING_ONLY',
               'checkpoint_path': str(checkpoint_path), 'formal_writes': 0})
    persist_checkpoint(snapshot, work_root, spec, checkpoint_path)
    return {**result, 'status': 'PASS' if result['state'] == 'COMPLETED' else 'PENDING',
            'mode': 'NEW_PRODUCT_MASTER_BUILD', 'work_root': str(work_root),
            'product_master_created': (work_root / 'candidate/product-master.json').exists(),
            'formal_writes': 0, 'fixture': bootstrap['fixture']}


def main(argv=None):
    p = argparse.ArgumentParser()
    for key in ('harness-root', 'checkout', 'instruction', 'registry-observation', 'work-root', 'out'):
        p.add_argument('--' + key, required=True)
    for key in ('observations', 'source-inputs', 'project-qa', 'governance', 'stop-after'):
        p.add_argument('--' + key)
    p.add_argument('--fixture', action='store_true')
    a = p.parse_args(argv)
    try:
        result = execute(a.harness_root, a.checkout, a.instruction, a.registry_observation, a.work_root,
                         a.observations, a.source_inputs, a.project_qa, a.governance, a.fixture, a.stop_after)
    except Exception as e:
        result = {'status': 'FAIL_CLOSED', 'blocking_reason': getattr(e, 'data', {'reason': str(e)})}
    output = Path(a.out).resolve()
    require(output.is_relative_to(Path(a.work_root).resolve()) and not output.is_symlink(), 'OUTPUT_PATH', 'Work output required', 'STORAGE')
    write_json(output, result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['status'] in ('PASS', 'WORK_STARTED', 'PENDING') else 2


if __name__ == '__main__':
    raise SystemExit(main())
