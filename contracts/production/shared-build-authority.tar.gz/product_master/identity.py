"""Canonical identity shared by the product-master domain and its validator."""
import hashlib
import json
def canonical(data):
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
def digest(data):
    return hashlib.sha256(canonical(data)).hexdigest()
