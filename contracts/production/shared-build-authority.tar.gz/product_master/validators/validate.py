#!/usr/bin/env python3
"""Structural QA and candidate gates. Does not authenticate facts or human decisions."""
import argparse, hashlib, json, sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[2]))
from product_master.identity import digest
METRICS=['UNKNOWN','UNMAPPED','SCHEMA_ERROR','DUPLICATE_ID','INVALID_OPTION','BROKEN_DEPENDENCY','BROKEN_RESET','ORPHAN_FIELD','MISSING_EVIDENCE','CONFLICTING_EVIDENCE','OUT_OF_SCOPE_FIELD','CRITICAL_VALIDATION_ERROR']

def refs(c):
    if isinstance(c,bool):return set()
    if 'field' in c:return {c['field']}
    if 'not' in c:return refs(c['not'])
    return set().union(*(refs(x) for x in c.get('all',c.get('any',[]))))
def condition(c,state):
    if isinstance(c,bool):return c
    if 'all' in c:return all(condition(x,state) for x in c['all'])
    if 'any' in c:return any(condition(x,state) for x in c['any'])
    if 'not' in c:return not condition(c['not'],state)
    v=state.get(c['field']);w=c['value'];op=c['op']
    if op=='exists':return (v is not None)==w
    if op=='eq':return v==w
    if op=='ne':return v!=w
    if op=='in':return isinstance(w,list) and v in w
    if op in ('gte','lte'):
        if not isinstance(v,(int,float)) or isinstance(v,bool) or not isinstance(w,(int,float)) or isinstance(w,bool):return False
        return v>=w if op=='gte' else v<=w
    raise ValueError('unsupported condition')
def valid_value(f,value,state):
    if value is None:return True
    t=f['data_type']
    if t=='number':
        return isinstance(value,(int,float)) and not isinstance(value,bool) and (f['minimum'] is None or value>=f['minimum']) and (f['maximum'] is None or value<=f['maximum'])
    if t=='boolean':return isinstance(value,bool)
    if t=='text':return isinstance(value,str)
    opts=[o['value'] for o in f['selectable_values'] if condition(o['when'],state)]
    if t=='multi_enum':return isinstance(value,list) and len({json.dumps(v,sort_keys=True) for v in value})==len(value) and all(v in opts for v in value)
    return value in opts

def handoff(p,test):
    fields={f['field_id']:f for f in p['fields']};before=test['before'];state=dict(before);state.update(test['changes'])
    errors=[];changed={k for k in test['changes'] if before.get(k)!=state.get(k)}
    unknown=set(state)-fields.keys()
    if unknown:errors.append('unknown input fields')
    # dependency order makes propagated parent reset deterministic.
    ordered=[];pending=dict(fields)
    while pending:
        ready=[k for k,f in pending.items() if not set(f['dependency'])&pending.keys()]
        if not ready:raise ValueError('dependency cycle')
        for k in sorted(ready):ordered.append(pending.pop(k))
    for f in ordered:
        k=f['field_id'];old=state.get(k)
        for r in f['reset_condition']:
            if r['on_change'] in changed:
                if r['action']=='CLEAR' or not valid_value(f,state.get(k),state):state[k]=None
        if not condition(f['visibility_condition'],state):state.pop(k,None)
        if old!=state.get(k):changed.add(k)
    isolated={k for g in p['gaps'] if g['classification']!='Blocker' and not g['result_in_scope'] for k in g['field_ids']}
    for f in fields.values():
        k=f['field_id'];value=state.get(k)
        if condition(f['visibility_condition'],state):
            if f['required'] and condition(f['required_when'],state) and value is None and k not in isolated:errors.append(k+':required')
            if not valid_value(f,value,state):errors.append(k+':invalid')
    for c in p['constraints']:
        if condition(c['when'],state):errors.append(c['rule_id']+':forbidden')
    output={k:v for k,v in state.items() if k in fields and (fields[k]['roles']['print'] or fields[k]['roles']['runtime']) and fields[k]['knowledge_status'] not in ['NOT_APPLICABLE','OUT_OF_SCOPE']}
    return not errors,output,errors

def validate(p,baseline=None,policy=None,decision=None,project_qa=None):
    metrics={k:0 for k in METRICS};findings=[]
    def issue(code,target,reason,blocking=True):
        metrics[code]+=1;findings.append({'code':code,'target':target,'reason':reason,'blocking':blocking})
    def result():
        blocked=sum(x['blocking'] for x in findings)
        ok=blocked==0
        safe=p if isinstance(p,dict) else {}
        return {'status':'PASS' if ok else 'FAIL','field_count':len(safe.get('fields',[])) if isinstance(safe.get('fields'),list) else 0,'metrics':metrics,'blocker_count':blocked,'gates':{'QA_READY':'PASS_CANDIDATE' if ok else 'FAIL','QA_PASS':'PASS' if ok else 'FAIL','FORMAL_CANDIDATE':('PASS_CANDIDATE' if ok else 'FAIL') if safe.get('lifecycle_status')=='FORMAL_CANDIDATE' else 'NOT_REQUESTED','FORMAL':'CLAIM_VALIDATED' if ok and safe.get('lifecycle_status')=='FORMAL' else 'NOT_PROMOTED'},'findings':findings,'package_sha256':digest(p),'limitations':['Manufacturer fact truth, Source applicability and Decision authenticity require actual Authority review.','Candidate gate does not replace Project official Gate.']}
    try:
        from jsonschema import Draft202012Validator
        schema=json.loads((Path(__file__).resolve().parents[1]/'schemas/work-package.schema.json').read_text())
        for e in Draft202012Validator(schema).iter_errors(p):issue('SCHEMA_ERROR','/'.join(map(str,e.path)),e.message)
    except ImportError:
        issue('CRITICAL_VALIDATION_ERROR','runtime','jsonschema unavailable; QA not executed')
    if metrics['SCHEMA_ERROR'] or metrics['CRITICAL_VALIDATION_ERROR']:return result()
    fields={f['field_id']:f for f in p['fields']};sources={s['source_id']:s for s in p['sources']};evidence={e['evidence_id']:e for e in p['evidence']}
    for label,rows,key in [('fields',p['fields'],'field_id'),('sources',p['sources'],'source_id'),('evidence',p['evidence'],'evidence_id'),('constraints',p['constraints'],'rule_id'),('gaps',p['gaps'],'gap_id'),('tests',p['handoff_tests'],'case_id')]:
        seen=set()
        for r in rows:
            if r[key] in seen:issue('DUPLICATE_ID',r[key],label)
            seen.add(r[key])
    if not fields or not p['scope']['required_fields']:issue('CRITICAL_VALIDATION_ERROR','scope','empty field set or required Scope')
    for k in p['scope']['required_fields']:
        if k not in fields:issue('ORPHAN_FIELD',k,'missing Scope Field')
        elif not fields[k]['required']:issue('CRITICAL_VALIDATION_ERROR',k,'Scope requires Field but required=false')
    old={f['field_id']:f for f in (baseline or {}).get('fields',[])}
    if baseline:
        if p['product']['product_id']!=baseline['product']['product_id']:issue('CRITICAL_VALIDATION_ERROR','baseline','cross-product baseline')
        if p['provenance']['baseline_hash']!=digest(baseline):issue('CRITICAL_VALIDATION_ERROR','baseline','baseline hash mismatch')
        if p['work_type'] in ('CARRY-FORWARD','QA ONLY') and p['fields']!=baseline['fields']:issue('CRITICAL_VALIDATION_ERROR','work_type','non-change Work changed Fields')
        if p['work_type']=='EVIDENCE CLOSURE':
            fact_projection=lambda rows:[{k:v for k,v in row.items() if k not in ('evidence_id','source','lifecycle_status')} for row in rows]
            if fact_projection(p['fields'])!=fact_projection(baseline['fields']):issue('CRITICAL_VALIDATION_ERROR','work_type','Evidence Closure changed Product Facts; use CHANGE WORK')
        for k,f in old.items():
            if f['lifecycle_status']=='FORMAL' and k in fields:
                stripped=lambda x:{key:v for key,v in x.items() if key!='lifecycle_status'}
                if stripped(f)==stripped(fields[k]) and fields[k]['lifecycle_status']!='FORMAL':issue('CRITICAL_VALIDATION_ERROR',k,'unchanged Formal downgraded')
    elif p['work_type'] in ('CARRY-FORWARD','CHANGE WORK','QA ONLY','EVIDENCE CLOSURE'):
        issue('CRITICAL_VALIDATION_ERROR','baseline','existing Work requires baseline')
    old_evidence={e['evidence_id']:e for e in (baseline or {}).get('evidence',[])}
    old_sources={s['source_id']:s for s in (baseline or {}).get('sources',[])}
    def inherited(f):
        if not (baseline and old.get(f['field_id'])==f and f['lifecycle_status']=='FORMAL'):return False
        ids=set(f['evidence_id'])|{eid for o in f['selectable_values'] for eid in o['evidence_ids']}
        for eid in ids:
            e=evidence.get(eid)
            if not e or old_evidence.get(eid)!=e or old_sources.get(e['source_id'])!=sources.get(e['source_id']):return False
        return True
    for s in sources.values():
        ident=s['content_identifier']
        if ident['kind'].startswith('SHA256') and (len(ident['value'])!=64 or any(c not in '0123456789abcdef' for c in ident['value'])):issue('SCHEMA_ERROR',s['source_id'],'invalid SHA256')
        if ident['kind']=='IMMUTABLE_VERSION' and (ident['value'].startswith(('http://','https://')) or ident['value']=='REPLACE'):issue('SCHEMA_ERROR',s['source_id'],'URL/placeholder is not immutable version')
    for e in evidence.values():
        s=sources.get(e['source_id'])
        if not s:issue('MISSING_EVIDENCE',e['evidence_id'],'Source missing');continue
        pairs=[('source_identity','identity'),('source_type','type'),('source_authority','authority'),('source_version','version'),('content_identifier','content_identifier')]
        if any(e[a]!=s[b] for a,b in pairs):issue('CONFLICTING_EVIDENCE',e['evidence_id'],'Evidence identity/version differs from Source')
        if e['decision_status']=='ACCEPTED' and not e['decision_ref']:issue('MISSING_EVIDENCE',e['evidence_id'],'Accepted Decision reference missing')
        for k in e['applicable_fields']:
            if k not in fields:issue('ORPHAN_FIELD',k,'Evidence Field missing')
        for c in e['claims']:
            if c['field_id'] not in e['applicable_fields']:issue('MISSING_EVIDENCE',e['evidence_id'],'Claim outside applicable Fields')
    def supports(ids,k,claim,value=None,fact=True):
        for eid in ids:
            e=evidence.get(eid);s=sources.get(e['source_id']) if e else None
            if not e or not s or e['decision_status'] not in ('VERIFIED','ACCEPTED'):continue
            if k not in e['applicable_fields']:continue
            if s['product_id']!=p['product']['product_id'] or s['manufacturer']!=p['product']['manufacturer']:continue
            if fact and s['authority']=='project_authority':continue
            if s['status']=='BASELINE' and not inherited(fields[k]):continue
            if not any(c['field_id']==k and c['claim']==claim and (value is None or c['value']==value) for c in e['claims']):continue
            return True
        return False
    for k,f in fields.items():
        gaps=[g for g in p['gaps'] if k in g['field_ids']]
        isolated=any(g['classification']!='Blocker' and not g['result_in_scope'] for g in gaps)
        if f['product_id']!=p['product']['product_id']:issue('ORPHAN_FIELD',k,'cross-product Field')
        if not f['semantic_role']:issue('UNMAPPED',k,'semantic_role missing')
        if not any(f['roles'].values()):issue('ORPHAN_FIELD',k,'no business role')
        if f['knowledge_status'] in ('UNKNOWN','UNRESOLVED'):
            issue('UNKNOWN',k,'unresolved Fact',not isolated)
            if f['default'] is not None or f['selectable_values']:issue('INVALID_OPTION',k,'unresolved Field contains asserted values')
            if not gaps:issue('CRITICAL_VALIDATION_ERROR',k,'unresolved Field has no Gap')
            if f['lifecycle_status']=='FORMAL':issue('CRITICAL_VALIDATION_ERROR',k,'unresolved Fact self-declared Formal')
        if f['knowledge_status']=='OUT_OF_SCOPE' and not any(g['classification']=='Out of Scope' for g in gaps):issue('OUT_OF_SCOPE_FIELD',k,'excluded Field without Scope Gap')
        if f['knowledge_status'] not in ('UNKNOWN','UNRESOLVED','OUT_OF_SCOPE') and not supports(f['evidence_id'],k,'field_fact'):issue('MISSING_EVIDENCE',k,'Field Fact Claim missing')
        for sid in f['source']:
            if sid not in sources:issue('MISSING_EVIDENCE',k,'Field Source missing')
        bound_ids=set(f['evidence_id'])|{eid for o in f['selectable_values'] for eid in o['evidence_ids']}
        bound_sources={evidence[eid]['source_id'] for eid in bound_ids if eid in evidence}
        if not bound_sources<=set(f['source']):issue('MISSING_EVIDENCE',k,'Field source does not include its bound Evidence Sources')
        values=[]
        if f['data_type'] in ('enum','multi_enum') and f['knowledge_status']=='KNOWN' and not f['selectable_values']:issue('INVALID_OPTION',k,'known enum empty')
        if f['data_type'] not in ('enum','multi_enum') and f['selectable_values']:issue('INVALID_OPTION',k,'non-enum has options')
        for o in f['selectable_values']:
            if o['value'] is None or o['value'] in values:issue('INVALID_OPTION',k,'null or duplicate option')
            values.append(o['value'])
            if not supports(o['evidence_ids'],k,'option',o['value']):issue('MISSING_EVIDENCE',k,'Option Claim missing: '+repr(o['value']))
        if f['minimum'] is not None and f['maximum'] is not None and f['minimum']>f['maximum']:issue('INVALID_OPTION',k,'inverted numeric bounds')
        if f['default'] is not None:
            if not valid_value(f,f['default'],{x['field_id']:x['default'] for x in fields.values()}):issue('INVALID_OPTION',k,'invalid default')
            if not supports(f['evidence_id'],k,'default',f['default'],False):issue('MISSING_EVIDENCE',k,'default requires Claim')
        deps=set(f['dependency']);conds=[f['visibility_condition'],f['required_when']]+[o['when'] for o in f['selectable_values']]
        used=set().union(*(refs(c) for c in conds))
        for target in deps|used:
            if target not in fields:issue('BROKEN_DEPENDENCY',k,'reference missing: '+target)
        if used-deps-{k}:issue('BROKEN_DEPENDENCY',k,'condition dependency undeclared')
        resets={r['on_change'] for r in f['reset_condition']}
        if deps-resets:issue('BROKEN_RESET',k,'upstream Reset missing')
        if resets-deps:issue('BROKEN_RESET',k,'Reset references non-dependency')
        for parent in deps:
            if not supports(f['evidence_id'],k,'dependency',parent,False):issue('MISSING_EVIDENCE',k,'Dependency Claim missing')
            if not any(parent in t['changes'] and t['before'].get(parent)!=t['changes'][parent] for t in p['handoff_tests']):issue('BROKEN_RESET',k,'Reset transition untested')
        if f['roles']['derived']:
            calculation_pass=bool(project_qa and project_qa.get('package_sha256')==digest(p) and project_qa.get('report_ref') and project_qa.get('result')=='PASS' and 'calculation' in project_qa.get('areas',[]) and k in project_qa.get('covered_fields',[]))
            if not supports(f['evidence_id'],k,'calculation',fact=False):issue('MISSING_EVIDENCE',k,'calculation Authority Claim missing')
            if not calculation_pass:issue('CRITICAL_VALIDATION_ERROR',k,'derived calculation requires retrieved package-bound Project QA report')
    def walk(k,trail,done):
        if k in trail:return True
        if k in done:return False
        trail=trail|{k}
        if any(walk(x,trail,done) for x in fields[k]['dependency'] if x in fields):return True
        done.add(k);return False
    done=set()
    if any(walk(k,set(),done) for k in fields):issue('BROKEN_DEPENDENCY','graph','dependency cycle')
    for g in p['gaps']:
        if g['classification']=='Blocker':issue('CRITICAL_VALIDATION_ERROR',g['gap_id'],g['reason'])
        if set(g['field_ids'])-fields.keys():issue('ORPHAN_FIELD',g['gap_id'],'Gap refers to missing Field')
    for c in p['constraints']:
        if refs(c['when'])-set(c['field_ids']) or set(c['field_ids'])-fields.keys():issue('BROKEN_DEPENDENCY',c['rule_id'],'constraint references missing/undeclared Field')
        for k in c['field_ids']:
            if k in fields and not supports(c['evidence_ids'],k,'constraint',c['rule_id'],False):issue('MISSING_EVIDENCE',c['rule_id'],'Constraint Claim missing')
        states=[dict(t['before'],**t['changes']) for t in p['handoff_tests']]
        if not any(condition(c['when'],s) for s in states) or not any(not condition(c['when'],s) for s in states):issue('CRITICAL_VALIDATION_ERROR',c['rule_id'],'Constraint true/false coverage missing')
    if not p['handoff_tests']:issue('CRITICAL_VALIDATION_ERROR','handoff','Handoff QA not run')
    if not any(t['expected_valid'] for t in p['handoff_tests']) or not any(not t['expected_valid'] for t in p['handoff_tests']):issue('CRITICAL_VALIDATION_ERROR','handoff','positive/negative cases required')
    for t in p['handoff_tests']:
        try:
            valid,output,errors=handoff(p,t)
            if valid!=t['expected_valid'] or output!=t['expected_output']:issue('CRITICAL_VALIDATION_ERROR',t['case_id'],'Handoff mismatch '+json.dumps({'valid':valid,'output':output,'errors':errors},ensure_ascii=False))
        except (KeyError,ValueError,TypeError) as e:issue('CRITICAL_VALIDATION_ERROR',t['case_id'],'Handoff not executable: '+str(e))
    for k,f in fields.items():
        isolated=any(k in g['field_ids'] and g['classification']!='Blocker' and not g['result_in_scope'] for g in p['gaps'])
        if f['required'] and f['knowledge_status']=='KNOWN' and not isolated:
            covered=False
            for t in p['handoff_tests']:
                try:
                    valid,output,errors=handoff(p,t)
                    if not t['expected_valid'] and k+':required' in errors:covered=True
                except (KeyError,ValueError,TypeError):pass
            if not covered:issue('CRITICAL_VALIDATION_ERROR',k,'visible required Field missing-value QA not executed')
    promoted=[f['field_id'] for f in fields.values() if f['lifecycle_status']=='FORMAL' and not inherited(f)]
    if p['lifecycle_status']=='FORMAL' and any(f['lifecycle_status']!='FORMAL' and f['knowledge_status'] not in ('UNKNOWN','UNRESOLVED','OUT_OF_SCOPE') for f in fields.values()):issue('CRITICAL_VALIDATION_ERROR','FORMAL','known Field not Formal')
    if promoted or (p['lifecycle_status']=='FORMAL' and not baseline):
        proof=bool(policy and decision and policy.get('policy_id')==p['provenance']['policy_ref'] and decision.get('policy_id')==policy.get('policy_id') and decision.get('payload_sha256')==digest(p) and decision.get('decision_ref') and decision.get('decision')=='ADOPT' and set(promoted)<=set(decision.get('field_ids',[])))
        if not proof:issue('CRITICAL_VALIDATION_ERROR','FORMAL','retrieved Policy and payload-bound adoption Decision required')
        elif policy.get('human_required',True) and decision.get('actor_kind')!='HUMAN':issue('CRITICAL_VALIDATION_ERROR','FORMAL','Human Decision required by Policy')
        if policy and policy.get('evidence_acceptance_required',False):
            for f in fields.values():
                ids=set(f['evidence_id'])|{eid for o in f['selectable_values'] for eid in o['evidence_ids']}|{eid for c in p['constraints'] if f['field_id'] in c['field_ids'] for eid in c['evidence_ids']}
                if f['field_id'] in promoted and any(evidence.get(eid,{}).get('decision_status')!='ACCEPTED' for eid in ids):issue('MISSING_EVIDENCE',f['field_id'],'Formal Evidence Acceptance required')
    return result()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('package');parser.add_argument('--baseline');parser.add_argument('--policy');parser.add_argument('--decision');parser.add_argument('--project-qa');parser.add_argument('--out');args=parser.parse_args()
    try:
        read=lambda f:json.loads(Path(f).read_text()) if f else None
        report=validate(read(args.package),read(args.baseline),read(args.policy),read(args.decision),read(args.project_qa))
    except (ValueError,KeyError,TypeError,OSError) as e:report={'status':'FAIL','error':str(e),'gates':{'QA_READY':'FAIL','QA_PASS':'NOT_RUN'}}
    text=json.dumps(report,ensure_ascii=False,indent=2)
    if args.out:Path(args.out).write_text(text+'\n')
    else:print(text)
    return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
