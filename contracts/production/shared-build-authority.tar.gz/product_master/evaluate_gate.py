#!/usr/bin/env python3
"""Project profile evaluator: select the native QA result, without running QA twice."""
import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from harness.core import read_json, write_json

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--qa', required=True)
    p.add_argument('--gate', required=True)
    p.add_argument('--out', required=True)
    args = p.parse_args()
    qa = read_json(args.qa)
    write_json(args.out, {'gate': args.gate, 'result': qa['gates'][args.gate], 'package_sha256': qa['package_sha256'], 'limitations': qa['limitations']})
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
