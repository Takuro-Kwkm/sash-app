---
name: product-master-builder
description: 新規の商品マスターを公式資料とCurrent Registryから作成し、Evidence・依存条件・制約・native QA・候補保存を整える。既存FormalがあればCarry-Forwardまたはproduct-change-workへ渡し、実行と再開はShared Harness v2へ委譲する。
---

# Product Master Builder

このSkillは、取得できなかった外部Skill原本の復元ではなく、GA済みv2 Contractから新規にCanonical化した入口である。[由来と責務](../../docs/architecture-v2/canonical-skills.md)を参照する。

1. 中央remote default branchのCurrent Architecture / Skill Authorityを取得する。consumerの採用implementation pin、Current Product Registry、Formal / Working、Source baseline、ACTIVE Information Source Manifest、native governing / completion / storage rulesを実取得し、HEAD・版・bytes hashをWork入力へ固定する。取得失敗をRegistry上の不存在にしない。
2. 新規作成Intentは中央 `scripts/architecture-work.py` で対象Repository・商品・native build profileを解決する。profile未採用なら `NATIVE_BUILD_PROFILE_REQUIRED` で停止する。Reference Fixtureや変更Adapterを新規作成に転用しない。既存Formalがある場合は `product_master/domain.py` の既存planning Contractに従い、無変更はCarry-Forward、既存Factの変更は `$product-change-work` へ渡す。
3. 公式本文・表・図・注記をnative Scopeで確認する。Sourceの版、適用範囲、Evidence IDとLocatorを固定し、Field、Dependency、Constraint、Gapをレビュー済み観測として構成する。価格・BOM・Set CodeやメーカーFactを推測しない。未確定はnative Unknown / HOLD / Controlled Unresolvedへ残す。
4. 採用済み `NEW_PRODUCT_MASTER_BUILD` Profileでは native `scripts/production/product-master-build.py` を通常モードで実行する。`--harness-root`、短文 `--instruction`、実取得Registry responseの `--registry-observation`、外部作業領域 `--work-root` とその領域内の `--out` を渡す。通常モードは中央remote default branchをfresh取得して互換性を検証し、immutable bindingと公式Source取得要求を保存して実Workを開始する。`--plan-only` は明示診断に限定し、新規作成依頼をplanningで終了しない。GA terminal indexは過去の完了証明であり、新Workをそのbootstrap HEADへ固定しない。Current契約非互換は `CURRENT_AUTHORITY_INCOMPATIBLE` で停止する。
5. 公式Sourceを実取得し、本文・表・図・注記からレビュー済み観測、Dependency、Constraint、Gap、Handoff Testを整える。実Source bytes/identity/version/locator/hashの `--source-inputs`、`--observations`、実行済み同一候補のbusiness Scope QA reportを指す `--project-qa`、ACTIVE native authority bytes/identity/hashの `--governance` を同じWorkへ渡す。Source待ちの永続Workは未完了であり、実取得できる要求を実行して続行する。`product_master/execution.py` はnative bindingを既存 `product_master/build.py`、native/domain Validator、`harness/workflow.py` のDAG・保存・Journal・Resumeへ接続する共通adapter。native engineを複製しない。candidate生成、QA_READY、候補保存、別経路readback、checkpoint、Human Review Packetまで実行する。fixtureを実商品QAや公式Sourceへ転用しない。
6. 既存Formal、Evidence、採用Decision、非影響Scope、revision lineageを保持し、必要なnative QAを実行する。QA_READYとFORMAL Candidate、Human Adoption、Field Promotion、Releaseを分ける。正式採用は固定Packetに対する既存の同一payloadの外部Decisionを消費し、AIはHuman Decisionを発行しない。
7. 要求されたGateまで、native Storage Contractに沿って保存、Registry、File ID / parent / revision、bytes hashをReadbackする。Checkpointは実入力・Journal・Receiptとともに指定Savepointへ保存する。再開は既存Harnessでbindingを再確認し、完了WorkはINSPECT_ONLY、変更は新しいsuccessorとする。

報告は新規/既存の判定、Source/Evidence、QAと候補状態、保存Readback、未解決条件を含める。Skillが検出されても未採用native build profileがREADYになったとは主張しない。
