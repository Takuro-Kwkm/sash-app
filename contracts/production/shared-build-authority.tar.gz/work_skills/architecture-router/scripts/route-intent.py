#!/usr/bin/env python3
"""Read-only Skill selection; native product resolution stays in the GA router."""
import argparse
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from harness.architecture import route_instruction
from harness.core import Blocked, read_json, require


def contains(text, term):
    pattern = re.escape(term.casefold())
    if term.isascii():
        pattern = r'(?<![a-z0-9])' + pattern + r'(?![a-z0-9])'
    return re.search(pattern, text.casefold()) is not None


def select_skill(root, instruction):
    root = Path(root).resolve()
    registry = read_json(root / 'registries/skill-authority.v2.json')
    require(registry['status'] == 'CURRENT', 'SKILL_AUTHORITY_NOT_CURRENT',
            'Acquire Current Skill Authority', 'SKILL_ROUTING')
    routes = registry['intent_routes']
    build = (any(contains(instruction, t) for t in routes['BUILD']['subject_terms'])
             and any(contains(instruction, t) for t in routes['BUILD']['intent_terms']))
    mutation = any(contains(instruction, t) for t in registry['mutating_intent_terms'])
    quality = any(contains(instruction, t) for t in routes['QUALITY']['intent_terms'])
    change = any(contains(instruction, t) for t in routes['CHANGE']['intent_terms'])
    require(not (build and mutation), 'WORK_TYPE_AMBIGUOUS',
            'Separate new-master creation and existing-master mutation', 'SKILL_ROUTING')
    kind = 'BUILD' if build else 'QUALITY' if quality and not mutation else 'CHANGE' if change else None
    require(kind is not None, 'WORK_TYPE_AMBIGUOUS',
            'Specify creation, existing change/current-state, or quality review', 'SKILL_ROUTING')
    name = routes[kind]['skill']
    matches = [s for s in registry['skills'] if s['name'] == name and s['status'].startswith('CURRENT')]
    require(len(matches) == 1, 'CANONICAL_SKILL_CONFLICT', name, 'SKILL_ROUTING')
    path = (root / matches[0]['path']).resolve()
    require(path.is_relative_to(root) and path.name == 'SKILL.md' and path.is_file(),
            'CANONICAL_SKILL_MISSING', name, 'SKILL_ROUTING')
    content = path.read_text()
    front = content.split('---', 2)
    match = re.search(r'^name:\s*(.*?)\s*$', front[1], re.M) if len(front) == 3 and not front[0].strip() else None
    require(match is not None and match.group(1).strip('\"\'') == name,
            'CANONICAL_SKILL_NAME_CONFLICT', name, 'SKILL_ROUTING')
    return {'state': 'SKILL_RESOLVED', 'selected_skill': name, 'intent': kind,
            'canonical_path': matches[0]['path'], 'native_execution': 'NOT_STARTED',
            'product_resolution': 'NOT_REQUESTED', 'legacy_selection': 0}


def dispatch(root, instruction, repositories=None, selected_product=None):
    result = select_skill(root, instruction)
    if repositories is None:
        return result
    try:
        native = route_instruction(root, repositories, instruction, selected_product)
    except Blocked as error:
        return {**result, 'state': 'FAIL_CLOSED', 'product_resolution': 'BLOCKED',
                'blocking_reason': error.data, 'reference_fallback': False}
    return {**result, 'state': 'ROUTED', 'product_resolution': 'RESOLVED_BY_CURRENT_ROUTER',
            'repository': native['repository'], 'product_id': native['product_id'],
            'native_route': native, 'reference_fallback': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--instruction', required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--intent-only', action='store_true')
    mode.add_argument('--repositories', help='Acquired repository -> checkout JSON map')
    parser.add_argument('--selected-product')
    args = parser.parse_args()
    try:
        repositories = read_json(args.repositories) if args.repositories else None
        result = dispatch(ROOT, args.instruction, repositories, args.selected_product)
    except (Blocked, OSError, KeyError, ValueError, TypeError) as error:
        result = {'state': 'FAIL_CLOSED', 'blocking_reason': getattr(error, 'data', {
            'code': 'AUTHORITY_ACQUISITION_REQUIRED', 'reason': str(error)}),
            'native_execution': 'NOT_STARTED', 'legacy_selection': 0, 'reference_fallback': False}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 2 if result['state'] == 'FAIL_CLOSED' else 0


if __name__ == '__main__':
    raise SystemExit(main())
