---
name: architecture-router
description: アプリ開発の短い指示から新規商品マスター、既存商品変更、QA/回帰のIntentを解決し、Current Registryの共通Skillへ渡す。Repository・商品・Adapterの解決は既存Architecture v2 routerに委譲し、未接続ScopeはFAIL_CLOSEDで止める。
---

# Architecture Skill Router

GA済みv2の単一Production routerは `scripts/architecture-work.py` のまま。このSkillは人のIntentからSkillを選ぶ入口として新規にCanonical化した。[由来と責務](../../docs/architecture-v2/canonical-skills.md)を参照する。

1. 中央remote default branchの `registries/current-architecture.v2.json` と `registries/skill-authority.v2.json` を実取得し、HEADと入力bytesを固定する。対象checkout、Current Product Registry / Formal / Source / Release / Resumeを確認する。過去Chatやconsumerの古いimplementation pinをlive Current selectorにしない。
2. 新規商品マスター作成は `$product-master-builder`、既存商品Fact/Source/仕様変更は `$product-change-work`、QA/Regression/Production readinessのレビューは `$app-quality-review` へ渡す。変更Workに含まれるQAはそのWorkのまま扱う。新規と既存変更が同時指定されるなど、Scopeが曖昧な指示は解決を求め、勝手に選ばない。
3. 検出可能なCanonical Skillのname/pathをCurrent Skill Registryと照合する。必要なら下記の読み取り専用host helperでIntent選択を確認する。商品指定がなければSkillだけを選択し、対象決定前に商品Workを開始しない。

```sh
python -B work_skills/architecture-router/scripts/route-intent.py --instruction '新規商品マスターを作成する' --intent-only
python -B work_skills/architecture-router/scripts/route-intent.py --instruction 'EWの最新版変更を確認して' --repositories ACQUIRED_REPOSITORY_MAP.json
```

4. Repository→checkout mapは実取得したものだけを渡す。Repository・商品Alias・Current Adapter・Validator・Scopeは既存Production routerが解決する。helperはSkill選択と既存routerへの委譲のみで、商品AliasやWorkflow・DAG・Evidence・Resume・CIを複製しない。
5. 新規作成のnative build profile未採用、PENDING Adapter、Authority不足、複数商品など、既存routerのBlockerをそのまま保持する。SKILL_RESOLVEDは商品実行READYやQA_PASSを意味しない。QUALITYはnative Validatorをレビューする入口であり、native商品の実行権限を拡張しない。
6. 解決したSkillへ入力Scopeとnative route / Blockerを一度だけ渡す。選択済みSkillからこのSkillへ無条件に戻して循環させない。実行は既存 `scripts/production-work.py`、再開は保存binding、完了WorkはINSPECT_ONLY。

このhelperは商品Work、QA、保存、merge、deploymentを開始しない。実行可能範囲はnative Contractと依頼Scopeで判断する。
