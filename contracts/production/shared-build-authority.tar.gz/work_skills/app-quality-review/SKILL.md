---
name: app-quality-review
description: 商品・Contract・Runtime・UIのQA、変更範囲の回帰、Browser/Output境界とProduction readinessをレビューする。Current native Validatorと既存Evidenceを使い、商品Fact変更や新規マスター作成は対応するWork Skillへ渡す。
---

# App Quality Review

このSkillはGA済みv2のnative Validator・QA/Output Contractから新規にCanonical化したレビュー入口である。[由来と責務](../../docs/architecture-v2/canonical-skills.md)を参照する。

1. 中央Current Architecture / Skill Authority、対象checkoutのCurrent pointer、Adapter / Validator Registry、Current Product Registry / Formal / Release / Resumeを実取得する。Repository・商品・版・入力hash・影響Scopeを固定し、過去ChatやFixtureをAuthorityにしない。
2. `$architecture-router` でQUALITY Intentを解決し、商品が明示された場合は既存 `scripts/architecture-work.py` を使ってnative Adapterを確認する。未READY商品の商品WorkはFAIL_CLOSEDのまま。QA入口の存在をAdapter昇格や本番実行権限と解釈しない。
3. native Validator Registry、Work DAGとRepositoryのQA Contractから、変更したField / Dependency / Runtime / UI / Outputに必要な検証を選ぶ。無変更のSource・Scope・rule・入力・artifactの既存EvidenceをCarry-Forwardし、結果だけの継承や無関係な全商品QAの再実行をしない。
4. Contract、runtime identity/parity、Dependency / Visibility / Required / Clear、Generic UI、Scope isolation、未知値/Controlled Unresolvedを検証する。商品Factの欠陥はFormal原本側の変更Workへ渡し、Adapter/UIの推測ルールで隠さない。
5. Browser QAは実renderingと操作を確認する。幅を指定された回帰はその幅のBrowserで確認し、Print PASSは実Print Previewまたは保存して視覚確認したPDFで判定する。OutputとPersistenceの保証範囲は `registries/production-boundaries.v2.json` とnative Contractで決め、localStorageをLive DB E2Eと混同しない。
6. CI / Evidence / Resumeは既存Harness・CI Bridgeへ委譲する。実行していない検証はNOT_EXECUTEDまたは具体的Blockerにし、QA_READY、QA_PASS、Human Adoption、Formal、Merge、Releaseを区別する。Production readinessのレビューをdeploymentの許可にしない。

Scope、実実行したValidator/Browser/Output、入力と結果hash、Carry-Forwardの根拠、PASS/FAIL/NOT_EXECUTEDと未解決条件を報告する。このSkillは第二のQA/Evidence Engineを実装しない。
