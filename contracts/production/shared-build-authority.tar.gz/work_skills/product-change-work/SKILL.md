---
name: product-change-work
description: カタログ改訂、新版カタログ、仕様変更、選択肢・寸法範囲・依存条件の変更、EvidenceによるGap解消を既存FORMAL Product Masterへ差分反映する。旧新版の全Scope比較、影響範囲、Carry-Forward、候補更新、QA、固定正式採用Packetを担当し、Authority・DAG・保存照合・再開・CIはShared Harness v2へ委譲する。新規商品マスターはproduct-master-builderを使用する。
---

# Product Change Work v2

Version: `2.1.0-production-connection`. 既存FORMALを基準に、差分と逆依存だけを更新する。

## 中央実行入口

1. 接続済みGitHubで `Takuro-Kwkm/product-ui-contracts` のremote mainと `AGENTS.md`、`docs/harness/v2.md`、`docs/harness/phase2.md`、`registries/work-routing.v2.json` を実取得する。Productionはconsumerの `contracts/production/work-connections.v2.json` を取得し、`scripts/production-work.py route` とnative prepare adapterを使う。`docs/harness/phase3.md` のHost bridgeを参照する。Skill内の過去SHAをCurrentにしない。Project Currentとconsumer adoption pinを分ける。
2. live CURRENT_INFORMATION_SOURCE_MANIFESTを実取得し、既存 `scripts/product-harness.py bootstrap` の許可済み取得要求を実行する。Current Product Registry、Current Formal/Working、旧採用Source、候補新版、Change/Completion/Evidence/Storage Policyを取得する。Registry未取得を既存なしにしない。
3. 商品別native Workflow / Validatorと `product_change/schemas/change-work.schema.json` に沿って入力を固定する。Current FormalはRegistryのrevisionと実bytes hashへ結ぶ。新版Sourceは `NEW_CANDIDATE / CANDIDATE` とし、Currentへ繰り上げない。入力・Source・Authority・runtime・Workflowの実hashをWork specへ固定する。
4. Sourceの本文、表、図、注記、Web field/portal/configurator、Source Registryの導線を全営業見積責務Scopeで比較する。PDF図表は視覚確認する。単なるhash一致や検索snippetを意味差分監査に代えない。適用日、商品、地域、工法、単位、版、document number、価格資料、採寸・寸法公式・施工条件・必要部材も比較する。
5. レビュー済み意味Projectionをnative adapterへ渡す。`COMPLETE_REVIEWED` とreview_ref、scope_id、全比較sectionを明記する。未確認の図注や抽出漏れは unresolvedへ置き、`NOT_DETERMINED / REVIEW_REQUIRED` でBlockする。参照Fixtureを実商品のAuthorityやメーカーFactに転用しない。
6. 差分を `product_change/domain.py` の分類ContractへMappingする。構造移動・名称整理・Web構造変更を商品Fact変更と即断しない。影響Field、Dependency、Constraint、Evidence、Mapping、Runtime/UI consumerの逆依存closureを固定する。Impact外の編集を入れない。
7. Current Formal、旧Evidence ID、Accepted Decision、非影響Field/Rule、履歴・revision lineageをCarry-Forwardする。変更内容だけWorking候補へ反映し、native QAを共通Harnessで実行する。意味不明やconsumer依存情報不足は unknown impactとしてBlockする。影響consumerを記録することと統合実行を分ける。
8. 要求Gateを保存・Registry・Readbackまで完走する。QA_READYをFORMALと呼ばない。正式採用要求ならReview Packetを固定し、外部の同じpayloadに対するHuman Decisionを消費する。AIがHuman Decisionを発行しない。承認済み同一payloadは再要求しない。

```sh
python scripts/run.py --harness-root /acquired/product-ui-contracts --root /work-input --spec /work-input/spec.json --work /durable/checkpoint --instruction 'EWの新版カタログとの差分を確認して正式反映して'
python scripts/run.py --harness-root /acquired/product-ui-contracts --root /work-input --work /durable/checkpoint --resume
```

実行状態、DAG、completed gate、ロック、出力hash、Storage、Resume、GitHub/CIは中央Harnessだけが管理する。Stage定義をSkill本文へ複製しない。Production runnerは `--live-state` に実取得したbranch応答を要求する。登録済みNative AdapterのScopeだけ実行し、接続未完了の商品はReferenceへfallbackせず限定Blockerを報告する。

## 差分なし・境界

- 全Scope比較を実行しProduct impactがNONEの場合はCurrent FORMALをbyte単位で維持する。Audit recordを保存し、新revisionを作らない。新版Sourceの採用は別の明示Authorityに従う。
- 新規MasterはBuilderへ渡す。Fact不変のEvidence Closureは互換入口として残す。旧 `catalog-diff` のdiff-only利用を残し、更新・ClosureはこのSkillへ渡す。
- Native XLSX/Sheets adapterがない場合はadapter gapを明記する。Fixture PASSで実商品を正式認定しない。Production Runtime/UI/Releaseはnative consumer Impactとユーザーの許可Scopeに従う。
- 停止後は保存したWork spec/入力/Journalを復元し、Current Authority、Registry、Master、Source hashes、runtime、completed outputを再検証する。変更があれば旧Workを改ざんせず、影響限定successorへ分岐する。

## Completion

要求Gate、delta分類、影響/非影響Scope、revision lineage、QA/QA_READY、正式採用状態、Packet/Decision、保存先の実bytes照合、未解決事項を報告する。ローカル保存は `cloud_sync=NOT_VERIFIED`。必要なクラウド保存はProject Storage Contractの実connector Receiptで確認する。

旧catalog-diffの差分確認だけを求められた場合は [catalog-diff-legacy.md](references/catalog-diff-legacy.md) のhelper手順を使用する。正式反映は共通Workflowを使う。

詳細Contractと移行境界は [change-contract.md](references/change-contract.md) を読む。
