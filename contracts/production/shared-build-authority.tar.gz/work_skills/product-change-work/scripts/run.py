#!/usr/bin/env python3
"""Work Skill adapter: route/dispatch to the acquired shared runner, without local lifecycle."""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--harness-root', required=True)
    p.add_argument('--root', required=True)
    p.add_argument('--work', required=True)
    p.add_argument('--spec')
    p.add_argument('--instruction')
    p.add_argument('--resume', action='store_true')
    p.add_argument('--stop-after')
    p.add_argument('--live-state', help='Fresh authenticated Production branch response')
    args = p.parse_args()
    central = Path(args.harness_root).resolve()
    if not (central / 'harness/workflow.py').is_file():
        raise SystemExit('Shared Harness v2 checkout missing')
    if args.resume:
        binding = json.loads((Path(args.work) / 'workflow-binding.json').read_text())
        spec_path = Path(args.work) / 'resume-spec.json'
        spec_path.write_text(json.dumps(binding['spec'], ensure_ascii=False))
    else:
        if not args.spec or not args.instruction:
            p.error('New work requires --spec and --instruction')
        spec_path = Path(args.spec)
        spec = json.loads(spec_path.read_text())
        if spec.get('production_binding'):
            sys.path.insert(0, str(central))
            from harness.architecture import route_instruction
            from harness.core import read_json
            config_path=Path(spec['production_routing']['path']).resolve()
            config=read_json(config_path)
            routed=route_instruction(central,{config['products'][0]['repository']:str(config_path.parents[2])},args.instruction,spec['target'])
            if routed['product_id']!=spec['target'] or routed['work_skill']!=spec['work_skill'] or routed['target_gate']!=spec['target_gate']:
                raise SystemExit('Production instruction and native Work spec disagree')
            if not args.live_state:p.error('Production requires --live-state from authenticated Current branch readback')
            command=[sys.executable,'-B',str(central/'scripts/production-work.py'),'run','--root',args.root,'--work',args.work,'--spec',str(spec_path),'--live-state',args.live_state]
            if args.stop_after:command+=['--stop-after',args.stop_after]
            return subprocess.run(command).returncode
        command = [sys.executable, '-B', str(central / 'scripts/workflow-harness.py'), 'route',
                   '--instruction', args.instruction, '--routing', str(central / 'registries/work-routing.v2.json'),
                   '--target', spec['target'], '--work-id', spec['workflow_id']]
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode:
            print(result.stdout)
            return result.returncode
        routed = json.loads(result.stdout)
        if any(routed[k] != spec[k] for k in ('work_skill', 'target_gate', 'target')):
            raise SystemExit('Instruction and bound Work spec disagree')
    env = dict(os.environ, PRODUCT_WORK_HARNESS_ROOT=str(central))
    spec = json.loads(spec_path.read_text())
    if spec.get('production_binding'):
        if not args.live_state:p.error('Production Resume requires fresh --live-state')
        command=[sys.executable,'-B',str(central/'scripts/production-work.py'),'resume','--root',args.root,'--work',args.work,'--spec',str(spec_path),'--live-state',args.live_state]
        if args.stop_after:command+=['--stop-after',args.stop_after]
        return subprocess.run(command,env=env).returncode
    command = [sys.executable, '-B', str(central / 'scripts/workflow-harness.py'), 'resume' if args.resume else 'run',
               '--root', args.root, '--work', args.work, '--spec', str(spec_path)]
    if args.stop_after:
        command += ['--stop-after', args.stop_after]
    return subprocess.run(command, env=env).returncode

if __name__ == '__main__':
    raise SystemExit(main())
