---
name: catalog-diff
description: 旧版・新版のSourceDocumentおよび公式Web Sourceの差分を検出し、ProductMaster、SpecificationDefinition、AllowedValue、RuleSet、EstimateRequiredFieldRule、Evidenceへの影響候補をレビュー用に生成する。
---

# Catalog Diff v2

## 対象
PDF改訂だけでなく以下を比較する。
- SourceDocument
- Product Page
- ESTIMATE_PORTAL
- CONFIGURATOR
- SourceRegistry導線
- Web Field構造

## 変更分類
- ADDED
- REMOVED
- CHANGED
- MOVED
- CLARIFIED
- SOURCE_CHANGED
- FIELD_STRUCTURE_CHANGED
- ALLOWED_VALUE_CHANGED
- DEPENDENCY_CHANGED
- UNRESOLVED

## 監視対象
- Product/Series
- SpecificationDefinition
- AllowedValue
- Required/Conditional
- 親子依存
- 採寸
- 寸法公式
- 製作範囲
- 施工条件
- 必要部材
- 価格資料の版
- Web contentFingerprint
- SourceRegistry URL/死活

## 実行手順
1. 同一Product/用途/仕様の比較対象を確定。
2. issueDate/revision/documentNumber/fingerprintを比較。
3. 本文、表、図、注記、Web fieldを差分抽出。
4. 変更の意味をEvidence候補として記録。
5. 影響するDefinition/Rule/Productを特定。
6. 自動上書きせずReview Candidateにする。
7. 過去案件のVersion再現性を維持する。

## 出力
```json
{
  "from": {},
  "to": {},
  "changes": [],
  "affected_entities": [],
  "review_candidates": [],
  "historical_impact": [],
  "unresolved": []
}
```

## 禁止事項
- 差分発見だけでACTIVEデータを自動上書き
- 新版発見で旧版削除
- Web構造変更を商品仕様変更と即断
