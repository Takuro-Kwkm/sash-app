# Change adapter Contract

中央 `product_change` はBuilderのnative sidecarを基準にしたreference adapter。
本体となるProjectのXLSX/Sheets/Registry/Scopeを自動発見・変換するものではない。
Hostはlive Authority、旧採用Source、新版公式Source、意味Projectionの完全性と真正性を確認する。

- Work identity: work_id/work_skill/product_id/work_type/change_reason/target_gate/starting_revision/candidate_revision。
- Harness spec: authority_index/authorities/registry/sources/workflow/input/runtime_refs/storage_root。
- Source roles: CURRENT_ADOPTED、NEW_CANDIDATE、PREVIOUS、PRIMARY_OFFICIAL、SUPPLEMENTAL、ARCHIVED。
- Delta: NO_CHANGE、TEXT_ONLY、PRESENTATION_ONLY、PRODUCT_FACT_CHANGE、FIELD_ADDED/REMOVED、OPTION_ADDED/REMOVED、RANGE_CHANGED、DEFAULT_CHANGED、DEPENDENCY_CHANGED、APPLICABILITY_CHANGED、FORBIDDEN_COMBINATION_CHANGED、SEMANTIC_CHANGE、SOURCE_AUTHORITY_CHANGE、UNKNOWN_REVIEW_REQUIRED。
- Review Packet: Product/revisions/Source refs/hashes/delta/before-after/Evidence/unresolved/QA/QA_READY/proposed final bytes/payload SHA256。
- Human gate binds both Work spec and native Packet. Import actor_kind=HUMAN, decision=APPROVED, gate=HUMAN_ADOPTION, real decision_ref and same wrapper payload_sha256. Host authenticates the external Decision; an actor_kind string alone is not proof of person identity.
- Candidate storage retains current_formal_revision. Only admitted Formal adoption sets new_source_role=CURRENT_ADOPTED in isolated projection. Live Registry writes need native CAS/storage adapter.
- No-change retains exact Current Master bytes, saves audit, and avoids Formal Decision replay. Historical projects keep old Sources/Decisions.

Read `docs/harness/phase2.md` from acquired current main for commands, fixtures, schemas, migration matrix and deferred native adapters.
