#!/usr/bin/env python3
"""Single Current architecture resolver; existing production-work runs its Work."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from harness.architecture import main
if __name__ == '__main__':
    sys.exit(main())
