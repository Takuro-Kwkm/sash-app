#!/usr/bin/env python3
"""Read-only check of the live terminal index against acquired Main observations."""
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from harness.core import read_json,require,sha,Blocked
from harness.production import connector_document
parser=argparse.ArgumentParser()
parser.add_argument('--index',required=True);parser.add_argument('--metadata',required=True)
parser.add_argument('--main-observations',required=True)
parser.add_argument('--checkouts',help='Acquired repository -> checkout map for Current compatibility')
parser.add_argument('--authority-root',help='Fresh acquired Central checkout')
args=parser.parse_args()
try:
 index=read_json(args.index);metadata=connector_document(read_json(args.metadata));mains=read_json(args.main_observations)
 require(metadata['id']=='1DnJflUJAIS5UfisxQa-AgTI6BPtZsoeI' and metadata['parent_ids']==['1NNx06iWLVEcM_FSn8CY6QOHpComEYiWa'],
         'GA_INDEX_LOCATION','Acquire the bound Current terminal index','GA')
 require(index['status']=='CURRENT' and index['state']=='ARCHITECTURE_V2_GA_COMPLETED','GA_NOT_COMPLETED','Terminal state is not complete','GA')
 require(index['pending_gates']==[] and index['pending_adoption']==0 and index['pending_merge'] is False
         and index['architecture_deviation']==0,'GA_PENDING_GATE','Unfinished GA work','GA')
 required={'PRE_GA_STATE_RECOVERY','THREE_PROJECT_COVERAGE_MATRIX','PERSISTENCE_BOUNDARY_RESOLVED',
           'REQUIRED_ADAPTER_CLOSURE','OUTPUT_BOUNDARY_RESOLVED','LEGACY_INVENTORY','LEGACY_RETIREMENT',
           'FINAL_ROUTER_AUTHORITY','CURRENT_ARCHITECTURE_AUTHORITY','SHORT_INSTRUCTION_PRODUCTION_ACCEPTANCE',
           'OPERATIONAL_RECOVERY','FINAL_THREE_PROJECT_REGRESSION','POST_MERGE_READBACK','FINAL_GA_CHECKPOINT'}
 require(required.issubset(index['completion_gates']) and all(v=='PASS' for v in index['completion_gates'].values()),
         'GA_FAILED_GATE','Required completion gates do not all pass','GA')
 require(set(index['heads'])=={'Takuro-Kwkm/product-ui-contracts','Takuro-Kwkm/sash-app','Takuro-Kwkm/interior-estimator',
                             'Takuro-Kwkm/exterior-estimator'},'GA_REPOSITORY_MISSING','Four Current Main observations required','GA')
 for repo,head in index['heads'].items():
  current=connector_document(mains[repo])
  if current['commit']['sha']!=head:
   require(args.checkouts and args.authority_root,'CURRENT_AUTHORITY_COMPATIBILITY_REQUIRED',repo+' advanced after GA; acquire Current compatibility, do not rewrite terminal index','GA')
   from harness.current_authority import verify_ga_successor
   verify_ga_successor(args.authority_root,read_json(args.checkouts),repo,head,current['commit']['sha'])
  checks=index['post_merge_ci'][repo]['checks']
  require(checks and all(c['head_sha']==head and c['status']=='completed' and c['conclusion']=='success' for c in checks),
          'GA_CI_BINDING',repo,'GA')
 result={'status':'PASS','state':index['state'],'index_sha256':sha(Path(args.index).read_bytes()),
         'ga_activation_heads':index['heads'],'heads':{r:connector_document(v)['commit']['sha'] for r,v in mains.items()},'policy':'HISTORICAL_GA_CI_PRESERVED; CURRENT_COMPATIBILITY_VALIDATED','pending_gates':[],'pending_adoption':0,'pending_merge':False,
         'legacy_selection':0,'architecture_deviation':0,'operation':'INSPECT_ONLY; next Work uses a new immutable binding'}
except (Blocked,OSError,KeyError,ValueError) as error:
 result={'status':'FAIL_CLOSED','blocking_reason':getattr(error,'data',{'reason':str(error)})}
print(json.dumps(result,ensure_ascii=False,indent=2))
sys.exit(0 if result['status']=='PASS' else 2)
