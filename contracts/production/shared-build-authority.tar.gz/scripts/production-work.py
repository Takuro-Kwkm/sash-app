#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from harness.production import main
if __name__ == '__main__':
    # Compatibility route alias delegates to the unique Current authority. The
    # original run/resume/checkpoint engine and immutable Work specs are intact.
    if len(sys.argv) > 1 and sys.argv[1] == 'route' and '--config' in sys.argv:
        import argparse
        import json
        from harness.architecture import route_instruction
        from harness.core import Blocked, read_json
        parser = argparse.ArgumentParser()
        parser.add_argument('command'); parser.add_argument('--config', required=True)
        parser.add_argument('--instruction', required=True); parser.add_argument('--selected-product')
        args = parser.parse_args()
        config_path = Path(args.config).resolve()
        config = read_json(config_path)
        if config.get('current_architecture_pointer'):
            checkout = config_path.parents[2]
            try:
                result = route_instruction(Path(__file__).resolve().parents[1],
                    {config['products'][0]['repository']: str(checkout)}, args.instruction, args.selected_product)
            except (Blocked, OSError, ValueError, KeyError) as error:
                result = {'state': 'FAIL_CLOSED', 'blocking_reason': getattr(error, 'data', {'reason': str(error)}),
                          'legacy_selection': 0, 'reference_fallback': False}
            print(json.dumps(result, ensure_ascii=False, indent=2))
            sys.exit(2 if result.get('state') == 'FAIL_CLOSED' else 0)
    sys.exit(main())
