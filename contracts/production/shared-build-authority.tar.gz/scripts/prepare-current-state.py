#!/usr/bin/env python3
"""Bind a native read-only acceptance profile to the unchanged v2 Work engine."""
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from harness.architecture import route_instruction
from harness.core import read_json, write_json, sha, require
from harness.production import repository_binding, observation_fingerprint


def prepare(repositories, captures, instruction, destination):
    central = Path(__file__).resolve().parents[1]
    route = route_instruction(central, repositories, instruction)
    require(route['operation'] == 'CURRENT_STATE', 'CURRENT_STATE_INTENT', 'This adapter never executes a mutation', 'PREPARE')
    checkout = Path(repositories[route['repository']]).resolve()
    contract = read_json(checkout / route['acceptance_contract'])['products'][route['product_id']]
    root = Path(destination).resolve()
    require(not (root / 'spec.json').exists(), 'IMMUTABLE_WORK_EXISTS', 'Inspect or resume this binding; do not overwrite it', 'PREPARE')
    root.mkdir(parents=True, exist_ok=True)
    raw = captures[route['repository']]
    def ref(path):
        path = Path(path).resolve()
        return {'path': str(path), 'sha256': sha(path.read_bytes())}
    captured = {p: checkout / p for p in contract['immutable_files']}
    binding = repository_binding(route['repository'], raw['branch'], raw['tree'], captured)
    binding['checkout'] = str(checkout)
    observations = {'native_registry': read_json(raw['native_registry']),
                    'information_manifest': read_json(raw['information_manifest'])}
    binding['observations'] = {k: observation_fingerprint(v) for k,v in observations.items()}
    write_json(root / 'repository-binding.json', binding)
    write_json(root / 'live-state.json', {'repository': raw['branch'], 'observations': observations})
    data = {'checkout': str(checkout), 'route': route, 'native_contract': contract,
            'native_registry': str(Path(raw['native_registry']).resolve()),
            'adopted_source_files': raw['adopted_source_files']}
    require(data['adopted_source_files'], 'SOURCE_ACQUISITION_REQUIRED', 'Current adopted source bytes required', 'PREPARE')
    for source in data['adopted_source_files']:
        require(sha(Path(source['path']).read_bytes()) == source['sha256'], 'SOURCE_HASH', source['path'], 'PREPARE')
    write_json(root / 'input.json', data)
    authority = {**ref(central / 'registries/current-architecture.v2.json'), 'authority_id': 'CURRENT_ARCHITECTURE_V2',
                 'authority_type': 'ARCHITECTURE', 'repository': 'Takuro-Kwkm/product-ui-contracts',
                 'version': '2.0.0', 'status': 'CURRENT', 'scope_axis': 'CONSUMER_ADOPTED',
                 'resolution_source': 'ACQUIRED_CURRENT_SHARED_REGISTRY'}
    write_json(root / 'authority-index.json', {'status': 'CURRENT', 'entries': [authority]})
    write_json(root / 'registry.json', {'registry_id': 'NATIVE_CURRENT_STATE_PROJECTION', 'version': contract['formal_revision'],
        'status': 'CURRENT', 'products': [{'product_id': route['product_id'], 'master_state': 'PRESENT', 'aliases': []}]})
    worker = ref(central / 'scripts/verify-current-state.py')
    steps = []
    for stage in ('SOURCE_RESOLUTION', 'IMPACT_SCOPE', 'FORMAL_READBACK', 'VALIDATOR_BINDING', 'RESUME_BINDING', 'SAFE_EXIT'):
        steps.append({'id': stage, 'kind': 'validator', 'needs': [steps[-1]['id']] if steps else [],
            'script': worker, 'args': ['--input', '{input}', '--stage', stage, '--output', '{work}/' + stage + '.json'],
            'output': '{work}/' + stage + '.json', 'result_path': ['status'], 'expected_result': 'PASS'})
    steps.append({'id': 'CHECKPOINT_STORAGE', 'kind': 'storage', 'needs': ['SAFE_EXIT'],
                  'source': '{work}/SAFE_EXIT.json', 'destination': '{workflow_id}/SAFE_EXIT.json'})
    write_json(root / 'workflow.json', {'workflow_id': 'NATIVE_CURRENT_STATE_V2', 'version': '2.0.0', 'status': 'CURRENT',
        'work_skill': 'product-change-work', 'steps': steps, 'targets': {'CURRENT_STATE_VERIFIED': ['CHECKPOINT_STORAGE']},
        'scope': 'READ_ONLY_ADOPTED_CURRENT_ACCEPTANCE; NO_MANUFACTURER_RESEARCH_OR_FORMAL_PROMOTION'})
    spec = {'workflow_id': root.name, 'work_skill': 'product-change-work', 'target': route['product_id'],
        'target_gate': 'CURRENT_STATE_VERIFIED', 'skill_root': str(central), 'authority_index': ref(root / 'authority-index.json'),
        'authorities': [authority], 'registry': ref(root / 'registry.json'), 'workflow': ref(root / 'workflow.json'),
        'input': ref(root / 'input.json'), 'production_binding': ref(root / 'repository-binding.json'),
        'production_routing': ref(checkout / 'contracts/production/work-connections.v2.json'),
        'sources': [{**ref(p['path']), 'source_id': p['source_id'], 'identity': p['identity'],
            'version': contract['formal_revision'], 'product_id': route['product_id'], 'status': 'ADOPTED', 'role': 'CURRENT_ADOPTED'}
                    for p in data['adopted_source_files']],
        'runtime_refs': [ref(p) for p in sorted((central / 'harness').glob('*.py'))] + [worker,
            ref(checkout / route['acceptance_contract']), ref(checkout / 'contracts/production/current-work.json')],
        'storage_root': str(root / 'saved')}
    write_json(root / 'spec.json', spec)
    return {'status': 'PREPARED_NATIVE_CURRENT_STATE', 'route': route, 'root': str(root),
            'spec': str(root / 'spec.json'), 'live_state': str(root / 'live-state.json'), 'work': str(root / 'checkpoint')}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    for key in ('repositories', 'captures', 'instruction', 'destination'):
        parser.add_argument('--' + key, required=True)
    args = parser.parse_args()
    try:
        result = prepare(read_json(args.repositories), read_json(args.captures), args.instruction, args.destination)
    except Exception as error:
        result = {'state': 'FAIL_CLOSED', 'blocking_reason': getattr(error, 'data', {'reason': str(error)})}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(2 if result.get('state') == 'FAIL_CLOSED' else 0)
