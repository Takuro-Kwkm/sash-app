#!/usr/bin/env python3
"""Read-only native Contract checks, dispatched by the existing Shared Work DAG.

This verifies the acquired adopted state, not a fresh manufacturer catalog audit.
The supplied native Contract fixes identity selectors and artifacts; it cannot
turn a CSV-empty N/A cell into a fact or produce a Formal/Human decision.
"""
import argparse
import csv
import io
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from harness.core import sha, require, read_json, write_json
from harness.production import connector_document


def verify(data, stage):
    contract = data['native_contract']
    checkout = Path(data['checkout'])
    require({s['source_id']: s['sha256'] for s in data['adopted_source_files']} == contract['adopted_source_byte_hashes'],
            'SOURCE_NATIVE_BINDING', 'Source identities must match the acquired native Contract', stage)
    for path, expected in contract['immutable_files'].items():
        require(sha((checkout / path).read_bytes()) == expected, 'CURRENT_NATIVE_BYTES_CHANGED', path, stage)
    for source in data['adopted_source_files']:
        require(sha(Path(source['path']).read_bytes()) == source['sha256'], 'ADOPTED_SOURCE_CHANGED', source['path'], stage)
    raw = connector_document(read_json(data['native_registry']))
    require(isinstance(raw, str), 'NATIVE_REGISTRY_ACQUISITION', 'Complete native Registry export required', stage)
    matches = []
    selector = contract['native_registry_selector']
    for section in raw.split('\f'):
        rows = list(csv.reader(io.StringIO(section)))
        if not rows or not all(k in rows[0] for k in list(selector) + list(contract['native_registry_expected'])):
            continue
        for row in rows[1:]:
            if len(row) != len(rows[0]):
                continue
            item = dict(zip(rows[0], row))
            if all(item.get(k) == v for k,v in selector.items()):
                matches.append(item)
    require(len(matches) == 1, 'NATIVE_REGISTRY_AMBIGUOUS', contract['product_id'], stage)
    require(all(matches[0].get(k) == v for k,v in contract['native_registry_expected'].items()),
            'CURRENT_FORMAL_REGISTRY_DRIFT', contract['product_id'], stage)
    for path in contract['native_validator_files']:
        require((checkout / path).is_file(), 'NATIVE_VALIDATOR_MISSING', path, stage)
    descriptor = read_json(checkout / 'contracts/production/current-work.json')
    require('terminal_policy' in descriptor, 'RESUME_UNRESOLVED', 'Terminal selection policy required', stage)
    return {'status': 'PASS', 'stage': stage, 'product_id': contract['product_id'],
            'formal_revision': contract['formal_revision'], 'source_scope': 'CURRENT_ADOPTED_ONLY',
            'source_result': 'SOURCE_UNCHANGED', 'impact_scope': 0,
            'no_formal_revision': True, 'no_downstream_change': True,
            'no_duplicate_adoption': True, 'native_write_count': 0,
            'validator_binding': contract['native_validator_files'],
            'resume_binding': 'IMMUTABLE_SPEC_HASH_AND_EXISTING_SHARED_JOURNAL',
            'safe_exit': 'SAFE_COMPLETE' if stage == 'SAFE_EXIT' else 'NEXT_BOUND_GATE',
            'latest_manufacturer_discovery': 'NOT_EXECUTED_BY_CURRENT_STATE_PATH'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True); parser.add_argument('--stage', required=True)
    parser.add_argument('--output', required=True); args = parser.parse_args()
    try:
        result = verify(read_json(args.input), args.stage)
    except Exception as error:
        result = {'status': 'FAIL', 'blocking_reason': getattr(error, 'data', {'reason': str(error)})}
    write_json(args.output, result)
    sys.exit(0 if result['status'] == 'PASS' else 2)
