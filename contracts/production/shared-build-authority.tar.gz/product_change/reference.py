"""Isolated synthetic Source comparison on inherited builder fixture structure."""
import copy
from pathlib import Path
from harness.core import fingerprint, read_json, sha, write_json
from product_change.domain import SECTIONS
ROOT=Path(__file__).resolve().parents[1]
GATES=['INITIALIZATION','AUTHORITY_RESOLUTION','REGISTRY_RESOLUTION','CURRENT_MASTER_ACQUISITION',
 'SOURCE_ACQUISITION','SOURCE_DELTA_AUDIT','IMPACT_SCOPE','CARRY_FORWARD','CHANGE_APPLICATION','QA','QA_READY','FORMAL_CHANGE_REVIEW']

def reference(destination, mode='change', target_gate='FORMAL_CANDIDATE'):
    root=Path(destination).resolve();root.mkdir(parents=True,exist_ok=True)
    def ref(path):
        p=Path(path);return {'path':str(p),'sha256':sha(p.read_bytes())}
    master=read_json(ROOT/'product_master/fixtures/baseline.json')
    write_json(root/'current-master.json',master)
    projection={s:copy.deepcopy(master[s]) for s in SECTIONS}
    current={'source_id':'fixture-current','product_id':master['product']['product_id'],'scope_id':master['scope']['scope_id'],
             'comparison_status':'COMPLETE_REVIEWED','review_ref':'SYNTHETIC_FIXTURE_ONLY','projection':projection,'text':'old','presentation':'table','unresolved':[]}
    new=copy.deepcopy(current);new.update(source_id='fixture-new',text='new edition')
    if mode=='change':
        # Independent new Evidence ID; accepted old decisions/claims remain unchanged.
        source=copy.deepcopy(master['sources'][1]);source.update(source_id='S-CANDIDATE',identity='ISOLATED_NEW_SOURCE',version='2',status='CANDIDATE')
        source['content_identifier']['value']=sha(b'SYNTHETIC_OPTION_Z_FACT')
        evidence=copy.deepcopy(master['evidence'][1]);evidence.update(evidence_id='E-CANDIDATE',source_id=source['source_id'],source_identity=source['identity'],
             source_version=source['version'],content_identifier=source['content_identifier'],decision_status='VERIFIED',decision_ref=None,supporting_fact='SYNTHETIC_FIXTURE: roof option Z')
        evidence['claims']=[{'field_id':'roof_material','claim':'field_fact','value':None},{'field_id':'roof_material','claim':'option','value':'Z'}]
        field=new['projection']['fields'][2];field['selectable_values'].append({'value':'Z','label':'Fixture Z','when':True,'evidence_ids':['E-CANDIDATE']})
        field['evidence_id'].append('E-CANDIDATE');field['source'].append('S-CANDIDATE')
        new['projection']['sources'].append(source);new['projection']['evidence'].append(evidence)
        new['projection']['handoff_tests'].append({'case_id':'new-Z-positive','before':{'variant':'SC-STD-1','wind_v0_mps':40,'roof_material':'Z'},'changes':{},'expected_valid':True,
          'expected_output':{'variant':'SC-STD-1','wind_v0_mps':40,'roof_material':'Z'}})
    elif mode=='unknown': new['unresolved']=['Uninterpreted diagram/footnote']
    elif mode!='no-change': raise ValueError(mode)
    write_json(root/'current-source.json',current);write_json(root/'new-source.json',new)
    source_refs=[{**ref(root/(name+'-source.json')),'source_id':doc['source_id'],'identity':'ISOLATED_SYNTHETIC_'+name.upper(),
      'version':'1' if name=='current' else '2','product_id':master['product']['product_id'],'status':'CURRENT' if name=='current' else 'CANDIDATE',
      'role':'CURRENT_ADOPTED' if name=='current' else 'NEW_CANDIDATE'} for name,doc in [('current',current),('new',new)]]
    row={'product_id':master['product']['product_id'],'aliases':['TW fixture','EW fixture'],'master_state':'PRESENT','lifecycle_state':'FORMAL',
        'formal_revision':master['product']['revision'],'formal_sha256':ref(root/'current-master.json')['sha256'],
        'current_source_id':source_refs[0]['source_id'],'current_source_sha256':source_refs[0]['sha256']}
    write_json(root/'registry.json',{'registry_id':'ISOLATED_CHANGE_FIXTURE','version':'2','status':'CURRENT','products':[row]})
    write_json(root/'policy.json',{'policy_id':master['provenance']['policy_ref'],'human_required':True,'evidence_acceptance_required':False,'scope':'SYNTHETIC_ONLY'})
    work_id='change-v2-'+mode
    contract={'work_id':work_id,'work_skill':'product-change-work','product_id':row['product_id'],'work_type':'PRODUCT_MASTER_CHANGE',
       'change_reason':'Isolated catalogue delta fixture','target_gate':target_gate,'starting_revision':row['formal_revision'],
       'candidate_revision':'v0.2-change-fixture','current_master':ref(root/'current-master.json'),'policy':ref(root/'policy.json'),
       'sources':source_refs,'storage_root':str(root/'saved'),'decision_path':str(root/'decision.json'),
       'stored_artifacts':[g+'.json' for g in GATES]+['FORMAL_CHANGE_ADOPTION.json','selected-master.json','registry-projection.json','human-decision.json']}
    write_json(root/'contract.json',contract)
    worker=ref(ROOT/'product_change/worker.py')
    steps=[]
    def native(g, needs):
        return {'id':g,'kind':'build' if g in ('CHANGE_APPLICATION','FORMAL_CHANGE_REVIEW') else 'validator','needs':needs,'script':worker,
         'args':['--stage',g,'--contract','{input}','--registry','{registry}','--root','{root}','--work','{work}','--out','{work}/'+g+'.json'],
         'output':'{work}/'+g+'.json','result_path':['status'],'expected_result':'PASS'}
    for g in GATES: steps.append(native(g,[steps[-1]['id']] if steps else []))
    if target_gate=='FORMAL_CHANGE_ADOPTION':
        prepared=[]
        for g in GATES:
            ident='PRE_REVIEW_STORAGE_'+g
            steps.append({'id':ident,'kind':'storage','needs':['FORMAL_CHANGE_REVIEW'],'source':'{work}/'+g+'.json',
                          'destination':'review-candidates/{workflow_id}/'+g+'.json'})
            prepared.append(ident)
        steps.append({'id':'HUMAN_ADOPTION','kind':'human','needs':prepared,'packet':'{work}/FORMAL_CHANGE_REVIEW.json',
          'packet_destination':'review-candidates/{workflow_id}/bound-human-packet.json',
          'when':{'source':'{work}/SOURCE_DELTA_AUDIT.json','result_path':['product_impact'],'allowed_values':['CHANGED','NONE'],'equals':'CHANGED'}})
    adoption=native('FORMAL_CHANGE_ADOPTION',[steps[-1]['id']]);adoption['side_outputs']=['{work}/selected-master.json','{work}/registry-projection.json','{work}/human-decision.json'];steps.append(adoption)
    storage_ids=[]
    for i,name in enumerate(contract['stored_artifacts']):
        ident='STORAGE' if i==0 else 'STORAGE_'+str(i)
        steps.append({'id':ident,'kind':'storage','needs':['FORMAL_CHANGE_ADOPTION'],'source':'{work}/'+name,'destination':'{workflow_id}/'+name});storage_ids.append(ident)
    steps.append({'id':'REGISTRY_UPDATE','kind':'registry-output','needs':storage_ids,'source':'{work}/registry-projection.json',
         'destination':'reference-change-registry.json','entry_keys':['product_id','current_formal_revision','candidate_revision','adoption_state','master_sha256','new_source_role']})
    steps.append(native('READBACK',['REGISTRY_UPDATE']));steps.append(native('COMPLETION',['READBACK']))
    profile={'workflow_id':'product-change-v2-reference','version':'2.0.0-reference','status':'CURRENT','work_skill':'product-change-work',
      'scope':'SYNTHETIC_FIXTURE_ONLY; native Project adapter required for live products','steps':steps,'targets':{target_gate:['COMPLETION']}}
    write_json(root/'workflow.json',profile)
    authority={**ref(root/'workflow.json'),'authority_id':'change-workflow','authority_type':'WORKFLOW','repository':'ISOLATED_FIXTURE',
      'version':'2.0.0-reference','status':'CURRENT','scope_axis':'PROJECT_CURRENT','resolution_source':'ISOLATED_FIXTURE'}
    policy_authority={**ref(root/'policy.json'),'authority_id':'change-policy','authority_type':'COMPLETION_POLICY','repository':'ISOLATED_FIXTURE',
      'version':'1','status':'CURRENT','scope_axis':'PROJECT_CURRENT','resolution_source':'ISOLATED_FIXTURE'}
    write_json(root/'authority-index.json',{'status':'CURRENT','entries':[authority,policy_authority]})
    spec={'workflow_id':work_id,'work_skill':'product-change-work','target':row['product_id'],'target_gate':target_gate,'skill_root':'CENTRAL_DOMAIN_ADAPTER',
      'authority_index':ref(root/'authority-index.json'),'authorities':[authority,policy_authority],'registry':ref(root/'registry.json'),
      'sources':source_refs,'workflow':ref(root/'workflow.json'),'input':ref(root/'contract.json'),'storage_root':str(root/'saved'),
      'decisions':{'HUMAN_ADOPTION':contract['decision_path']},
      'runtime_refs':[ref(ROOT/p) for p in ('harness/workflow.py','harness/resolvers.py','harness/artifacts.py','harness/core.py',
        'product_change/domain.py','product_change/worker.py','product_change/schemas/change-work.schema.json','product_change/schemas/impact-scope.schema.json','product_change/schemas/source-delta.schema.json',
        'product_master/domain.py','product_master/identity.py','product_master/validators/validate.py','product_master/schemas/work-package.schema.json')]+[contract['current_master']]}
    write_json(root/'spec.json',spec)
    return root,spec
