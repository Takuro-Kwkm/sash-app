#!/usr/bin/env python3
"""Native change adapter dispatched as hash-bound subprocesses by Shared Harness."""
import argparse
import copy
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from harness.core import Blocked, fingerprint, read_json, require, write_json
from harness.resolvers import capture
from harness.artifacts import readback, seal
from product_master.validators.validate import validate
from product_change.domain import verify_input, delta, impact, apply, scope_check

def execute(stage, contract, registry, root, work):
    c = read_json(contract)
    master = json.loads(capture(root, c['current_master']))
    docs = [json.loads(capture(root, r)) for r in c['sources']]
    rows = read_json(registry)['products']
    selected = [r for r in rows if r['product_id'] == c['product_id']]
    require(len(selected) == 1, 'REGISTRY_TARGET', 'Product selector missing', stage)
    current, new = verify_input(c, master, selected[0], docs)
    new_doc = docs[c['sources'].index(new)]
    old_doc = docs[c['sources'].index(current)]
    def get(name): return read_json(work / (name + '.json'))
    if stage in ('INITIALIZATION','AUTHORITY_RESOLUTION','REGISTRY_RESOLUTION','CURRENT_MASTER_ACQUISITION','SOURCE_ACQUISITION'):
        return {'status':'PASS','stage':stage,'product_id':c['product_id'],'current_revision':c['starting_revision'],
                'source_roles':[r['role'] for r in c['sources']], 'current_formal_retained':True}
    if stage == 'SOURCE_DELTA_AUDIT': return delta(master, old_doc, new_doc)
    report = get('SOURCE_DELTA_AUDIT')
    require(report == delta(master, old_doc, new_doc), 'MALFORMED_DELTA', 'Audit is not the captured full-scope comparison', stage)
    if stage == 'IMPACT_SCOPE': return impact(master, report, new_doc)
    scope = get('IMPACT_SCOPE')
    require(scope == impact(master, report, new_doc), 'IMPACT_SCOPE_VIOLATION', 'Approved impact differs from audited closure', stage)
    if stage == 'CARRY_FORWARD':
        return {'status':'PASS', 'baseline_sha256':fingerprint(master), 'unaffected_fields':scope['unaffected_fields'],
                'accepted_decisions_retained':True, 'unrelated_evidence_review':'NOT_REPEATED'}
    if stage == 'CHANGE_APPLICATION': return apply(master, report, scope, c['candidate_revision'])
    candidate = get('CHANGE_APPLICATION')
    if stage == 'QA':
        guard = scope_check(master, candidate, report, scope, c['candidate_revision'])
        # An unchanged Formal projection is evaluated as inherited, with a sidecar-only lineage ref.
        tested = copy.deepcopy(candidate)
        if report['product_impact'] == 'NONE': tested['provenance']['baseline_hash'] = fingerprint(master)
        native = validate(tested, master)
        return {'status':native['status'], 'scope':guard,'native':native,'candidate_sha256':fingerprint(candidate),
                'limitations':['Structured reviewed projection; not PDF extraction or manufacturer authenticity certification.']}
    if stage == 'QA_READY':
        qa = get('QA')
        require(qa['status'] == 'PASS' and qa['candidate_sha256'] == fingerprint(candidate), 'QA_BINDING', 'Missing exact candidate QA', stage)
        return {'status':'PASS', 'candidate_sha256':fingerprint(candidate),'formal_adoption':'NOT_PROMOTED','requested_gate':c['target_gate']}
    if stage == 'FORMAL_CHANGE_REVIEW':
        formal = copy.deepcopy(candidate)
        if report['product_impact'] == 'CHANGED':
            formal['lifecycle_status'] = 'FORMAL'
            for f in formal['fields']: f['lifecycle_status'] = 'FORMAL'
            for source in formal['sources']:
                if source['source_id'] in scope['approved_entities']['sources']:
                    source['status'] = 'CURRENT'
        policy = json.loads(capture(root, c['policy']))
        packet = {'product_id':c['product_id'],'starting_revision':c['starting_revision'],
          'candidate_revision':formal['product']['revision'],'source_identities':c['sources'],
          'delta_summary':report,'impacted_fields':scope['impacted_fields'],'before_after':report['rows'],
          'evidence_identity':{'before':fingerprint(master['evidence']),'after':fingerprint(candidate['evidence'])},
          'unresolved_items':report['unresolved'],'qa_result':get('QA'),'qa_ready_result':get('QA_READY'),
          'policy':policy, 'proposed_adoption':{'master':formal,'sha256':fingerprint(formal)},
          'candidate_sha256':fingerprint(candidate),'work_id':c['work_id'],'status':'PREPARED_NOT_APPROVED'}
        packet['payload_sha256'] = fingerprint(packet)
        return packet
    if stage == 'FORMAL_CHANGE_ADOPTION':
        packet = get('FORMAL_CHANGE_REVIEW')
        if report['product_impact'] == 'NONE':
            formal = master
            state = 'RETAINED_FORMAL_NO_CHANGE'
        elif c['target_gate'] != 'FORMAL_CHANGE_ADOPTION':
            formal = candidate
            state = 'CANDIDATE_NOT_ADOPTED'
        else:
            wrapper = read_json(work / 'review-packets/HUMAN_ADOPTION.json')
            decision = read_json(c['decision_path'])
            require(decision['payload_sha256'] == wrapper['payload_sha256'] and decision.get('actor_kind') == 'HUMAN' and
                    decision.get('decision') == 'APPROVED' and decision.get('decision_ref'), 'HUMAN_DECISION_REQUIRED', 'No imported same-payload Human Decision', stage)
            formal = packet['proposed_adoption']['master']
            require(fingerprint(formal) == packet['proposed_adoption']['sha256'], 'ADOPTION_PAYLOAD', 'Formal bytes differ', stage)
            admitted = {**decision,'decision':'ADOPT','payload_sha256':fingerprint(formal),
                        'policy_id':packet['policy']['policy_id'],'field_ids':scope['impacted_fields']}
            qa = validate(formal, master, packet['policy'], admitted)
            require(qa['status'] == 'PASS', 'FORMAL_NATIVE_QA', 'Formal validation failed', stage)
            state = 'FORMAL_ADOPTED'
        write_json(work / 'selected-master.json', formal)
        write_json(work / 'human-decision.json', decision if state == 'FORMAL_ADOPTED' else {'status': 'NOT_APPLICABLE', 'adoption_state': state})
        registry = {'product_id':c['product_id'],'current_formal_revision': formal['product']['revision'] if state != 'CANDIDATE_NOT_ADOPTED' else c['starting_revision'],
                    'candidate_revision':candidate['product']['revision'],'adoption_state':state,
                    'master_sha256':fingerprint(formal),'new_source_role':'CURRENT_ADOPTED' if state == 'FORMAL_ADOPTED' else 'NEW_CANDIDATE'}
        write_json(work / 'registry-projection.json', registry)
        return {'status':'PASS','adoption_state':state,'selected_master_sha256':fingerprint(formal),
                'current_formal_retained':state != 'FORMAL_ADOPTED','decision_ref':decision['decision_ref'] if state == 'FORMAL_ADOPTED' else None}
    if stage in ('READBACK', 'COMPLETION'):
        saved = Path(c['storage_root']) / c['work_id']
        names = c['stored_artifacts']
        expected = {n:{'bytes':len((work/n).read_bytes()),'sha256':__import__('hashlib').sha256((work/n).read_bytes()).hexdigest()} for n in names}
        # Shared storage creates lockfiles outside the content manifest.
        actual = seal(saved)['files']; actual = {n:v for n,v in actual.items() if not n.endswith('.lock')}
        require(expected == actual, 'BYTE_READBACK', 'Saved package differs', stage)
        result = get('FORMAL_CHANGE_ADOPTION')
        return {'status':'PASS','verification':'BYTE_LEVEL','files':len(expected),'cloud_sync':'NOT_VERIFIED',
                'adoption_state':result['adoption_state'],'product_impact':report['product_impact'],
                'source_audit_executed':True,'unnecessary_revision':False if report['product_impact']=='NONE' else None}
    raise ValueError('Unknown native stage: ' + stage)

def main():
    p=argparse.ArgumentParser();p.add_argument('--stage',required=True);p.add_argument('--contract',required=True)
    p.add_argument('--registry',required=True);p.add_argument('--root',required=True);p.add_argument('--work',required=True);p.add_argument('--out',required=True)
    a=p.parse_args()
    try: result=execute(a.stage,a.contract,a.registry,a.root,Path(a.work))
    except (Blocked,OSError,ValueError,KeyError,TypeError) as e:
        result={'status':'FAIL','blocking_reason':e.data if isinstance(e,Blocked) else {'code':'INPUT_OR_EXECUTION','reason':str(e)}}
    write_json(a.out,result)
    return 2 if result.get('status') in ('FAIL','REVIEW_REQUIRED') else 0
if __name__=='__main__':raise SystemExit(main())
