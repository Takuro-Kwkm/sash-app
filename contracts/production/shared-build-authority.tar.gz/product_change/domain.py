"""Change meaning/impact projection; repository-owned, not generic orchestration."""
import copy
from harness.core import Blocked, fingerprint, require
from product_master.domain import diff

VERSION = '2.0.0-reference'
CLASSIFICATIONS = ('NO_CHANGE', 'TEXT_ONLY', 'PRESENTATION_ONLY', 'PRODUCT_FACT_CHANGE',
 'FIELD_ADDED', 'FIELD_REMOVED', 'OPTION_ADDED', 'OPTION_REMOVED', 'RANGE_CHANGED',
 'DEFAULT_CHANGED', 'DEPENDENCY_CHANGED', 'APPLICABILITY_CHANGED',
 'FORBIDDEN_COMBINATION_CHANGED', 'SEMANTIC_CHANGE', 'SOURCE_AUTHORITY_CHANGE', 'UNKNOWN_REVIEW_REQUIRED')
SECTIONS = {'fields': 'field_id', 'constraints': 'rule_id', 'evidence': 'evidence_id', 'sources': 'source_id',
            'handoff_tests': 'case_id', 'gaps': 'gap_id'}

def validate_document(document, schema_name):
    from jsonschema import Draft202012Validator
    from pathlib import Path
    import json
    schema = json.loads((Path(__file__).parent / 'schemas' / schema_name).read_text())
    errors = list(Draft202012Validator(schema).iter_errors(document))
    require(not errors, 'CHANGE_SCHEMA', str(errors[0].message) if errors else '', 'QA')
    return document

def indexed(rows, key):
    result = {r[key]: r for r in rows}
    require(len(result) == len(rows), 'DUPLICATE_ID', key, 'QA')
    return result

def verify_input(c, master, registry, source_docs):
    from jsonschema import Draft202012Validator
    from pathlib import Path
    import json
    schema = json.loads((Path(__file__).parent / 'schemas/change-work.schema.json').read_text())
    errors = list(Draft202012Validator(schema).iter_errors(c))
    require(not errors, 'CHANGE_CONTRACT', str(errors[0].message) if errors else '', 'INITIALIZATION')
    require(c['product_id'] == master['product']['product_id'] == registry['product_id'], 'MASTER_PRODUCT', 'Product mismatch', 'CURRENT_MASTER_ACQUISITION')
    require(master['lifecycle_status'] == registry['lifecycle_state'] == 'FORMAL', 'CURRENT_NOT_FORMAL', 'Change requires existing FORMAL', 'CURRENT_MASTER_ACQUISITION')
    require(c['starting_revision'] == master['product']['revision'] == registry['formal_revision'] and
            c['current_master']['sha256'] == registry['formal_sha256'], 'STALE_CURRENT_MASTER', 'Current Formal selector differs', 'CURRENT_MASTER_ACQUISITION')
    require(c['candidate_revision'] != c['starting_revision'], 'REVISION_IDENTITY', 'Candidate revision must be distinct', 'INITIALIZATION')
    refs = c['sources']
    for role in ('CURRENT_ADOPTED', 'NEW_CANDIDATE'):
        require(sum(s['role'] == role for s in refs) == 1, 'SOURCE_ROLE', 'Exactly one current and candidate required', 'SOURCE_ACQUISITION')
    current = next(s for s in refs if s['role'] == 'CURRENT_ADOPTED')
    new = next(s for s in refs if s['role'] == 'NEW_CANDIDATE')
    require(current['source_id'] == registry['current_source_id'] and current['sha256'] == registry['current_source_sha256'],
            'SOURCE_CURRENT_SELECTOR', 'Current adopted source differs from Registry', 'SOURCE_ACQUISITION')
    require(current['source_id'] != new['source_id'] and new['status'] == 'CANDIDATE', 'CANDIDATE_SOURCE_CURRENT', 'Unadopted source cannot be Current', 'SOURCE_ACQUISITION')
    for ref, doc in zip(refs, source_docs):
        require(ref['product_id'] == c['product_id'] == doc['product_id'] and doc['source_id'] == ref['source_id'], 'SOURCE_PRODUCT', 'Source product/identity mismatch', 'SOURCE_ACQUISITION')
        require(doc.get('comparison_status') == 'COMPLETE_REVIEWED' and doc.get('review_ref') and
                doc.get('scope_id') == master['scope']['scope_id'], 'NOT_DETERMINED', 'Full scope semantic extraction/review missing', 'SOURCE_DELTA_AUDIT')
        require(set(doc['projection']) == set(SECTIONS), 'NOT_DETERMINED', 'Missing domain sections', 'SOURCE_DELTA_AUDIT')
        for section, key in SECTIONS.items(): indexed(doc['projection'][section], key)
    for section in SECTIONS:
        require(source_docs[refs.index(current)]['projection'][section] == master[section], 'SOURCE_BASELINE_MISMATCH', section, 'SOURCE_DELTA_AUDIT')
    return current, new

def classify_field(a, b):
    if a is None: return ['FIELD_ADDED']
    if b is None: return ['FIELD_REMOVED']
    if a == b: return []
    labels = []
    known = set()
    def group(keys, label):
        nonlocal known
        known.update(keys)
        if any(a.get(k) != b.get(k) for k in keys): labels.append(label)
    group(('minimum', 'maximum', 'unit'), 'RANGE_CHANGED')
    group(('default',), 'DEFAULT_CHANGED')
    group(('dependency', 'reset_condition'), 'DEPENDENCY_CHANGED')
    group(('visibility_condition', 'required_when', 'required'), 'APPLICABILITY_CHANGED')
    group(('semantic_role', 'data_type'), 'SEMANTIC_CHANGE')
    group(('label',), 'PRESENTATION_ONLY')
    group(('notes',), 'TEXT_ONLY')
    group(('source', 'evidence_id'), 'SOURCE_AUTHORITY_CHANGE')
    known.add('selectable_values')
    old = {fingerprint(o['value']): o for o in a.get('selectable_values', [])}
    new = {fingerprint(o['value']): o for o in b.get('selectable_values', [])}
    if new.keys() - old.keys(): labels.append('OPTION_ADDED')
    if old.keys() - new.keys(): labels.append('OPTION_REMOVED')
    if any(old[k] != new[k] for k in old.keys() & new.keys()): labels.append('PRODUCT_FACT_CHANGE')
    changed = {k for k in a.keys() | b.keys() if a.get(k) != b.get(k)}
    if changed - known: labels.append('UNKNOWN_REVIEW_REQUIRED')
    return sorted(set(labels))

def delta(master, current, new):
    rows = []
    for section, key in SECTIONS.items():
        a, b = indexed(current['projection'][section], key), indexed(new['projection'][section], key)
        for ident in sorted(a.keys() | b.keys()):
            if a.get(ident) == b.get(ident): continue
            if section == 'fields': kinds = classify_field(a.get(ident), b.get(ident))
            elif section == 'constraints': kinds = ['FORBIDDEN_COMBINATION_CHANGED']
            elif section in ('sources', 'evidence'): kinds = ['SOURCE_AUTHORITY_CHANGE']
            elif section == 'handoff_tests': kinds = ['PRODUCT_FACT_CHANGE']
            else: kinds = ['UNKNOWN_REVIEW_REQUIRED']
            rows.append({'section': section, 'entity_id': ident, 'classifications': kinds, 'before': a.get(ident), 'after': b.get(ident)})
    unknown = new.get('unresolved', []) + current.get('unresolved', [])
    unsupported = set(new) - {'source_id','product_id','comparison_status','review_ref','scope_id','projection','text','presentation','unresolved'}
    if unsupported: unknown.append({'unsupported_source_keys': sorted(unsupported)})
    if any('UNKNOWN_REVIEW_REQUIRED' in r['classifications'] for r in rows): unknown.append('Unclassified structural change')
    classifications = sorted({k for r in rows for k in r['classifications']})
    if current.get('text') != new.get('text'): classifications.append('TEXT_ONLY')
    if current.get('presentation') != new.get('presentation'): classifications.append('PRESENTATION_ONLY')
    if not classifications: classifications = ['NO_CHANGE']
    return validate_document({'status': 'REVIEW_REQUIRED' if unknown else 'PASS', 'comparison_executed': True,
            'source_ids': [current['source_id'], new['source_id']], 'source_projection_sha256': [fingerprint(current), fingerprint(new)],
            'classifications': sorted(set(classifications)), 'rows': rows, 'unresolved': unknown,
            'product_impact': 'UNKNOWN' if unknown else 'CHANGED' if rows else 'NONE',
            'required_scope': master['scope']['scope_id'], 'complete_scope_compared': True}, 'source-delta.schema.json')

def impact(master, report, new):
    require(report['status'] == 'PASS' and report['comparison_executed'], 'REVIEW_REQUIRED', 'Delta audit requires review', 'IMPACT_SCOPE')
    modified = copy.deepcopy(master)
    modified.update(new['projection'])
    derived = diff(master, modified)
    scope = {'status': 'PASS', 'impacted_fields': derived['qa_impact'],
             'unaffected_fields': sorted({f['field_id'] for f in master['fields']} - set(derived['qa_impact'])),
             'impacted_dependencies': sorted({r['entity_id'] for r in report['rows'] if r['section'] == 'fields' and 'DEPENDENCY_CHANGED' in r['classifications']}),
             'impacted_constraints': sorted(r['entity_id'] for r in report['rows'] if r['section'] == 'constraints'),
             'impacted_evidence': sorted(r['entity_id'] for r in report['rows'] if r['section'] == 'evidence'),
             'impacted_mappings': derived['qa_impact'], 'impacted_runtime_consumers': derived['qa_impact'],
             'impacted_ui_contract_consumers': derived['qa_impact'], 'unknown_impact': [],
             'approved_entities': {s: sorted(r['entity_id'] for r in report['rows'] if r['section'] == s) for s in SECTIONS},
             'consumer_execution': 'IMPACT_ONLY_NOT_INTEGRATED', 'source_delta_sha256': fingerprint(report)}
    return validate_document(scope, 'impact-scope.schema.json')

def apply(master, report, scope, revision):
    if report['product_impact'] == 'NONE': return copy.deepcopy(master)
    out = copy.deepcopy(master)
    for section, key in SECTIONS.items():
        values = indexed(out[section], key)
        for r in report['rows']:
            if r['section'] != section: continue
            require(r['entity_id'] in scope['approved_entities'][section], 'IMPACT_SCOPE', 'Unapproved entity', 'CHANGE_APPLICATION')
            if r['after'] is None: values.pop(r['entity_id'], None)
            else: values[r['entity_id']] = copy.deepcopy(r['after'])
        original_order = [r[key] for r in out[section] if r[key] in values]
        out[section] = [values[k] for k in original_order + sorted(values.keys() - set(original_order))]
    out['work_type'] = 'CHANGE WORK'
    out['lifecycle_status'] = 'QA_READY'
    out['product']['revision'] = revision
    out['provenance']['baseline_hash'] = fingerprint(master)
    for f in out['fields']:
        if f['field_id'] in scope['approved_entities']['fields']: f['lifecycle_status'] = 'PROVISIONAL'
    return out

def scope_check(before, after, report, scope, revision):
    expected = apply(before, report, scope, revision)
    require(after == expected, 'IMPACT_SCOPE_VIOLATION', 'Actual changes differ from approved delta; unrelated or lifecycle edit', 'QA')
    for section, key in SECTIONS.items():
        a, b = indexed(before[section], key), indexed(after[section], key)
        actual = {k for k in a.keys() | b.keys() if a.get(k) != b.get(k)}
        require(actual <= set(scope['approved_entities'][section]), 'IMPACT_SCOPE_VIOLATION', section, 'QA')
    require(not scope['unknown_impact'], 'UNKNOWN_IMPACT', 'Unknown consumer impact', 'QA')
    return {'status': 'PASS', 'actual_changed_artifacts_subset_approved': True}
