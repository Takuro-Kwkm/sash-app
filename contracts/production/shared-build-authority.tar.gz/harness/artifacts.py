"""Complete byte identity and atomic local saves; cloud sync is a separate proof."""
import hashlib
from pathlib import Path
from .core import atomic, lock

def seal(root, allow_empty=False):
    root = Path(root)
    if not root.is_dir():
        raise ValueError('artifact directory missing')
    files = {}
    for p in sorted(root.rglob('*')):
        if p.is_symlink():
            raise ValueError('symlinks are not artifact bytes')
        if p.is_file():
            data = p.read_bytes()
            files[p.relative_to(root).as_posix()] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    if not files and not allow_empty:
        raise ValueError('empty artifact directory')
    return {'format': 'product-master-readback-v1', 'files': files}

def readback(root, manifest):
    if manifest.get('format') != 'product-master-readback-v1' or not manifest.get('files'):
        raise ValueError('invalid or empty readback manifest')
    actual = seal(root, allow_empty=True)['files']
    wanted = manifest['files']
    return {'status': 'PASS' if actual == wanted else 'FAIL',
            'missing': sorted(wanted.keys() - actual.keys()), 'extra': sorted(actual.keys() - wanted.keys()),
            'mismatches': sorted(k for k in wanted.keys() & actual.keys() if wanted[k] != actual[k]),
            'files': len(wanted), 'verification': 'BYTE_COMPLETE; origin of downloaded directory must be recorded by caller'}

def save_verified(source, destination):
    data = Path(source).read_bytes()
    destination = Path(destination)
    with lock(destination.with_suffix(destination.suffix + '.lock')):
        if destination.exists() and destination.read_bytes() != data:
            raise ValueError('immutable saved artifact already exists with different bytes')
        atomic(destination, data)
        if destination.read_bytes() != data:
            raise ValueError('storage readback mismatch')
    return {'status': 'PASS', 'path': str(destination.resolve()), 'sha256': hashlib.sha256(data).hexdigest(),
            'bytes': len(data), 'hash_kind': 'LOCAL_BYTES_SHA256', 'cloud_sync': 'NOT_VERIFIED'}
