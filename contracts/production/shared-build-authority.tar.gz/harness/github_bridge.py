"""Exact identity checks and bounded connector requests; no implicit merge authority."""
from .core import require

def branch_request(repository, branch, base_sha):
    require(repository and branch and base_sha, 'BRANCH_IDENTITY', 'Explicit repository/branch/base required', 'GITHUB')
    return {'tool': 'github.create_branch', 'arguments': {'repository_full_name': repository, 'branch_name': branch, 'sha': base_sha}}

def pr_request(repository, branch, base, title, body):
    require(all((repository, branch, base, title, body)), 'PR_INPUT', 'Concrete isolated change required', 'GITHUB')
    return {'tool': 'github.create_pull_request', 'arguments': {'repository_full_name': repository, 'head': branch,
            'base': base, 'title': title, 'body': body}, 'status': 'REQUESTED_NOT_CREATED'}

def ci_readback(runs, repository, head, required, attempt=None):
    require(bool(required), 'CI_REQUIRED_EMPTY', 'Required checks must come from repository policy', 'CI')
    selected = []
    for context in required:
        candidates = [r for r in runs if r.get('repository') == repository and r.get('head_sha') == head and r.get('context') == context]
        require(bool(candidates), 'CI_MISSING', context, 'CI')
        latest = max(candidates, key=lambda r: (r['run_id'], r['run_attempt']))
        require(attempt is None or latest['run_attempt'] == attempt, 'CI_ATTEMPT', context, 'CI')
        selected.append(latest)
    pending = [r for r in selected if r['status'] != 'completed']
    failed = [r for r in selected if r['status'] == 'completed' and r.get('conclusion') != 'success']
    return {'status': 'FAIL' if failed else 'WAITING_FOR_CONNECTOR' if pending else 'PASS',
            'repository': repository, 'head_sha': head, 'checks': selected,
            'failed_artifact_requests': [{'tool': 'github.fetch_workflow_run_artifacts', 'run_id': r['run_id'], 'repository': repository} for r in failed]}

def bounded_ci_request(repository, head, poll_number, max_polls=10):
    require(0 <= poll_number < max_polls <= 60, 'CI_POLL_LIMIT', 'Bounded polling exhausted', 'CI')
    return {'tool': 'github.fetch', 'arguments': {'url': f'https://api.github.com/repos/{repository}/actions/runs?head_sha={head}'},
            'poll_number': poll_number, 'max_polls': max_polls, 'delay_seconds': min(30, 2 + poll_number * 2)}

def merge_request(pr, repository, expected_head, ci, review_admitted):
    require(pr.get('repository') == repository and pr.get('head_sha') == expected_head and pr.get('state') == 'open',
            'PR_IDENTITY', 'PR repository/head/state mismatch', 'MERGE')
    require(ci.get('status') == 'PASS' and ci.get('repository') == repository and ci.get('head_sha') == expected_head,
            'MERGE_CI', 'Exact-head CI missing', 'MERGE')
    require(review_admitted is True and pr.get('merge_authorized') is True, 'MERGE_REVIEW', 'Imported scope/review authorization required', 'MERGE')
    return {'tool': 'github.merge_pull_request', 'arguments': {'repository_full_name': repository,
            'pr_number': pr['number'], 'expected_head_sha': expected_head}, 'status': 'REQUESTED_NOT_MERGED'}

def main_readback(repository, merge_sha, main_sha, expected_files, actual_files, ci):
    require(main_sha == merge_sha and ci.get('repository') == repository and ci.get('head_sha') == merge_sha and ci.get('status') == 'PASS',
            'POST_MERGE_IDENTITY', 'Merge SHA/main/exact CI mismatch', 'MERGE')
    require(expected_files == actual_files and bool(expected_files), 'MAIN_READBACK', 'Main file identity mismatch', 'MERGE')
    return {'status': 'MERGE_CLOSED', 'repository': repository, 'merge_sha': merge_sha, 'release_state': 'NOT_RELEASED'}
