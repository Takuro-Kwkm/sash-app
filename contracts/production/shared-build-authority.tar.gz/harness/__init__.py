"""Product-work orchestration. Does not create manufacturer facts or approvals."""
