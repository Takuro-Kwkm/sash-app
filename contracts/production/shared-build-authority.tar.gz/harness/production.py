"""Production host boundary. Native contracts own facts; Workflow owns the DAG.

Connector observations are admitted by the authenticated host, never fetched by
an LLM-generated shell or substituted with reference fixtures. This module checks
their repository/product/content bindings, not the host's authentication itself.
"""
import csv
import io
import json
import re
import subprocess
import sys
from pathlib import Path
from .core import Blocked, fingerprint, read_json, require, sha, write_json
from .workflow import run, inspect
from .artifacts import save_verified

VERSION = '2.1.0-production'
CLASSIFICATIONS = ('UNCHANGED', 'ADDED', 'REMOVED', 'MODIFIED', 'RENAMED',
                   'SEMANTIC_CHANGE', 'DEPENDENCY_CHANGE', 'CONSTRAINT_CHANGE',
                   'PRESENTATION_ONLY', 'UNKNOWN')
COMPONENTS = ('Product Master', 'Evidence', 'Dependency', 'Constraints',
              'Selection Contract', 'Canonical Mapping', 'Runtime', 'Global Flow',
              'UI', 'Storage', 'Readback', 'Estimate Output', 'Print', 'Resume',
              'Regression Tests')


def connector_document(raw):
    """Accept complete structured connector response, reject errors/empty content."""
    require(not raw.get('isError'), 'CONNECTOR_FAILURE', 'Connector rejected acquisition', 'ACQUISITION')
    d = raw.get('structuredContent', raw)
    if isinstance(d, dict) and 'content' in d:
        value = d['content']
        if isinstance(value, str):
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                return value
    return d


def observation_fingerprint(raw):
    value = connector_document(raw)
    if isinstance(value, dict) and value.get('id') and value.get('mime_type'):
        # Permissions and display URLs can vary with fields selectors. Only the
        # native file identity/content revision and placement admit continuation.
        value = {k:value.get(k) for k in ('id','mime_type','size','modified_time','parent_ids')}
    return fingerprint(value)


def native_registry(raw, manufacturer, series):
    content = connector_document(raw)
    require(isinstance(content, str), 'NATIVE_REGISTRY', 'Full native CSV export required', 'REGISTRY')
    header, rows = None, []
    for r in csv.reader(io.StringIO(content)):
        if 'manufacturer' in r and 'series' in r and 'package_version' in r:
            header = r
        elif header and len(r) == len(header):
            row = dict(zip(header, r))
            if row.get('manufacturer') == manufacturer and row.get('series') == series:
                rows.append(row)
    require(len(rows) == 1, 'NATIVE_REGISTRY_AMBIGUOUS', 'One exact product row required', 'REGISTRY')
    require(rows[0]['master_status'] == 'FORMAL_PASS', 'NATIVE_FORMAL', 'Current Formal required', 'REGISTRY')
    return rows[0]


def short_route(instruction, config, selected_product=None):
    require(config.get('status') == 'CURRENT', 'PRODUCTION_ROUTING', 'Current connection registry required', 'ROUTER')
    hits = []
    for product in config['products']:
        for alias in product['aliases']:
            pattern = r'(?<![A-Za-z0-9])' + re.escape(alias) + r'(?![A-Za-z0-9])' if alias.isascii() else re.escape(alias)
            if re.search(pattern, instruction, re.I):
                hits.append((len(alias), product))
    if hits:
        longest = max(n for n, _ in hits)
        matches = {p['product_id']: p for n, p in hits if n == longest}
    else:
        matches = {p['product_id']: p for p in config['products'] if p['product_id'] == selected_product}
    require(len(matches) == 1, 'PRODUCTION_TARGET_AMBIGUOUS', 'Resolve selected product from native Registry or saved Work', 'ROUTER')
    p = next(iter(matches.values()))
    require(p.get('connection_state') == 'CONNECTED', 'NATIVE_ADAPTER_UNAVAILABLE',
            p['product_id'] + ': registered but not connected', 'ROUTER')
    require(any(w.lower() in instruction.lower() for w in config['change_triggers']),
            'PRODUCTION_INTENT', 'No admitted change/continuation intent', 'ROUTER')
    return {'repository': p['repository'], 'product_id': p['product_id'],
            'work_skill': 'product-change-work', 'work_type': 'PRODUCT_MASTER_CHANGE',
            'target_gate': 'FORMAL_CHANGE_ADOPTION' if any(w in instruction for w in ('正式採用', '正式反映')) else p['default_gate'],
            'operation': 'RESUME' if '再開' in instruction else 'RUN',
            'baseline_selector': p['baseline_selector'], 'source_selector': p['source_selector'],
            'native_adapter': p['native_adapter'], 'validators': p['validators'],
            'resume_selector': p['resume_selector']}


def repository_binding(repository, branch_raw, tree_raw, captured_files):
    branch = connector_document(branch_raw)
    tree = connector_document(tree_raw)
    require(isinstance(branch, dict) and branch.get('commit', {}).get('sha'), 'REMOTE_HEAD', 'Acquired default branch required', 'RESOLUTION')
    head = branch['commit']['sha']
    require(tree.get('sha') == head and tree.get('truncated') is False,
            'REMOTE_TREE', 'Full tree must belong to acquired HEAD', 'RESOLUTION')
    blobs = {f['path']: f['sha'] for f in tree['tree'] if f['type'] == 'blob'}
    out = {}
    for path, local in captured_files.items():
        require(path in blobs, 'REMOTE_PATH', path, 'RESOLUTION')
        b = Path(local).read_bytes()
        import hashlib
        actual = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
        require(actual == blobs[path], 'REMOTE_BLOB', path + ': captured bytes differ', 'RESOLUTION')
        out[path] = {'git_blob_sha': actual, 'sha256': sha(b)}
    return {'repository': repository, 'default_branch': branch['name'], 'head_sha': head, 'files': out}


def live_guard(binding, live_raw, live_files=None):
    live = connector_document(live_raw.get('repository', live_raw))
    require(live.get('commit', {}).get('sha') == binding['head_sha'],
            'REPOSITORY_HEAD_CHANGED', 'Reacquire Current state and create a scoped successor; do not replay completed gates', 'RESUME')
    if live_files is not None:
        for path, expected in binding['files'].items():
            require(path in live_files and sha(Path(live_files[path]).read_bytes()) == expected['sha256'],
                    'PRODUCTION_PATH_CHANGED', path, 'RESUME')
    for name, expected in binding.get('observations', {}).items():
        require(name in live_raw.get('observations', {}), 'LIVE_OBSERVATION_MISSING',
                'Reacquire ' + name + ' through its native connector', 'RESUME')
        require(observation_fingerprint(live_raw['observations'][name]) == expected, 'LIVE_AUTHORITY_CHANGED',
                name + ': resolve successor scope before continuing', 'RESUME')
    return {'status': 'PASS', 'head_sha': binding['head_sha']}


def recovery(result):
    """Preserve named blocker and last DAG checkpoint; never claim a failed gate."""
    if result['state'] == 'BLOCKED' and result.get('resumable'):
        return {**result, 'state': 'RECOVERABLE_BLOCKED', 'original_state': 'BLOCKED'}
    return result


def run_production(root, work, spec, live_raw, stop_after=None):
    binding = read_json(Path(root) / spec['production_binding']['path'])
    try:
        require(sha((Path(root) / spec['production_binding']['path']).read_bytes()) == spec['production_binding']['sha256'],
                'PRODUCTION_BINDING_CHANGED', 'Captured production binding changed', 'RESUME')
        live_guard(binding, live_raw, {p: Path(binding['checkout']) / p for p in binding['files']})
        result = recovery(run(root, work, spec, stop_after=stop_after))
    except (Blocked, OSError, ValueError, KeyError) as e:
        blocker = e.data if isinstance(e, Blocked) else {'code': 'PRODUCTION_IO', 'reason': str(e), 'target_gate': 'RESUME'}
        from .workflow import events
        try:
            completed = [r['gate'] for r in events(work)]
        except (Blocked, ValueError, OSError):
            completed = []
        result = {'state': 'RECOVERABLE_BLOCKED', 'resumable': True, 'completed_gates': completed,
                  'blocking_reason': blocker, 'required_next_action': 'Correct named acquisition/identity; resume the same verified checkpoint or create scoped successor'}
    write_json(Path(work) / 'production-result.json', result)
    return result


def persist_checkpoint(root, work, spec, destination):
    """Persist the exact journal; restore its original bound paths before Resume."""
    work, destination = Path(work).resolve(), Path(destination).resolve()
    rows = __import__('harness.workflow', fromlist=['events']).events(work)
    files = [p for p in work.rglob('*') if p.is_file() and not p.name.startswith('.') and not p.name.endswith('.lock')]
    entries = {}
    for p in files:
        relative = p.relative_to(work).as_posix()
        receipt = save_verified(p, destination / 'checkpoint' / relative)
        entries[relative] = {'sha256': receipt['sha256'], 'bytes': receipt['bytes']}
    manifest = {'status': 'SAVED_AND_READ_BACK', 'checkpoint_files': entries,
                'work_binding_sha256': fingerprint(spec), 'completed_gates': [r['gate'] for r in rows],
                'original_root': str(Path(root).resolve()), 'original_work': str(work),
                'restore_policy': 'Restore verified input refs and code before invoking existing Workflow; never rewrite journal bindings'}
    write_json(destination / 'checkpoint-manifest.json', manifest)
    require(read_json(destination / 'checkpoint-manifest.json') == manifest, 'CHECKPOINT_READBACK', 'Manifest mismatch', 'STORAGE')
    return manifest


def main(argv=None):
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('command', choices=('route', 'run', 'resume', 'checkpoint'))
    p.add_argument('--config'); p.add_argument('--instruction'); p.add_argument('--selected-product')
    p.add_argument('--root'); p.add_argument('--work'); p.add_argument('--spec'); p.add_argument('--live-state')
    p.add_argument('--stop-after'); p.add_argument('--destination')
    a = p.parse_args(argv)
    try:
        if a.command == 'route':
            result = short_route(a.instruction, read_json(a.config), a.selected_product)
        elif a.command == 'checkpoint':
            result = persist_checkpoint(a.root, a.work, read_json(a.spec), a.destination)
        else:
            result = run_production(a.root, a.work, read_json(a.spec), read_json(a.live_state), a.stop_after)
    except (Blocked, OSError, ValueError, TypeError, KeyError) as e:
        result = {'state': 'RECOVERABLE_BLOCKED', 'blocking_reason': e.data if isinstance(e, Blocked) else {'reason': str(e)}, 'resumable': True}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get('state') not in ('RECOVERABLE_BLOCKED', 'HUMAN_DECISION_REQUIRED') else 2
