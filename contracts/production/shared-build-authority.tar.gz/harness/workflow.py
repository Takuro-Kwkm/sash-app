"""Upper Work DAG orchestrator v2; retain v0.1 as its formal-storage subflow."""
import json
import subprocess
import sys
from pathlib import Path
from .core import Blocked, fingerprint, lock, read_json, require, run as storage_subflow, sha, timestamp, write_json
from .resolvers import capture, resolve
from .artifacts import save_verified

VERSION = '2.0.0-reference'

def route(instruction, routing, target=None, work_id=None):
    matches = [r for r in routing['routes'] if any(x.lower() in instruction.lower() for x in r['triggers'])]
    matches = [r for r in matches if not any(x.lower() in instruction.lower() for x in r.get('exclude_triggers', []))]
    require(len(matches) == 1, 'ROUTING_AMBIGUOUS', 'One route must match the instruction', 'ROUTER')
    r = matches[0]
    require(target or work_id, 'TARGET_REQUIRED', 'Target/work binding missing', 'ROUTER')
    gates = [g for g, words in r['gate_triggers'].items() if any(w.lower() in instruction.lower() for w in words)]
    require(len(gates) <= 1, 'TARGET_GATE_AMBIGUOUS', 'Multiple requested gates', 'ROUTER')
    return {'work_skill': r['work_skill'], 'target_gate': gates[0] if gates else r['default_gate'], 'target': target, 'workflow_id': work_id}

def definition(root, spec):
    doc = json.loads(capture(root, spec['workflow']))
    require(doc.get('status') in ('CURRENT', 'ACTIVE', 'ADOPTED') and doc.get('work_skill') == spec['work_skill'],
            'WORKFLOW_CONTRACT', 'Current workflow/skill mismatch', 'INITIALIZATION')
    ids = [s['id'] for s in doc['steps']]
    require(len(set(ids)) == len(ids), 'WORKFLOW_CONTRACT', 'Duplicate steps', 'INITIALIZATION')
    prior = set()
    for step in doc['steps']:
        require(set(step.get('needs', [])).issubset(prior), 'WORKFLOW_DAG', 'Missing, cyclic or non-topological dependencies', 'INITIALIZATION')
        prior.add(step['id'])
    require(spec['target_gate'] in doc['targets'], 'TARGET_GATE', 'Requested gate has no contract definition', 'INITIALIZATION')
    selected = doc['targets'][spec['target_gate']]
    require(set(selected).issubset(prior), 'TARGET_GATE', 'Unknown required step', 'INITIALIZATION')
    required = set(selected)
    for step in reversed(doc['steps']):
        if step['id'] in required:
            required.update(step.get('needs', []))
    return doc, [s for s in doc['steps'] if s['id'] in required]

def events(work):
    p = Path(work) / 'workflow-events.json'
    rows = read_json(p) if p.exists() else []
    previous = '0' * 64
    for i, row in enumerate(rows):
        payload = {k: v for k, v in row.items() if k != 'event_sha256'}
        require(row['sequence'] == i and row['previous_sha256'] == previous and row['event_sha256'] == fingerprint(payload),
                'WORKFLOW_JOURNAL', 'Work journal hash chain changed', 'RESUME')
        previous = row['event_sha256']
    return rows

def append(work, spec, step, evidence):
    rows = events(work)
    payload = {'sequence': len(rows), 'workflow_id': spec['workflow_id'], 'work_skill': spec['work_skill'],
               'target': spec['target'], 'gate': step, 'result': 'PASS', 'blocker': None,
               'timestamp': timestamp(), 'binding_sha256': fingerprint(spec), 'evidence': evidence,
               'previous_sha256': rows[-1]['event_sha256'] if rows else '0' * 64}
    rows.append({**payload, 'event_sha256': fingerprint(payload)})
    write_json(Path(work) / 'workflow-events.json', rows)

def inspect(root, work, spec):
    for ref in spec.get('runtime_refs', []):
        capture(root, ref)
    capture(root, spec['input'])
    resolved = resolve(root, spec)
    doc, steps = definition(root, spec)
    for step in steps:
        if 'script' in step:
            capture(root, step['script'])
        if step['kind'] == 'product-storage':
            capture(root, step['spec'])
            capture(root, step['package'])
        if step['kind'] in ('formal-save', 'downstream-change'):
            capture(root, step['plan'])
    rows = events(work)
    binding = fingerprint(spec)
    saved = Path(work) / 'workflow-binding.json'
    if saved.exists():
        require(read_json(saved)['sha256'] == binding, 'WORK_CHANGED', 'Pinned work input changed; create a scoped Change Work', 'RESUME')
    require(all(r['binding_sha256'] == binding for r in rows), 'WORK_CHANGED', 'Journal binding differs', 'RESUME')
    completed = [r['gate'] for r in rows]
    require(completed == [s['id'] for s in steps[:len(completed)]], 'WORKFLOW_ORDER', 'Cannot skip or repeat steps', 'RESUME')
    for row in rows:
        for artifact in row['evidence'].get('artifacts', []):
            p = Path(artifact['path'])
            require(p.is_file() and sha(p.read_bytes()) == artifact['sha256'], 'OUTPUT_CHANGED', str(p), 'RESUME')
        registry_proof = row['evidence'].get('registry_binding')
        if registry_proof:
            current = read_json(registry_proof['path'])
            require(fingerprint(current.get('products', {}).get(registry_proof['target'])) == registry_proof['entry_sha256'],
                    'REGISTRY_ENTRY_CHANGED', 'Saved target registry entry changed', 'RESUME')
    return {'workflow_id': spec['workflow_id'], 'target': spec['target'], 'work_skill': spec['work_skill'],
            'state': 'COMPLETED' if len(rows) == len(steps) else 'INITIALIZED' if not rows else 'IN_PROGRESS',
            'completed_gates': completed, 'pending_gates': [s['id'] for s in steps[len(rows):]],
            'current_authority_snapshot': resolved, 'blocking_reason': None}, doc, steps

def execute_step(root, work, spec, step):
    substitutions = {'root': str(Path(root).resolve()), 'work': str(Path(work).resolve()),
                     'skill_root': spec['skill_root'], 'input': str(Path(root) / spec['input']['path']),
                     'registry': str(Path(root) / spec['registry']['path'])}
    kind = step['kind']
    condition = step.get('when')
    if condition:
        condition_path = Path(condition['source'].format_map(substitutions))
        value = read_json(condition_path)
        observed = value
        for key in condition['result_path']:
            observed = observed[key]
        require(observed in condition['allowed_values'], 'BRANCH_NOT_DETERMINED', 'Conditional result is not admitted', step['id'])
        if observed != condition['equals']:
            return {'conditional_result': 'NOT_APPLICABLE', 'observed': observed,
                    'artifacts': [{'path': str(condition_path.resolve()), 'sha256': sha(condition_path.read_bytes())}]}
    if kind in ('build', 'validator'):
        script_ref = step['script']
        capture(root, script_ref)
        argv = [sys.executable, '-B', str(Path(root) / script_ref['path'])] + [a.format_map(substitutions) for a in step['args']]
        output = Path(step['output'].format_map(substitutions))
        produced = [output] + [Path(p.format_map(substitutions)) for p in step.get('side_outputs', [])]
        for path in produced:
            require(path.resolve().is_relative_to(Path(work).resolve()) and not path.is_symlink(), 'OUTPUT_PATH', 'Worker output must be owned by this checkpoint', step['id'])
            if path.exists():
                path.unlink()
        proc = subprocess.run(argv, cwd=root, capture_output=True, text=True, timeout=step.get('timeout_seconds', 60))
        require(proc.returncode == 0, 'STEP_EXECUTION', step['id'] + ': worker failed; inspect its bounded result', step['id'])
        require(all(path.is_file() and not path.is_symlink() for path in produced), 'OUTPUT_MISSING', step['id'], step['id'])
        value = read_json(output)
        if kind == 'validator':
            observed = value
            for key in step['result_path']:
                observed = observed[key]
            require(observed == step['expected_result'], 'GATE_FAILED', step['id'] + ': native validator rejected', step['id'])
        return {'validator_result': value if kind == 'validator' else None,
                'artifacts': [{'path': str(path.resolve()), 'sha256': sha(path.read_bytes())} for path in produced],
                'implementation': script_ref['path'], 'execution': 'SUBPROCESS'}
    if kind == 'storage':
        source = Path(step['source'].format_map(substitutions))
        dest = Path(spec['storage_root']) / step['destination'].format_map({**substitutions, 'workflow_id': spec['workflow_id']})
        require(dest.resolve().is_relative_to(Path(spec['storage_root']).resolve()), 'STORAGE_PATH', 'Destination escapes root', step['id'])
        result = save_verified(source, dest)
        return {**result, 'artifacts': [{'path': result['path'], 'sha256': result['sha256']}]}
    if kind == 'registry-output':
        path = Path(spec['storage_root']) / step['destination']
        require(path.resolve().is_relative_to(Path(spec['storage_root']).resolve()), 'STORAGE_PATH', 'Registry destination escapes root', step['id'])
        source = read_json(Path(step['source'].format_map(substitutions)))
        entry = {key: source[key] for key in step['entry_keys']}
        with lock(path.with_suffix('.lock')):
            document = read_json(path) if path.exists() else {'products': {}}
            require(isinstance(document.get('products'), dict), 'REGISTRY_FORMAT', 'Output registry has invalid rows', step['id'])
            previous = document['products'].get(spec['target'])
            require(previous is None or previous == entry, 'REGISTRY_CONFLICT', 'Existing target entry differs', step['id'])
            document['products'][spec['target']] = entry
            write_json(path, document)
            require(read_json(path) == document, 'REGISTRY_READBACK', 'Output registry differs after save', step['id'])
        return {'artifacts': [], 'registry_snapshot_sha256': sha(path.read_bytes()), 'registry_entry': entry,
                'registry_binding': {'path': str(path.resolve()), 'target': spec['target'], 'entry_sha256': fingerprint(entry)}}
    if kind == 'human':
        packet = {'workflow_id': spec['workflow_id'], 'gate': step['id'], 'payload_sha256': fingerprint(spec), 'status': 'PREPARED_NOT_APPROVED'}
        packet_path = None
        if step.get('packet'):
            packet_path = Path(step['packet'].format_map(substitutions))
            native_packet = read_json(packet_path)
            require(native_packet.get('payload_sha256') == fingerprint({k: v for k, v in native_packet.items() if k != 'payload_sha256'}),
                    'REVIEW_PACKET_CHANGED', 'Native review packet hash mismatch', step['id'])
            packet['native_packet'] = native_packet
            packet['work_binding_sha256'] = fingerprint(spec)
            packet['payload_sha256'] = fingerprint({'work_binding_sha256': fingerprint(spec), 'native_packet': native_packet})
        from .core import safe_path
        write_json(safe_path(Path(work) / 'review-packets', step['id'] + '.json'), packet)
        saved_packet = None
        if step.get('packet_destination'):
            destination = Path(spec['storage_root']) / step['packet_destination'].format_map({**substitutions, 'workflow_id': spec['workflow_id']})
            require(destination.resolve().is_relative_to(Path(spec['storage_root']).resolve()), 'STORAGE_PATH', 'Review packet destination escapes root', step['id'])
            saved_packet = save_verified(Path(work) / 'review-packets' / (step['id'] + '.json'), destination)
        decision_path = spec.get('decisions', {}).get(step['id'], spec.get('decision'))
        decision = read_json(decision_path) if decision_path and Path(decision_path).is_file() else {}
        require(decision.get('payload_sha256') == packet['payload_sha256'] and decision.get('gate') == step['id'] and
                decision.get('decision') == 'APPROVED' and decision.get('actor_kind') == 'HUMAN' and decision.get('decision_ref'),
                'HUMAN_DECISION_REQUIRED', 'Fixed review packet lacks an admitted decision', step['id'])
        artifacts = [{'path': str(Path(decision_path).resolve()), 'sha256': sha(Path(decision_path).read_bytes())},
                     {'path': str((Path(work) / 'review-packets' / (step['id'] + '.json')).resolve()),
                      'sha256': sha((Path(work) / 'review-packets' / (step['id'] + '.json')).read_bytes())}]
        if packet_path:
            artifacts.append({'path': str(packet_path.resolve()), 'sha256': sha(packet_path.read_bytes())})
        if saved_packet:
            artifacts.append({'path': saved_packet['path'], 'sha256': saved_packet['sha256']})
        return {'decision_ref': decision['decision_ref'], 'decision_sha256': fingerprint(decision), 'artifacts': artifacts}
    if kind == 'product-storage':
        nested_spec = read_json(Path(root) / step['spec']['path'])
        require(nested_spec['product_id'] == spec['target'], 'STORAGE_PRODUCT_BINDING', 'Storage subflow targets another product', step['id'])
        result = storage_subflow(Path(work) / 'storage-subflow', nested_spec,
                                 Path(root) / step['package']['path'], spec.get('storage_root'),
                                 read_json(spec['authorization']) if spec.get('authorization') else None,
                                 read_json(spec['receipts']) if spec.get('receipts') else None)
        if result['status'] != 'POST_SAVE_VERIFIED':
            blocker = Blocked('STORAGE_SUBFLOW_PENDING', 'Continue the returned connector request', step['id'])
            blocker.data['subflow_result'] = result
            raise blocker
        return {'storage_subflow': result, 'artifacts': []}
    if kind == 'formal-save':
        from .changed_path import save_formal
        plan = json.loads(capture(root, step['plan']))
        packet = read_json(Path(work) / 'review-packets/HUMAN_ADOPTION.json')
        decision_path = spec.get('decisions', {}).get('HUMAN_ADOPTION')
        require(decision_path and Path(decision_path).is_file(), 'HUMAN_DECISION_REQUIRED', 'Import the fixed packet decision', step['id'])
        receipt_path = spec.get('formal_receipt')
        require(receipt_path and Path(receipt_path).is_file(), 'NATIVE_FORMAL_READBACK_REQUIRED', 'Execute native save requests and readback', step['id'])
        result = save_formal(spec['storage_root'], plan, packet, read_json(decision_path), read_json(receipt_path))
        output = Path(work) / (step['id'] + '.json')
        write_json(output, result)
        selector = Path(spec['storage_root']) / plan['current_selector']
        return {'formal_save': result, 'artifacts': [{'path': str(output.resolve()), 'sha256': sha(output.read_bytes())},
                {'path': str(selector.resolve()), 'sha256': sha(selector.read_bytes())}] +
                [{'path': r['path'], 'sha256': r['sha256']} for r in result['artifacts']]}
    if kind == 'downstream-change':
        from .changed_path import apply_downstream
        plan = json.loads(capture(root, step['plan']))
        formal = read_json(Path(work) / step['formal_result'])
        result = apply_downstream(spec['downstream_checkout'], work, plan, formal)
        output = Path(work) / (step['id'] + '.json')
        write_json(output, result)
        return {'downstream_change': result, 'artifacts': [{'path': str(output.resolve()), 'sha256': sha(output.read_bytes())}] +
                [{'path': str((Path(spec['downstream_checkout']) / a['path']).resolve()), 'sha256': a['after_sha256']} for a in plan['updates']]}
    raise Blocked('STEP_KIND', 'No admitted adapter for ' + kind, step['id'])

def run(root, work, spec, stop_after=None):
    work = Path(work)
    with lock(work / '.workflow-lock'):
        try:
            capture(root, spec['input'])
            state, doc, steps = inspect(root, work, spec)
            for completed in steps[:len(state['completed_gates'])]:
                if completed['kind'] == 'product-storage':
                    execute_step(root, work, spec, completed)
            write_json(work / 'workflow-binding.json', {'sha256': fingerprint(spec), 'spec': spec, 'harness_version': VERSION})
            write_json(work / 'authority-snapshot.json', state['current_authority_snapshot'])
            for step in steps[len(state['completed_gates']):]:
                evidence = execute_step(root, work, spec, step)
                append(work, spec, step['id'], evidence)
                if stop_after == step['id']:
                    break
            result, _, _ = inspect(root, work, spec)
            result.update({'harness_version': VERSION, 'resumable': True, 'requested_gate': spec['target_gate'],
                           'required_next_action': result['pending_gates'][0] if result['pending_gates'] else None})
        except (Blocked, OSError, ValueError, KeyError, TypeError, subprocess.TimeoutExpired) as exc:
            blocker = exc.data if isinstance(exc, Blocked) else {'code': 'INPUT_OR_EXECUTION', 'reason': str(exc), 'target_gate': 'EXECUTION'}
            try:
                rows = events(work)
                resumable = True
            except (Blocked, OSError, ValueError, KeyError, TypeError):
                rows = []
                resumable = False
                blocker = {'code': 'WORKFLOW_JOURNAL', 'reason': 'Journal integrity failed; restore a verified savepoint', 'target_gate': 'RESUME'}
            result = {'workflow_id': spec.get('workflow_id'), 'state': 'HUMAN_DECISION_REQUIRED' if blocker['code'] == 'HUMAN_DECISION_REQUIRED' else 'BLOCKED',
                      'failed_gate': blocker['target_gate'], 'error_category': blocker['code'], 'blocking_reason': blocker,
                      'completed_gates': [r['gate'] for r in rows], 'last_valid_state': 'IN_PROGRESS' if rows else 'NOT_STARTED',
                      'resumable': resumable, 'required_next_action': blocker.get('resolution_condition', 'Correct the named input and resume' if resumable else 'Restore a verified durable savepoint')}
            try:
                _, steps = definition(root, spec)
                result['pending_gates'] = [s['id'] for s in steps[len(rows):]]
            except (Blocked, OSError, ValueError, KeyError, TypeError):
                result['pending_gates'] = ['INITIALIZATION']
        write_json(work / 'workflow-result.json', result)
        return result
