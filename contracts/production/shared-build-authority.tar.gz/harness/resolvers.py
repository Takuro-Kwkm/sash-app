"""Resolve supplied CURRENT indexes. Rules and adoption choices stay in repositories."""
from pathlib import Path
from .core import Blocked, fingerprint, read_json, require, sha, timestamp

CURRENT = ('CURRENT', 'ACTIVE', 'ADOPTED')
SOURCE_ROLES = ('PRIMARY_OFFICIAL', 'CURRENT_ADOPTED', 'NEW_CANDIDATE', 'PREVIOUS', 'SUPPLEMENTAL', 'ARCHIVED')

def capture(root, ref):
    p = Path(root) / ref['path']
    require(p.is_file() and not p.is_symlink(), 'REFERENCE_MISSING', str(p), 'INITIALIZATION')
    data = p.read_bytes()
    require(sha(data) == ref['sha256'], 'REFERENCE_CHANGED', ref['path'], 'INITIALIZATION')
    return data

def authorities(root, refs, index_ref=None):
    index = __import__('json').loads(capture(root, index_ref)) if index_ref else None
    if index is not None:
        require(index.get('status') in CURRENT and isinstance(index.get('entries'), list), 'AUTHORITY_INDEX', 'Current authority selector index missing', 'INITIALIZATION')
    result = []
    for ref in refs:
        require(ref.get('status') in CURRENT, 'OBSOLETE_AUTHORITY', ref.get('authority_id', '?'), 'INITIALIZATION')
        require(all(ref.get(k) for k in ('authority_id', 'authority_type', 'repository', 'version', 'resolution_source')),
                'AUTHORITY_IDENTITY', 'Authority identity is incomplete', 'INITIALIZATION')
        capture(root, ref)
        if index is not None:
            matches = [row for row in index['entries'] if row.get('authority_id') == ref['authority_id']]
            require(len(matches) == 1 and all(matches[0].get(k) == ref.get(k) for k in ('version', 'sha256', 'status', 'scope_axis')),
                    'AUTHORITY_NOT_SELECTED', 'Reference differs from current role-specific authority selector', 'INITIALIZATION')
        result.append({**ref, 'resolved_at': timestamp()})
    require(result, 'AUTHORITY_MISSING', 'No current authority references', 'INITIALIZATION')
    return result

def registry(root, ref, target):
    doc = __import__('json').loads(capture(root, ref))
    require(doc.get('status') in CURRENT, 'REGISTRY_NOT_CURRENT', ref['path'], 'INITIALIZATION')
    require(doc.get('registry_id') and doc.get('version') and isinstance(doc.get('products'), list),
            'REGISTRY_FORMAT', 'Registry identity/rows missing', 'INITIALIZATION')
    matches = [r for r in doc['products'] if target == r.get('product_id') or target in r.get('aliases', [])]
    require(len(matches) == 1, 'REGISTRY_TARGET_AMBIGUOUS', 'Target must have one explicit registry row', 'INITIALIZATION')
    require(matches[0].get('master_state') in ('PRESENT', 'ABSENT'), 'REGISTRY_STATE', 'Explicit inspected master state required', 'INITIALIZATION')
    return {'registry_id': doc['registry_id'], 'version': doc['version'], 'sha256': ref['sha256'],
            'resolved_at': timestamp(), 'entry': matches[0]}

def sources(root, refs, product_id):
    out = []
    for ref in refs:
        require(ref.get('role') in SOURCE_ROLES and ref.get('product_id') == product_id,
                'SOURCE_SCOPE', 'Source role/product mismatch', 'INITIALIZATION')
        require(ref.get('source_id') and ref.get('identity') and ref.get('version'),
                'SOURCE_IDENTITY', 'Source identity incomplete', 'INITIALIZATION')
        if ref['role'] in ('PRIMARY_OFFICIAL', 'CURRENT_ADOPTED'):
            require(ref.get('status') in CURRENT, 'OBSOLETE_SOURCE', ref['source_id'], 'INITIALIZATION')
        if ref['role'] == 'NEW_CANDIDATE':
            require(ref.get('status') == 'CANDIDATE', 'CANDIDATE_SOURCE_CURRENT', 'Candidate has not been adopted', 'INITIALIZATION')
        capture(root, ref)
        out.append({**ref, 'resolved_at': timestamp(), 'hash_kind': 'CAPTURED_BYTES_SHA256'})
    require(out, 'SOURCE_MISSING', 'No captured sources', 'INITIALIZATION')
    return out

def resolve(root, spec):
    require(spec.get('authority_index'), 'AUTHORITY_INDEX_MISSING', 'Acquire Current authority selectors', 'INITIALIZATION')
    authority = authorities(root, spec['authorities'], spec['authority_index'])
    reg = registry(root, spec['registry'], spec['target'])
    src = sources(root, spec['sources'], reg['entry']['product_id'])
    return {'authorities': authority, 'registry': reg, 'sources': src,
            'snapshot_sha256': fingerprint({'authority_index': spec['authority_index'], 'authorities': spec['authorities'], 'registry': spec['registry'], 'sources': spec['sources']})}
