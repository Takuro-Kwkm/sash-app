"""Acquisition boundary with durable named blockers; it never advances a DAG."""
from pathlib import Path
from .core import Blocked, read_json, require, sha, write_json
from .production import connector_document
from .workflow import events, inspect


def admit_source_response(root, work, spec, source_id, response, downloaded_path=None):
    work = Path(work)
    try:
        refs = [s for s in spec['sources'] if s['source_id'] == source_id]
        require(len(refs) == 1, 'SOURCE_IDENTITY', 'One bound official source required', 'ACQUISITION')
        doc = connector_document(response)
        require(doc.get('id') == source_id, 'SOURCE_IDENTITY', 'Provider returned another source', 'ACQUISITION')
        require(downloaded_path is not None and Path(downloaded_path).is_file(),
                'SOURCE_READBACK_REQUIRED', 'Download complete bytes before resume', 'ACQUISITION')
        observed = sha(Path(downloaded_path).read_bytes())
        require(observed == refs[0]['sha256'], 'SOURCE_CHANGED', 'Acquired source differs; resolve new scope', 'ACQUISITION')
        state, _, _ = inspect(root, work, spec)
        result = {'state': 'ACQUISITION_VERIFIED', 'source_id': source_id, 'sha256': observed,
                  'completed_gates': state['completed_gates'], 'resumable': True,
                  'next_action': 'Resume existing production entry point; no accepted source delta is repeated'}
    except (Blocked, OSError, ValueError, KeyError) as error:
        result = {'state': 'RECOVERABLE_BLOCKED', 'source_id': source_id, 'resumable': True,
                  'completed_gates': [r['gate'] for r in events(work)],
                  'blocking_reason': error.data if isinstance(error, Blocked) else {'code': 'SOURCE_IO', 'reason': str(error)}}
    write_json(work / 'source-acquisition-recovery.json', result)
    return result
