"""Durable product-master workflow with explicit trust and storage boundaries.

Hashes bind imported evidence; they do not authenticate reviewers. Connector
responses and approvals must be admitted by the host/repository review controls.
"""
from __future__ import annotations
import csv
import datetime as dt
import fcntl
import hashlib
import io
import json
import os
import re
import tempfile
import zipfile
from contextlib import contextmanager
from pathlib import Path, PurePosixPath

STAGES = ('QA_PASS', 'PACKAGE_SAVED', 'REGISTRY_UPDATED', 'POST_SAVE_VERIFIED')
METRICS = ('UNKNOWN', 'UNMAPPED', 'SCHEMA_ERROR', 'DUPLICATE_ID', 'CRITICAL_VALIDATION_ERROR')
COMMON_KEYS = ('APP_CHANGE_GUARDRAIL', 'COMMON_PRODUCT_APP_STANDARD',
               'PRODUCT_MASTER_COMPLETION_POLICY', 'CONTROLLED_UNRESOLVED_GOVERNANCE',
               'EVIDENCE_GOVERNANCE', 'DATA_DICTIONARY')
APP_KEYS = {
    'exterior': ('EXTERIOR_PROJECT_INSTRUCTIONS', 'EXTERIOR_SALES_ESTIMATE_REQUEST_BOUNDARY',
                 'EXTERIOR_ARCHITECTURE_GOVERNANCE'),
    'interior': ('INTERIOR_PROJECT_INSTRUCTIONS', 'INTERIOR_SALES_ESTIMATE_REQUEST_BOUNDARY',
                 'INTERIOR_ARCHITECTURE_GOVERNANCE'),
    'sash': ('SASH_PROJECT_INSTRUCTIONS', 'SALES_ESTIMATE_REQUEST_BOUNDARY',
             'SASH_PRODUCT_MASTER_COMMON', 'SASH_PACKAGE_STORAGE_GATE'),
}

class Blocked(Exception):
    def __init__(self, code, reason, gate='FORMAL', resolution=None):
        super().__init__(reason)
        self.data = {'code': code, 'reason': reason, 'target_gate': gate,
                     'resolution_condition': resolution or 'Correct the named input; resume the same work.'}


def require(ok, code, reason, gate='FORMAL'):
    if not ok:
        raise Blocked(code, reason, gate)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(obj):
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()


def fingerprint(obj):
    return sha(canonical(obj))


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def timestamp():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def atomic(path, data):
    """Same-directory atomic replace and fsync; no shared fixed temp filename."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
        directory_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def write_json(path, data):
    atomic(path, json.dumps(data, ensure_ascii=False, indent=2).encode() + b'\n')


@contextmanager
def lock(path):
    """OS-released lock; an interrupted process does not leave a stale owner."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a+b') as stream:
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise Blocked('SINGLE_WRITER', str(path), 'STORAGE_EXECUTION') from exc
        try:
            yield
        finally:
            fcntl.flock(stream, fcntl.LOCK_UN)


def safe_path(root, relative):
    require(isinstance(relative, str) and bool(relative), 'PATH', 'Empty or non-string path')
    pure = PurePosixPath(relative)
    require(not pure.is_absolute() and '..' not in pure.parts and '\\' not in relative,
            'PATH', 'Unsafe relative path: ' + relative, 'STORAGE_EXECUTION')
    root = Path(root).resolve()
    result = (root / relative).resolve()
    require(result.is_relative_to(root), 'PATH', 'Path escapes configured root', 'STORAGE_EXECUTION')
    return result


def response_content(response):
    """Accept a connector's structuredContent export, never scrape UI text."""
    if 'structuredContent' in response:
        response = response['structuredContent']
    require(isinstance(response, dict) and isinstance(response.get('content'), str),
            'CONNECTOR_RESPONSE', 'Readable connector content is missing', 'STORAGE_EXECUTION')
    return response


def active_rows(text):
    """Drive readable Sheets export is CSV sheets separated by form feed."""
    found = {}
    for section in text.lstrip('\ufeff').split('\f'):
        rows = list(csv.reader(io.StringIO(section)))
        header = next((i for i, row in enumerate(rows)
                       if 'Source_Key' in row and 'Drive_File_ID' in row and 'Status' in row), None)
        if header is None:
            continue
        names = rows[header]
        for row in rows[header + 1:]:
            item = dict(zip(names, row))
            if item.get('Status') != 'ACTIVE':
                continue
            key = item.get('Source_Key')
            require(key not in found, 'AMBIGUOUS_CURRENT', 'Multiple ACTIVE entries for ' + str(key))
            found[key] = item
    require(found, 'MANIFEST_EMPTY', 'No ACTIVE source rows found')
    return found


def resolve_sources(response, app):
    require(app in APP_KEYS, 'APP', 'Unsupported app: ' + app)
    response = response_content(response)
    require(response.get('id') and response.get('modified_time'), 'MANIFEST_IDENTITY',
            'Manifest must include ID and modified_time', 'STORAGE_EXECUTION')
    rows = active_rows(response['content'])
    keys = COMMON_KEYS + APP_KEYS[app]
    selected = []
    for key in keys:
        require(key in rows, 'AUTHORITY_MISSING', 'No ACTIVE entry for ' + key)
        row = rows[key]
        file_id = row.get('Drive_File_ID', '')
        require(re.fullmatch(r'[A-Za-z0-9_-]+', file_id) is not None,
                'AUTHORITY_ID', 'No usable Drive ID for ' + key)
        selected.append({'key': key, 'file_id': file_id, 'version': row['Version'],
                         'status': row['Status'], 'name': row['File_Name']})
    return {'manifest': {'id': response['id'], 'modified_time': response['modified_time'],
                         'readable_content_sha256': sha(response['content'].encode()),
                         'hash_kind': 'CONNECTOR_READABLE_CONTENT_NOT_SOURCE_BYTES'},
            'app': app, 'sources': selected,
            'omitted_source_count': len(rows) - len(selected)}


def bootstrap(response, app, receipts=None):
    result = resolve_sources(response, app)
    receipts = receipts or {}
    pending, acquired = [], []
    for item in result['sources']:
        if item['key'] not in receipts:
            pending.append({'request_id': item['key'], 'tool': 'google_drive.fetch',
                            'arguments': {'url': 'https://drive.google.com/file/d/' + item['file_id'] + '/view'},
                            'expected_file_id': item['file_id'], 'expected_version': item['version']})
            continue
        r = response_content(receipts[item['key']])
        require(r.get('id') == item['file_id'] and r.get('modified_time') and r['content'].strip(),
                'AUTHORITY_RECEIPT', 'Wrong/missing source identity for ' + item['key'])
        acquired.append({**item, 'modified_time': r['modified_time'],
                         'readable_content_sha256': sha(r['content'].encode())})
    return {**result, 'acquired': acquired, 'requests': pending,
            'status': 'READY' if not pending else 'WAITING_FOR_CONNECTOR',
            'next_action': 'Execute requests with the connected Drive plugin and import responses.' if pending
                           else 'Resolve product Registry and bind package/source/scope/rules/model identities.'}


def package_members(data):
    """Bounded, no extraction or execution, complete internal hash coverage."""
    require(len(data) <= 64 * 1024 * 1024, 'PACKAGE_SIZE', 'Package exceeds 64 MiB')
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
        entries = z.infolist()
        require(len(entries) <= 2000 and sum(i.file_size for i in entries) <= 128 * 1024 * 1024,
                'PACKAGE_SIZE', 'Archive exceeds bounded expansion limits')
        names = [i.filename for i in entries]
        require(len(names) == len(set(names)), 'ZIP_DUPLICATE', 'Duplicate archive paths')
        files = {}
        for info in entries:
            name = info.filename
            pure = PurePosixPath(name)
            require(not pure.is_absolute() and '..' not in pure.parts and '\\' not in name,
                    'ZIP_PATH', 'Unsafe archive path: ' + name)
            require((info.external_attr >> 16) & 0o170000 != 0o120000,
                    'ZIP_SYMLINK', 'Archive contains symlink')
            if not info.is_dir():
                files[name] = z.read(info)
    except (zipfile.BadZipFile, RuntimeError, NotImplementedError) as exc:
        raise Blocked('PACKAGE_INVALID', str(exc)) from exc
    require('PackageManifest.json' in files, 'PACKAGE_MANIFEST', 'PackageManifest.json is missing')
    manifest = json.loads(files['PackageManifest.json'])
    listed = manifest.get('files', [])
    require(isinstance(listed, list) and listed, 'PACKAGE_MANIFEST', 'Empty file manifest')
    paths = [x.get('path') for x in listed]
    require(len(paths) == len(set(paths)), 'MANIFEST_DUPLICATE', 'Duplicate manifest paths')
    require(set(paths) == set(files) - {'PackageManifest.json'}, 'PACKAGE_COVERAGE',
            'Manifest must cover every member except itself')
    for item in listed:
        b = files[item['path']]
        require(item.get('sha256') == sha(b) and item.get('bytes') == len(b),
                'MEMBER_HASH', 'Hash/size mismatch: ' + item['path'])
    return manifest, files


def inspect_package(data, expected=None):
    manifest, files = package_members(data)
    require('PRODUCT_MASTER_MANIFEST.json' in files, 'MASTER_MANIFEST', 'Product manifest missing')
    product = json.loads(files['PRODUCT_MASTER_MANIFEST.json'])
    for key in ('package_identity', 'evidence_identity'):
        require(product.get(key) and product[key] == manifest.get(key), 'IDENTITY', key + ' mismatch')
    revision = product.get('formal_revision')
    require(revision and revision == manifest.get('revision'), 'REVISION', 'Package/product revision mismatch')
    qa = json.loads(files[product['formal_content_qa']])
    scope_bytes = files[product['formal_selection_scope']]
    scope = json.loads(scope_bytes)
    require(qa.get('target_gate') == 'QA_PASS' and qa.get('result') == 'PASS',
            'QA_PASS', 'No QA_PASS proof for the formal selection scope')
    require(qa.get('scope_id') == scope.get('scope_id') and scope.get('scope_id') and
            qa.get('revision') == revision == scope.get('revision'), 'QA_SCOPE', 'QA scope/revision mismatch')
    require(all(type(qa.get('metrics', {}).get(k)) is int and qa['metrics'][k] == 0 for k in METRICS),
            'CRITICAL_METRICS', 'Missing or nonzero formal-scope critical metrics')
    checks = qa.get('checks', [])
    require(checks and all(x.get('actual') == 'PASS' for x in checks), 'QA_CHECKS', 'Missing/failed QA check')
    require(len({x.get('check_id') for x in checks}) == len(checks) and all(x.get('check_id') for x in checks),
            'QA_DUPLICATE', 'Missing/duplicate check identity')
    require(type(qa.get('formal_pass_count')) is int and qa['formal_pass_count'] == len(checks) ==
            qa.get('formal_additional_checks'), 'QA_COUNT', 'Formal QA count mismatch')
    result = {'package_sha256': sha(data), 'package_identity': product['package_identity'],
              'revision': revision, 'manufacturer': product.get('manufacturer'), 'series': product.get('series'),
              'evidence_identity': product['evidence_identity'], 'scope_sha256': sha(scope_bytes),
              'qa_sha256': sha(files[product['formal_content_qa']]), 'member_count': len(files),
              'content_gate': 'QA_PASS', 'content_validation': 'IMPORTED_CONTENT_BOUND_QA_PROOF',
              'product_qa_rerun': False, 'storage_gate': 'NOT_CHECKED', 'registry_gate': 'NOT_CHECKED'}
    require(result['manufacturer'] and result['series'], 'PRODUCT_IDENTITY', 'Manufacturer/series missing')
    if expected:
        for key, value in expected.items():
            require(key in result and result[key] == value, 'EXPECTED_IDENTITY', key + ' differs from fixed input')
    return result


def package_baseline(data, refs):
    """Compute four baseline hashes from actual package members / JSON pointers."""
    _, files = package_members(data)
    require(isinstance(refs, dict) and set(refs) == {'source', 'scope', 'rules', 'model'},
            'BASELINE_REFS', 'Source/scope/rules/model package selectors required')
    result = {}
    for kind, ref in refs.items():
        require(isinstance(ref, dict) and set(ref).issubset({'path', 'pointer'}) and ref.get('path') in files,
                'BASELINE_REFS', 'Unknown package member for ' + kind)
        data_bytes = files[ref['path']]
        if 'pointer' in ref:
            pointer = ref['pointer']
            require(isinstance(pointer, str) and (pointer == '' or pointer.startswith('/')),
                    'BASELINE_REFS', 'Invalid JSON pointer')
            value = json.loads(data_bytes)
            for token in pointer.split('/')[1:] if pointer else []:
                token = token.replace('~1', '/').replace('~0', '~')
                value = value[int(token)] if isinstance(value, list) else value[token]
            data_bytes = canonical(value)
        result[kind] = sha(data_bytes)
    return result


def bound_inputs(spec):
    """Source, scope, rules, model and actual artifacts all participate in carry-forward."""
    from jsonschema import Draft202012Validator
    schema = read_json(Path(__file__).resolve().parents[1] / 'schemas/product-work-input.schema.json')
    errors = list(Draft202012Validator(schema).iter_errors(spec))
    require(not errors, 'WORK_SCHEMA', '; '.join(e.message for e in errors))
    required = ('source', 'scope', 'rules', 'model')
    baseline = spec.get('baseline', {})
    require(set(baseline) == set(required) and all(re.fullmatch(r'[a-f0-9]{64}', baseline[k])
            for k in required), 'BASELINE', 'Four baseline content hashes are required')
    require(spec.get('qa_baseline') == baseline, 'STALE_QA',
            'Source/scope/rules/model changed; affected QA must be completed before carry-forward')
    require(spec.get('product_id') and spec.get('work_id'), 'WORK_IDENTITY', 'Product/work identity missing')
    require(spec.get('adapter') in ('filesystem', 'drive_bridge'), 'ADAPTER', 'Unknown storage adapter')
    require(spec.get('target_gate') == 'POST_SAVE_VERIFIED', 'TARGET', 'Unsupported terminal state')
    require(isinstance(spec.get('expected'), dict) and
            all(k in spec['expected'] for k in ('package_sha256', 'package_identity', 'revision',
                                               'manufacturer', 'series', 'evidence_identity', 'scope_sha256', 'qa_sha256')),
            'EXPECTED_IDENTITY', 'Complete fixed package/product/scope/QA identity required')
    require(spec['baseline']['scope'] == spec['expected']['scope_sha256'],
            'BASELINE_SCOPE', 'Baseline scope must be the actual scope bytes hash')
    return fingerprint(spec)


def journal(work):
    path = Path(work) / 'events.json'
    events = read_json(path) if path.exists() else []
    previous = '0' * 64
    for index, event in enumerate(events):
        payload = {k: v for k, v in event.items() if k != 'event_sha256'}
        require(event.get('sequence') == index and event.get('previous_sha256') == previous and
                event.get('event_sha256') == fingerprint(payload), 'JOURNAL_CHANGED', 'Event chain is invalid')
        require(index < len(STAGES) and event.get('stage') == STAGES[index],
                'STAGE_ORDER', 'Invalid workflow transition')
        previous = event['event_sha256']
    return events


def append_event(work, stage, binding, evidence):
    events = journal(work)
    require(len(events) < len(STAGES) and stage == STAGES[len(events)], 'STAGE_ORDER', 'Cannot skip/repeat stage')
    payload = {'sequence': len(events), 'stage': stage, 'binding_sha256': binding,
               'previous_sha256': events[-1]['event_sha256'] if events else '0' * 64,
               'recorded_at': timestamp(), 'evidence': evidence}
    events.append({**payload, 'event_sha256': fingerprint(payload)})
    write_json(Path(work) / 'events.json', events)


def review_payload(spec):
    return {k: spec[k] for k in ('work_id', 'product_id', 'adapter', 'target_gate', 'expected',
                                'baseline', 'baseline_refs', 'destination', 'registry')}


def validate_authorization(spec, authorization):
    """An imported external decision, never generated by run/resume."""
    require(isinstance(authorization, dict), 'APPROVAL_REQUIRED', 'A content-bound external authorization is required')
    require(authorization.get('decision') == 'APPROVED' and authorization.get('reviewer') and
            authorization.get('decision_ref') and authorization.get('authorization_kind') in
            ('EXPLICIT_USER_SCOPE', 'HUMAN_PACKET_ADOPTION'), 'APPROVAL_REQUIRED', 'No admitted approval decision')
    require(authorization.get('review_payload_sha256') == fingerprint(review_payload(spec)),
            'STALE_APPROVAL', 'Approval does not bind this exact product, revision, payload and destination')
    require(authorization.get('work_id') == spec['work_id'] and authorization.get('product_id') == spec['product_id'],
            'APPROVAL_SCOPE', 'Approval belongs to another work/product')
    return fingerprint(authorization)


def validate_binding(work, spec):
    binding = bound_inputs(spec)
    events = journal(work)
    require(all(e['binding_sha256'] == binding for e in events), 'WORK_CHANGED',
            'Input changed after checkpoint; create a scoped Change Work')
    saved = Path(work) / 'binding.json'
    if saved.exists():
        require(read_json(saved)['sha256'] == binding, 'WORK_CHANGED', 'Pinned work input changed')
    return binding, events


def plan(work, spec):
    binding, events = validate_binding(work, spec)
    stage = STAGES[len(events)] if len(events) < len(STAGES) else None
    return {'work_id': spec['work_id'], 'product_id': spec['product_id'], 'binding_sha256': binding,
            'completed': [x['stage'] for x in events], 'next_stage': stage,
            'status': 'POST_SAVE_VERIFIED' if stage is None else 'IN_PROGRESS',
            'adapter': spec['adapter'], 'required_action': stage,
            'review_payload_sha256': fingerprint(review_payload(spec)),
            'qa_reuse': 'CONTENT_BOUND; NO PRODUCT QA RERUN', 'target_gate': spec['target_gate']}


def registry_entry(spec):
    return {'product_id': spec['product_id'], **spec['expected'], 'lifecycle': 'FORMAL',
            'package_location': spec['destination'], 'adapter': spec['adapter']}


def registry_upsert(path, entry, previous_sha):
    path = Path(path)
    current = path.read_bytes() if path.exists() else b''
    document = json.loads(current) if current else {'products': {}}
    require(isinstance(document, dict) and isinstance(document.get('products'), dict),
            'REGISTRY_FORMAT', 'Invalid local adapter registry')
    old = document['products'].get(entry['product_id'])
    if old == entry:
        return  # crash after write before checkpoint; idempotent recovery
    require(sha(current) == previous_sha, 'REGISTRY_CONFLICT', 'Registry changed since bootstrap', 'STORAGE_EXECUTION')
    document['products'][entry['product_id']] = entry
    write_json(path, document)


def expected_bridge(spec, stage, package):
    e = spec['expected']
    target = spec['destination']
    registry = spec['registry']
    require(isinstance(target, dict) and all(target.get(k) for k in ('parent_id', 'name')),
            'DRIVE_DESTINATION', 'Drive folder ID/name required', 'STORAGE_EXECUTION')
    require(isinstance(registry, dict) and all(registry.get(k) for k in ('file_id', 'range', 'before_sha256')),
            'DRIVE_REGISTRY', 'Drive Registry ID/range/pre-write hash required', 'STORAGE_EXECUTION')
    request = {'request_id': spec['work_id'] + ':' + stage, 'stage': stage,
               'work_binding_sha256': bound_inputs(spec), 'product_id': spec['product_id'],
               'expected': e, 'destination': target, 'registry': registry,
               'package_path': str(Path(package).resolve())}
    operations = {
        'PACKAGE_SAVED': 'Upload the exact package bytes into the verified product folder; read metadata back.',
        'REGISTRY_UPDATED': 'Read the fixed Registry range, compare before_sha256, update only the product row, then read it back.',
        'POST_SAVE_VERIFIED': 'Fetch saved package bytes and metadata again; read Registry row and verify every identity.'}
    request['operation'] = operations[stage]
    request['receipt_contract'] = {'request_id': request['request_id'], 'work_binding_sha256': request['work_binding_sha256'],
        'stage': stage, 'package': {'file_id': 'observed result', 'parent_id': target['parent_id'], 'name': target['name'],
                                'sha256': e['package_sha256']},
        'registry': {'file_id': registry['file_id'], 'range': registry['range'], 'entry': registry_entry(spec)},
        'hash_kind': 'DOWNLOADED_BYTES_SHA256 at POST_SAVE_VERIFIED; UPLOAD_BYTES_SHA256 otherwise',
        'observed_at': 'ISO UTC timestamp', 'connector_result_ref': 'host-admitted tool result reference'}
    return request


def validate_bridge_receipt(receipt, request, saved_file_id=None):
    for key in ('request_id', 'work_binding_sha256', 'stage'):
        require(receipt.get(key) == request[key], 'RECEIPT_SCOPE', key + ' mismatch', 'STORAGE_EXECUTION')
    require(receipt.get('connector_result_ref') and receipt.get('observed_at'),
            'RECEIPT_PROVENANCE', 'Connector result/time missing', 'STORAGE_EXECUTION')
    p = receipt.get('package', {})
    require(p.get('file_id') and p.get('parent_id') == request['destination']['parent_id'] and
            p.get('name') == request['destination']['name'] and p.get('sha256') == request['expected']['package_sha256'],
            'DRIVE_READBACK', 'Saved package identity mismatch', 'STORAGE_EXECUTION')
    if saved_file_id:
        require(p['file_id'] == saved_file_id, 'DRIVE_FILE_CHANGED', 'Readback uses another File ID', 'STORAGE_EXECUTION')
    if request['stage'] == 'POST_SAVE_VERIFIED':
        require(receipt.get('hash_kind') == 'DOWNLOADED_BYTES_SHA256', 'READBACK_HASH_KIND',
                'Final verification requires freshly downloaded bytes', 'STORAGE_EXECUTION')
    if request['stage'] != 'PACKAGE_SAVED':
        r = receipt.get('registry', {})
        require(r.get('file_id') == request['registry']['file_id'] and r.get('range') == request['registry']['range'] and
                r.get('entry') == registry_entry_from_request(request), 'REGISTRY_READBACK',
                'Registry row identity mismatch', 'STORAGE_EXECUTION')
    if request['stage'] == 'REGISTRY_UPDATED':
        require(receipt.get('registry_before_sha256') == request['registry']['before_sha256'],
                'REGISTRY_CONFLICT', 'Registry pre-write row hash differs', 'STORAGE_EXECUTION')
        require(re.fullmatch(r'[a-f0-9]{64}', receipt.get('unrelated_rows_before_sha256', '')) and
                receipt['unrelated_rows_before_sha256'] == receipt.get('unrelated_rows_after_sha256'),
                'REGISTRY_OTHER_ROWS', 'Unrelated Registry rows changed or preservation proof missing', 'STORAGE_EXECUTION')
    return receipt


def registry_entry_from_request(request):
    return {'product_id': request['product_id'], **request['expected'], 'lifecycle': 'FORMAL',
            'package_location': request['destination'], 'adapter': 'drive_bridge'}


def run(work, spec, package, storage_root=None, authorization=None, receipts=None):
    work = Path(work)
    package = Path(package)
    receipts = receipts or {}
    # Lock product across different work directories in the same storage/work root.
    lock_root = Path(storage_root) if spec.get('adapter') == 'filesystem' and storage_root else work.parent
    with lock(lock_root / '.harness-locks' / (fingerprint(spec.get('product_id')) + '.lock')):
        binding, events = validate_binding(work, spec)
        package_data = package.read_bytes()
        info = inspect_package(package_data, spec['expected'])
        require(package_baseline(package_data, spec.get('baseline_refs')) == spec['baseline'],
                'BASELINE_CONTENT', 'Actual source/scope/rules/model differs from fixed QA baseline')
        work.mkdir(parents=True, exist_ok=True)
        if not (work / 'binding.json').exists():
            write_json(work / 'binding.json', {'sha256': binding, 'spec': spec})
        if not events:
            append_event(work, 'QA_PASS', binding, info)
        # Preserve content PASS when approval/storage is blocked.
        if len(journal(work)) < len(STAGES):
            validate_authorization(spec, authorization)
        if spec['adapter'] == 'filesystem':
            require(storage_root is not None, 'STORAGE_ROOT', 'Filesystem adapter requires storage root', 'STORAGE_EXECUTION')
            target = safe_path(storage_root, spec['destination'])
            registry = safe_path(storage_root, spec['registry'])
            require(target != registry and not target.is_relative_to(work.resolve()) and
                    not registry.is_relative_to(work.resolve()), 'STORAGE_PATH', 'Output overlaps work/Registry', 'STORAGE_EXECUTION')
            # Registry lock also prevents different products from overwriting each other's updates.
            with lock(Path(storage_root) / '.harness-locks' / 'registry.lock'):
                return run_filesystem(work, spec, package, target, registry, binding)
        return run_bridge(work, spec, package, receipts, binding)


def run_filesystem(work, spec, package, target, registry, binding):
    for stage in STAGES[len(journal(work)):]:
        if stage == 'PACKAGE_SAVED':
            data = package.read_bytes()
            require(sha(data) == spec['expected']['package_sha256'], 'INPUT_CHANGED', 'Package changed during execution')
            if target.exists():
                require(sha(target.read_bytes()) == spec['expected']['package_sha256'],
                        'FORMAL_IMMUTABLE', 'Existing formal package differs; use a new revision', 'STORAGE_EXECUTION')
            else:
                atomic(target, data)
            require(sha(target.read_bytes()) == spec['expected']['package_sha256'], 'SAVE_READBACK', 'Saved bytes differ')
            evidence = {'path': str(target), 'sha256': sha(target.read_bytes())}
        elif stage == 'REGISTRY_UPDATED':
            require(target.exists() and sha(target.read_bytes()) == spec['expected']['package_sha256'],
                    'SAVE_READBACK', 'Stored package changed before Registry update', 'STORAGE_EXECUTION')
            registry_upsert(registry, registry_entry(spec), spec['registry_before_sha256'])
            evidence = {'path': str(registry), 'entry': read_json(registry)['products'][spec['product_id']]}
        else:
            inspect_package(target.read_bytes(), spec['expected'])
            require(read_json(registry)['products'].get(spec['product_id']) == registry_entry(spec),
                    'REGISTRY_READBACK', 'Registry and package differ', 'STORAGE_EXECUTION')
            evidence = {'package_sha256': sha(target.read_bytes()), 'registry_entry': registry_entry(spec)}
        append_event(work, stage, binding, evidence)
    # Recheck terminal outputs on every resume; a saved terminal status is not sufficient.
    inspect_package(target.read_bytes(), spec['expected'])
    require(read_json(registry)['products'].get(spec['product_id']) == registry_entry(spec),
            'REGISTRY_READBACK', 'Terminal Registry changed', 'STORAGE_EXECUTION')
    return plan(work, spec)


def run_bridge(work, spec, package, receipts, binding):
    for stage in STAGES[len(journal(work)):]:
        request = expected_bridge(spec, stage, package)
        if stage not in receipts:
            write_json(work / 'pending-request.json', request)
            return {**plan(work, spec), 'status': 'WAITING_FOR_CONNECTOR', 'request': request}
        events = journal(work)
        saved_file_id = next((e['evidence']['package']['file_id'] for e in events
                              if e['stage'] == 'PACKAGE_SAVED'), None)
        receipt = validate_bridge_receipt(receipts[stage], request, saved_file_id)
        append_event(work, stage, binding, receipt)
    pending = work / 'pending-request.json'
    if pending.exists():
        pending.unlink()
    return {**plan(work, spec), 'verification_mode': 'HOST_ADMITTED_CONNECTOR_RECEIPTS',
            'last_verified_at': journal(work)[-1]['evidence']['observed_at']}


def verify_existing(data, registry_response, master_metadata, package_metadata, series_id):
    """Read-only pilot: compare native Registry index, metadata and downloaded ZIP.

    No product QA or native cell-level QA is rerun. Registry's package/evidence
    note is an index assertion; the downloaded ZIP validates its own bytes.
    """
    info = inspect_package(data)
    r = response_content(registry_response)
    rows = []
    for section in r['content'].split('\f'):
        records = list(csv.reader(io.StringIO(section)))
        header = next((i for i, row in enumerate(records)
                       if 'series_id' in row and 'authoring_file_id' in row and 'formal_adoption' in row), None)
        if header is not None:
            rows += [dict(zip(records[header], row)) for row in records[header + 1:]]
    matching = [row for row in rows if row.get('series_id') == series_id]
    require(len(matching) == 1, 'REGISTRY_IDENTITY', 'Registry product must resolve uniquely')
    row = matching[0]
    require(row.get('manufacturer') == info['manufacturer'] and row.get('series') == info['series'] and
            row.get('product_master_status') == 'FORMAL' and row.get('formal_adoption') == 'FORMAL_PASS' and
            row.get('qa_status') == 'PASS' and row.get('storage_gate') == 'PASS' and
            row.get('registry_status') == 'REGISTERED', 'REGISTRY_IDENTITY', 'Formal Registry identity/status differs')
    for metadata in (master_metadata, package_metadata):
        require(metadata.get('id') and metadata.get('modified_time'), 'METADATA_IDENTITY', 'Metadata ID/time missing')
    require(master_metadata['id'] == row['authoring_file_id'] and
            master_metadata.get('title', master_metadata.get('name')) == row['authoring_file_name'] and
            row['canonical_folder_id'] in master_metadata.get('parent_ids', master_metadata.get('parents', [])),
            'MASTER_METADATA', 'Native master metadata differs from Registry')
    require(row['canonical_folder_id'] in package_metadata.get('parent_ids', package_metadata.get('parents', [])),
            'PACKAGE_METADATA', 'Package parent differs from canonical folder')
    notes = row.get('next_action', '')
    require('Package=' + package_metadata['id'] in notes and info['package_sha256'] in notes and
            info['evidence_identity'] in notes and info['revision'] in notes,
            'REGISTRY_PACKAGE_INDEX', 'Registry package/evidence/revision assertion differs')
    return {**info, 'status': 'EXISTING_FORMAL_READBACK_VERIFIED', 'registry_gate': 'PASS', 'storage_gate': 'PASS',
            'verification_scope': 'DOWNLOADED_PACKAGE_BYTES_AND_NATIVE_REGISTRY_INDEX_METADATA',
            'registry_file_id': r['id'], 'registry_modified_time': r['modified_time'],
            'master_file_id': master_metadata['id'], 'package_file_id': package_metadata['id'],
            'canonical_folder_id': row['canonical_folder_id'], 'product_qa_rerun': False,
            'native_cell_qa_rerun': False, 'writes_performed': 0, 'observed_at': timestamp()}
