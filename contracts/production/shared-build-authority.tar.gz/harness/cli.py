"""Small JSON-only CLI for ChatGPT Work and local execution."""
import argparse
import json
import sys
from pathlib import Path
from .core import (Blocked, bootstrap, bound_inputs, fingerprint, inspect_package, journal,
                   plan, read_json, review_payload, run, sha, write_json, package_baseline, require, verify_existing)


def parser():
    p = argparse.ArgumentParser(prog='product-harness')
    sub = p.add_subparsers(dest='command', required=True)
    b = sub.add_parser('bootstrap', help='Resolve ACTIVE, task-specific sources from live connector export')
    b.add_argument('--manifest', required=True)
    b.add_argument('--app', choices=('exterior', 'interior', 'sash'), required=True)
    b.add_argument('--receipts')
    b.add_argument('--output')
    i = sub.add_parser('inspect', help='Check package hashes and imported QA proof; read only')
    i.add_argument('--package', required=True)
    i.add_argument('--expected')
    i.add_argument('--output')
    v = sub.add_parser('verify-existing', help='Read-only native Drive index/package/metadata verification')
    v.add_argument('--package', required=True)
    v.add_argument('--registry-response', required=True)
    v.add_argument('--master-metadata', required=True)
    v.add_argument('--package-metadata', required=True)
    v.add_argument('--series-id', required=True)
    v.add_argument('--output')
    for name in ('plan', 'check', 'run', 'resume'):
        c = sub.add_parser(name)
        c.add_argument('--spec', required=True)
        c.add_argument('--work', required=True)
        if name in ('check', 'run', 'resume'):
            c.add_argument('--package', required=True)
        if name in ('run', 'resume'):
            c.add_argument('--storage-root')
            c.add_argument('--authorization')
            c.add_argument('--receipts')
        c.add_argument('--output')
    a = sub.add_parser('review-payload', help='Prepare exact authorization payload, not approval')
    a.add_argument('--spec', required=True)
    a.add_argument('--output')
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        if args.command == 'bootstrap':
            result = bootstrap(read_json(args.manifest), args.app,
                               read_json(args.receipts) if args.receipts else None)
        elif args.command == 'inspect':
            result = inspect_package(Path(args.package).read_bytes(), read_json(args.expected) if args.expected else None)
            result['status'] = 'PACKAGE_CONTENT_PROOF_VALID'
        elif args.command == 'verify-existing':
            result = verify_existing(Path(args.package).read_bytes(), read_json(args.registry_response),
                                     read_json(args.master_metadata), read_json(args.package_metadata), args.series_id)
        elif args.command == 'review-payload':
            spec = read_json(args.spec)
            bound_inputs(spec)
            payload = review_payload(spec)
            result = {'payload': payload, 'review_payload_sha256': fingerprint(payload),
                      'status': 'PREPARED_NOT_APPROVED'}
        else:
            spec = read_json(args.spec)
            if args.command == 'plan':
                result = plan(args.work, spec)
            elif args.command == 'check':
                data = Path(args.package).read_bytes()
                require(package_baseline(data, spec.get('baseline_refs')) == spec['baseline'], 'BASELINE_CONTENT', 'Package baseline differs')
                result = {**plan(args.work, spec), 'package': inspect_package(data, spec['expected'])}
            else:
                result = run(args.work, spec, args.package, args.storage_root,
                             read_json(args.authorization) if args.authorization else None,
                             read_json(args.receipts) if args.receipts else None)
        if args.command in ('run', 'resume'):
            write_json(Path(args.work) / 'last-result.json', result)
        if args.output:
            write_json(args.output, result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 3 if result.get('status') == 'WAITING_FOR_CONNECTOR' else 0
    except Blocked as exc:
        result = {'status': 'BLOCKED', 'blocker': exc.data}
    except (OSError, ValueError, KeyError, TypeError) as exc:
        result = {'status': 'BLOCKED', 'blocker': {'code': 'INPUT_OR_STORAGE_ERROR', 'reason': str(exc),
                  'target_gate': 'STORAGE_EXECUTION', 'resolution_condition': 'Correct the failed input or storage operation; resume.'}}
    if args.command in ('run', 'resume'):
        try:
            write_json(Path(args.work) / 'last-result.json', result)
        except OSError:
            pass
    if getattr(args, 'output', None):
        try:
            write_json(args.output, result)
        except OSError:
            pass
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 2


if __name__ == '__main__':
    sys.exit(main())
