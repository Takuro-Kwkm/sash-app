"""Host continuation across a verified, approved native Registry transaction.

The frozen Work and its accepted journal remain unchanged. Only a same-payload
Human Decision plus the actual transaction readback admits the planned row
change; all other observations, rows, HEAD and code remain pinned.
"""
import csv
import io
import json
from pathlib import Path
from .core import Blocked, fingerprint, read_json, require, sha, write_json
from .changed_path import validate_plan, verify_decision
from .production import connector_document, observation_fingerprint, live_guard, run_production, recovery
from .workflow import run, events


def registry_rows(raw):
    content = connector_document(raw)
    require(isinstance(content, str), 'NATIVE_REGISTRY', 'Complete native CSV required', 'RESUME')
    rows = list(csv.reader(io.StringIO(content)))
    headers = [i for i, row in enumerate(rows) if all(k in row for k in ('manufacturer', 'series', 'package_version'))]
    require(len(headers) == 1, 'NATIVE_REGISTRY', 'One Registry header required', 'RESUME')
    i = headers[0]
    return rows, i, rows[i]


def approved_registry_guard(binding, live_raw, before_raw, plan, packet, decision, receipt, live_files):
    transaction = validate_plan(plan)
    decision_ref = verify_decision(packet, decision)
    require(packet['native_packet']['proposed_formal_plan_sha256'] == transaction,
            'STALE_DECISION', 'Approved plan differs', 'RESUME')
    require(receipt.get('status') == 'POST_SAVE_VERIFIED' and receipt.get('plan_sha256') == transaction
            and receipt.get('decision_ref') == decision_ref
            and receipt.get('registry_entry') == plan['native_registry_after']
            and receipt.get('downloaded_artifact_hashes') == plan['native_artifact_hashes']
            and receipt.get('raw_connector_refs'),
            'NATIVE_FORMAL_READBACK_REQUIRED', 'Actual native transaction readback required', 'RESUME')
    require(observation_fingerprint(before_raw) == binding['observations']['native_registry'],
            'NATIVE_REGISTRY_BEFORE', 'Original acquired Registry differs', 'RESUME')
    after_raw = live_raw.get('observations', {}).get('native_registry')
    require(after_raw is not None, 'LIVE_OBSERVATION_MISSING', 'Reacquire native Registry', 'RESUME')
    old, oi, header = registry_rows(before_raw)
    new, ni, new_header = registry_rows(after_raw)
    require(oi == ni and header == new_header and len(old) == len(new),
            'LIVE_AUTHORITY_CHANGED', 'Registry structure changed', 'RESUME')
    before, after = plan['native_registry_before'], plan['native_registry_after']
    require(set(header) == set(before) == set(after), 'NATIVE_REGISTRY', 'Exact native row schema required', 'RESUME')
    matches = [i for i, row in enumerate(old) if i > oi and row == [before[k] for k in header]]
    require(len(matches) == 1, 'NATIVE_REGISTRY_AMBIGUOUS', 'One exact previous product row required', 'RESUME')
    row_index = matches[0]
    expected = [list(row) for row in old]
    expected[row_index] = [after[k] for k in header]
    require(new == expected, 'LIVE_AUTHORITY_CHANGED', 'Unrelated Registry rows changed or target differs', 'RESUME')
    adjusted = {**binding, 'observations': {**binding['observations'],
                 'native_registry': observation_fingerprint(after_raw)}}
    live_guard(adjusted, live_raw, live_files)
    return {'status': 'PASS', 'plan_sha256': transaction, 'decision_ref': decision_ref,
            'native_registry_before': observation_fingerprint(before_raw),
            'native_registry_after': observation_fingerprint(after_raw)}


def resume_approved(root, work, spec, live_raw, before_raw, plan, receipt, stop_after=None):
    root, work = Path(root), Path(work)
    binding_path = root / spec['production_binding']['path']
    binding = read_json(binding_path)
    current = live_raw.get('observations', {}).get('native_registry')
    if current is not None and observation_fingerprint(current) == binding['observations']['native_registry']:
        return run_production(root, work, spec, live_raw, stop_after)
    try:
        require(sha(binding_path.read_bytes()) == spec['production_binding']['sha256'],
                'PRODUCTION_BINDING_CHANGED', 'Frozen binding changed', 'RESUME')
        require(plan['work_id'] == spec['workflow_id'] and plan['product_id'] == spec['target'],
                'FORMAL_PLAN', 'Plan belongs to another Work', 'RESUME')
        packet = read_json(work / 'review-packets/HUMAN_ADOPTION.json')
        require(packet['work_binding_sha256'] == fingerprint(spec), 'STALE_DECISION', 'Work changed', 'RESUME')
        decision = read_json(spec['decisions']['HUMAN_ADOPTION'])
        admitted = approved_registry_guard(binding, live_raw, before_raw, plan, packet, decision, receipt,
                   {p: Path(binding['checkout']) / p for p in binding['files']})
        result = recovery(run(root, work, spec, stop_after=stop_after))
        result = {**result, 'approved_native_continuation': admitted}
    except (Blocked, OSError, ValueError, KeyError) as error:
        blocker = error.data if isinstance(error, Blocked) else {'code': 'PRODUCTION_IO', 'reason': str(error), 'target_gate': 'RESUME'}
        result = {'state': 'RECOVERABLE_BLOCKED', 'resumable': True,
                  'completed_gates': [r['gate'] for r in events(work)], 'blocking_reason': blocker}
    write_json(work / 'production-result.json', result)
    return result


def main():
    import argparse
    parser = argparse.ArgumentParser()
    for key in ('root', 'work', 'spec', 'live-state', 'before-registry', 'plan', 'native-receipt'):
        parser.add_argument('--' + key, required=True)
    args = parser.parse_args()
    result = resume_approved(args.root, args.work, read_json(args.spec), read_json(args.live_state),
                             read_json(args.before_registry), read_json(args.plan), read_json(args.native_receipt))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 2 if result['state'] in ('RECOVERABLE_BLOCKED', 'HUMAN_DECISION_REQUIRED') else 0


if __name__ == '__main__':
    raise SystemExit(main())
