"""Changed production transactions; native contracts own every product fact.

One immutable promotion identity, a compare-and-swap Current selector, and
bounded downstream replacements. Remote publication/readback is a host task.
These functions never manufacture a Human Decision or a provider receipt.
"""
import json
from pathlib import Path
from .core import Blocked, atomic, fingerprint, lock, read_json, require, sha, write_json
from .artifacts import save_verified


def checked_bytes(ref):
    path = Path(ref['path'])
    require(path.is_file() and not path.is_symlink(), 'SOURCE_FETCH_FAILURE', str(path), 'SOURCE_ACQUISITION')
    data = path.read_bytes()
    require(sha(data) == ref['sha256'], 'CONTENT_DRIFT', str(path), 'RESUME')
    return data


def safe_destination(root, relative):
    root, path = Path(root).resolve(), Path(root) / relative
    require(path.resolve().is_relative_to(root) and not path.is_symlink(),
            'ARTIFACT_PATH', relative, 'STORAGE')
    require(relative and '..' not in Path(relative).parts and not Path(relative).is_absolute(),
            'ARTIFACT_PATH', relative, 'STORAGE')
    return path


def verify_decision(packet, decision):
    native = packet.get('native_packet', {})
    require(native.get('payload_sha256') == fingerprint({k: v for k, v in native.items() if k != 'payload_sha256'}),
            'REVIEW_PACKET_CHANGED', 'Native packet changed', 'HUMAN_ADOPTION')
    require(packet.get('payload_sha256') == fingerprint({'work_binding_sha256': packet.get('work_binding_sha256'),
                                                        'native_packet': native}),
            'REVIEW_PACKET_CHANGED', 'Workflow packet changed', 'HUMAN_ADOPTION')
    require(decision.get('actor_kind') == 'HUMAN' and decision.get('decision') == 'APPROVED'
            and decision.get('gate') == packet.get('gate') == 'HUMAN_ADOPTION'
            and decision.get('decision_ref') and decision.get('payload_sha256') == packet['payload_sha256'],
            'HUMAN_DECISION_REQUIRED', 'Admit a real same-payload external decision', 'HUMAN_ADOPTION')
    # The host authenticates the real user event; JSON alone proves no issuer.
    return decision['decision_ref']


def validate_plan(plan):
    require(plan.get('product_id') and plan.get('revision') and plan.get('work_id'),
            'FORMAL_PLAN', 'Bound native identity required', 'FORMAL_SAVE')
    require(plan['current_after']['product_id'] == plan['product_id']
            and plan['current_after']['revision'] == plan['revision']
            and plan['current_after']['lifecycle_state'] == 'FORMAL',
            'FORMAL_PLAN', 'Current selector must identify the promoted Formal', 'FORMAL_SAVE')
    names = [a['destination'] for a in plan['artifacts']]
    require(len(set(names)) == len(names), 'DUPLICATE_ARTIFACT', 'One destination per artifact', 'FORMAL_SAVE')
    roles = {a['role'] for a in plan['artifacts']}
    require({'PRODUCT_MASTER', 'FIELD_STATE', 'EVIDENCE', 'PROMOTION',
             'FORMAL_REGISTRY', 'AUTHORITY', 'SOURCE_BASELINE'}.issubset(roles),
            'FORMAL_PLAN', 'Native Formal transaction is incomplete', 'FORMAL_SAVE')
    require(set(plan['current_after']['artifacts']) == set(names),
            'FORMAL_PLAN', 'Next Current resolution must discover every saved artifact', 'FORMAL_SAVE')
    for a in plan['artifacts']:
        require(plan['current_after']['artifacts'][a['destination']] == a['source']['sha256'],
                'FORMAL_PLAN', 'Current hash differs from pinned artifact', 'FORMAL_SAVE')
        checked_bytes(a['source'])
    return fingerprint(plan)


def resolve_current(root, selector):
    document = read_json(safe_destination(root, selector))
    require(document.get('lifecycle_state') == 'FORMAL', 'CURRENT_NOT_FORMAL', selector, 'CURRENT_FORMAL_RESOLUTION')
    for name, expected in document['artifacts'].items():
        path = safe_destination(root, name)
        require(path.is_file() and sha(path.read_bytes()) == expected,
                'PARTIAL_SAVE', name, 'CURRENT_FORMAL_RESOLUTION')
    if document.get('human_decision'):
        ref = document['human_decision']
        path = safe_destination(root, ref['path'])
        require(path.is_file() and fingerprint(read_json(path)) == ref['sha256'],
                'PARTIAL_SAVE', ref['path'], 'CURRENT_FORMAL_RESOLUTION')
    return document


def save_formal(root, plan, packet, decision, native_receipt):
    """Publish only after actual native Registry/package readback is admitted.

    Native Drive remains the app's existing authority. The host must execute
    its immutable plan, preserve the raw connector responses, and reacquire
    the target row/package; this projected repository index cannot replace it.
    """
    transaction = validate_plan(plan)
    decision_ref = verify_decision(packet, decision)
    require(packet['native_packet']['proposed_formal_plan_sha256'] == transaction,
            'STALE_DECISION', 'Approved transaction differs', 'FORMAL_SAVE')
    require(native_receipt.get('plan_sha256') == transaction
            and native_receipt.get('decision_ref') == decision_ref
            and native_receipt.get('status') == 'POST_SAVE_VERIFIED'
            and native_receipt.get('registry_entry') == plan['native_registry_after']
            and native_receipt.get('downloaded_artifact_hashes') == plan['native_artifact_hashes']
            and native_receipt.get('raw_connector_refs'),
            'NATIVE_FORMAL_READBACK_REQUIRED', 'Execute and reread native package/Registry first', 'FORMAL_SAVE')
    selector = safe_destination(root, plan['current_selector'])
    with lock(selector.with_suffix('.transaction.lock')):
        current = read_json(selector) if selector.exists() else None
        before = plan['current_before']
        # Approval does not exist when its packet is frozen. Persist the actual
        # admitted decision separately; never pre-generate a Human artifact.
        decision_path = f"formal/{plan['work_id']}/human-decision.json"
        after = {**plan['current_after'], 'human_decision': {'path': decision_path,
                 'sha256': fingerprint(decision), 'decision_ref': decision_ref}}
        require(current == before or current == after, 'REGISTRY_HEAD_DRIFT',
                'Current changed; create a scoped successor', 'FORMAL_SAVE')
        receipts = []
        # A crash after a prefix leaves the old Current selector active. Equal
        # artifacts are read back; no version, Decision or Promotion is repeated.
        for a in plan['artifacts']:
            receipts.append(save_verified(Path(a['source']['path']), safe_destination(root, a['destination'])))
        decision_target = safe_destination(root, decision_path)
        if decision_target.exists():
            require(read_json(decision_target) == decision, 'DECISION_CONFLICT', decision_path, 'FORMAL_SAVE')
        else:
            write_json(decision_target, decision)
        if current != after:
            write_json(selector, after)
        observed = resolve_current(root, plan['current_selector'])
        require(observed == after, 'FORMAL_READBACK', 'Current resolution differs', 'FORMAL_SAVE')
        return {'status': 'PASS', 'transaction_sha256': transaction, 'decision_ref': decision_ref,
                'current': observed, 'artifacts': receipts, 'native_receipt': native_receipt,
                'idempotent_replay': current == after,
                'repository_persistence': 'REMOTE_COMMIT_READBACK_REQUIRED'}


def validate_downstream(plan):
    require(not plan.get('unknown_impact'), 'DOWNSTREAM_UNKNOWN', 'Resolve unknown consumers', 'DOWNSTREAM_UPDATE')
    paths = [a['path'] for a in plan['updates']]
    require(len(paths) == len(set(paths)), 'DUPLICATE_DOWNSTREAM', 'Duplicate target path', 'DOWNSTREAM_UPDATE')
    for a in plan['updates']:
        require(plan['components'].get(a['component']) == 'UPDATE_REQUIRED',
                'OUTSIDE_IMPACT_SCOPE', a['path'], 'DOWNSTREAM_UPDATE')
        require(sha(checked_bytes(a['source'])) == a['after_sha256'],
                'DOWNSTREAM_HASH', a['path'], 'DOWNSTREAM_UPDATE')
    require({a['component'] for a in plan['updates']} ==
            {k for k, v in plan['components'].items() if v == 'UPDATE_REQUIRED'},
            'DOWNSTREAM_COVERAGE', 'Every impacted layer needs an admitted update', 'DOWNSTREAM_UPDATE')
    return fingerprint(plan)


def apply_downstream(checkout, work, plan, formal_result):
    identity = validate_downstream(plan)
    require(formal_result.get('status') == 'PASS' and formal_result['current']['product_id'] == plan['product_id']
            and formal_result['current']['revision'] == plan['revision'],
            'FORMAL_REQUIRED', 'Downstream target must be the saved Formal', 'DOWNSTREAM_UPDATE')
    checkpoint = Path(work) / 'downstream-transaction.json'
    with lock(Path(work) / '.downstream-lock'):
        prior = read_json(checkpoint) if checkpoint.exists() else {'plan_sha256': identity, 'completed': []}
        require(prior['plan_sha256'] == identity, 'DOWNSTREAM_PLAN_DRIFT', 'Pinned plan changed', 'RESUME')
        # Preflight the entire transaction before any mutation. A partial prefix
        # is allowed only when every path still has its exact before/after hash.
        for a in plan['updates']:
            target = safe_destination(checkout, a['path'])
            actual = sha(target.read_bytes()) if target.is_file() else None
            require(actual in (a['before_sha256'], a['after_sha256']),
                    'DOWNSTREAM_HEAD_DRIFT', a['path'], 'DOWNSTREAM_UPDATE')
        for name, expected in plan.get('unchanged_paths', {}).items():
            target = safe_destination(checkout, name)
            require(target.is_file() and sha(target.read_bytes()) == expected,
                    'UNAFFECTED_COMPONENT_CHANGED', name, 'DOWNSTREAM_UPDATE')
        for a in plan['updates']:
            target = safe_destination(checkout, a['path'])
            if not target.is_file() or sha(target.read_bytes()) != a['after_sha256']:
                atomic(target, checked_bytes(a['source']))
            require(sha(target.read_bytes()) == a['after_sha256'], 'DOWNSTREAM_READBACK', a['path'], 'DOWNSTREAM_UPDATE')
            if a['path'] not in prior['completed']:
                prior['completed'].append(a['path'])
                write_json(checkpoint, prior)
        return {'status': 'PASS', 'plan_sha256': identity, 'completed_paths': prior['completed'],
                'components': plan['components'], 'remote_readback': 'REQUIRED_AFTER_PR_MERGE'}
