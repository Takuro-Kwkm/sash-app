"""Fresh Current selection and immutable per-Work compatibility binding.

The GA terminal index proves a historical activation, not a floating HEAD lock.
Registry admissions may grow; executable semantics require explicit adoption.
"""
import json
import subprocess
from pathlib import Path
from .core import fingerprint, read_json, require, sha, write_json

CENTRAL = 'Takuro-Kwkm/product-ui-contracts'
SEMANTIC_DIRS = ('harness', 'product_master', 'product_change', 'work_skills', 'schemas', 'workflows')
SEMANTIC_SCRIPTS = ('scripts/architecture-work.py', 'scripts/production-work.py',
                    'scripts/prepare-current-state.py', 'scripts/verify-current-state.py', 'scripts/verify-ga-index.py',
                    'registries/work-routing.v2.json', 'registries/production-boundaries.v2.json')


def adoption_contract(root):
    root = Path(root)
    a = read_json(root / 'registries/current-architecture.v2.json')
    additive = ('product_routes', 'new_product_build_profiles', 'supported_repositories')
    return {'central_repository': CENTRAL, 'current_architecture': a['current_architecture'],
            'current_router': a['current_router'], 'frozen_engine': a['frozen_engine'],
            'semantic_hashes': semantic_hashes(root), 'required_current_entries': {k:a[k] for k in additive},
            'architecture_contract': {k:v for k,v in a.items() if k not in additive},
            'skill_authority_sha256': sha((root / 'registries/skill-authority.v2.json').read_bytes())}


def semantic_hashes(root):
    root = Path(root).resolve()
    paths = set(SEMANTIC_SCRIPTS)
    for directory in SEMANTIC_DIRS:
        paths.update(p.relative_to(root).as_posix() for p in (root / directory).rglob('*')
                     if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py', '.json', '.md'))
    return {p: sha((root / p).read_bytes()) for p in sorted(paths) if (root / p).is_file()}


def compatibility(root, checkout):
    root, checkout = Path(root).resolve(), Path(checkout).resolve()
    adopted = read_json(checkout / 'contracts/production/current-authority-adoption.json')
    require(set(adoption_contract(root)).issubset(adopted), 'CURRENT_AUTHORITY_INCOMPATIBLE',
            'Incomplete consumer adoption contract', 'INITIALIZATION')
    current = read_json(root / 'registries/current-architecture.v2.json')
    actual = semantic_hashes(root)
    require(adopted.get('central_repository') == CENTRAL and adopted.get('semantic_hashes') == actual,
            'CURRENT_AUTHORITY_INCOMPATIBLE', 'Shared engine, Skill, schema or DAG semantics changed without adoption', 'INITIALIZATION')
    require(current['current_architecture'] == adopted['current_architecture']
            and current['frozen_engine'] == adopted['frozen_engine']
            and current['current_router'] == adopted['current_router'],
            'CURRENT_AUTHORITY_INCOMPATIBLE', 'Critical Architecture contract changed', 'INITIALIZATION')
    additive = ('product_routes', 'new_product_build_profiles', 'supported_repositories')
    require({k:v for k,v in current.items() if k not in additive} == adopted['architecture_contract'],
            'CURRENT_AUTHORITY_INCOMPATIBLE', 'Unknown or changed critical Authority contract', 'INITIALIZATION')
    if 'required_current_entries' in adopted:
        prior = adopted['required_current_entries']
        routes = {p['product_id']: p for p in current['product_routes']}
        require(all(routes.get(p['product_id']) == p for p in prior['product_routes'])
                and all(current['new_product_build_profiles'].get(k) == v for k, v in prior['new_product_build_profiles'].items())
                and set(prior['supported_repositories']).issubset(current['supported_repositories']),
                'CURRENT_AUTHORITY_INCOMPATIBLE', 'Current registry mutation is not additive', 'INITIALIZATION')
    if 'skill_authority_sha256' in adopted:
        require(sha((root / 'registries/skill-authority.v2.json').read_bytes()) == adopted['skill_authority_sha256'],
                'CURRENT_AUTHORITY_INCOMPATIBLE', 'Canonical Skill Authority selector changed', 'INITIALIZATION')
    for path, expected in current['frozen_engine']['files'].items():
        require(sha((root / path).read_bytes()) == expected, 'CURRENT_AUTHORITY_INCOMPATIBLE', path, 'INITIALIZATION')
    return {'status': 'PASS', 'policy': 'EXACT_SEMANTIC_ADOPTION; ADDITIVE_REGISTRY_ALLOWED',
            'semantic_hashes': actual, 'adoption_sha256': sha((checkout / 'contracts/production/current-authority-adoption.json').read_bytes())}


def acquire(root, checkout, destination):
    """Acquire remote default branch, then checkout the observed immutable commit."""
    root, destination = Path(root).resolve(), Path(destination).resolve()
    require(not destination.exists(), 'WORK_ALREADY_EXISTS', 'Resume the saved binding or create a successor', 'INITIALIZATION')
    def git(*args, cwd=root):
        return subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()
    url = git('remote', 'get-url', 'origin')
    require(url.rstrip('/').removesuffix('.git').endswith('github.com/' + CENTRAL),
            'CURRENT_AUTHORITY_UNVERIFIED', 'Wrong Central remote', 'INITIALIZATION')
    remote = git('ls-remote', '--symref', 'origin', 'HEAD').splitlines()
    refs = [r.split()[1] for r in remote if r.startswith('ref:')]
    heads = [r.split()[0] for r in remote if r.endswith('\tHEAD') and not r.startswith('ref:')]
    require(len(refs) == len(heads) == 1, 'CURRENT_AUTHORITY_UNVERIFIED', 'Remote default HEAD missing', 'INITIALIZATION')
    snapshot = destination / 'authority'
    snapshot.mkdir(parents=True)
    git('init', cwd=snapshot)
    git('remote', 'add', 'origin', url, cwd=snapshot)
    git('fetch', '--quiet', '--depth=1', 'origin', heads[0], cwd=snapshot)
    git('checkout', '--quiet', '--detach', heads[0], cwd=snapshot)
    proof = compatibility(snapshot, checkout)
    require(semantic_hashes(root) == proof['semantic_hashes'], 'CURRENT_AUTHORITY_INCOMPATIBLE',
            'Host execution checkout differs from fresh Current semantics; synchronize before Work', 'INITIALIZATION')
    registry_paths = ('registries/current-architecture.v2.json', 'registries/skill-authority.v2.json')
    binding = {'central_repository': CENTRAL, 'selector': 'REMOTE_DEFAULT_BRANCH', 'remote_default_branch': refs[0],
               'current_head': heads[0], 'snapshot_root': str(snapshot),
               'authority_hashes': {p: sha((snapshot / p).read_bytes()) for p in registry_paths},
               'compatibility': proof, 'resume_policy': 'KEEP_IMMUTABLE_BINDING; changed inputs require successor'}
    binding['binding_sha256'] = fingerprint(binding)
    write_json(destination / 'current-authority-binding.json', binding)
    return snapshot, binding


def inspect_binding(binding):
    require(binding['binding_sha256'] == fingerprint({k: v for k, v in binding.items() if k != 'binding_sha256'}),
            'IMMUTABLE_WORK_CHANGED', 'Authority binding changed', 'RESUME')
    root = Path(binding['snapshot_root'])
    for path, expected in {**binding['authority_hashes'], **binding['compatibility']['semantic_hashes']}.items():
        require(sha((root / path).read_bytes()) == expected, 'IMMUTABLE_WORK_CHANGED', path, 'RESUME')
    return {'status': 'PASS', 'current_head': binding['current_head'], 'successor_required_for_new_inputs': True}


def verify_ga_successor(root, checkouts, repository, ga_head, current_head):
    """Keep GA's exact historical CI proof; authenticate a compatible successor."""
    checkout = Path(root if repository == CENTRAL else checkouts[repository]).resolve()
    actual_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip()
    require(actual_head == current_head, 'CURRENT_AUTHORITY_UNVERIFIED', 'Fresh Main/checkout identity differs', 'GA')
    ancestor = subprocess.run(['git', 'merge-base', '--is-ancestor', ga_head, current_head], cwd=checkout)
    require(ancestor.returncode == 0, 'CURRENT_AUTHORITY_INCOMPATIBLE', 'GA history is not carried forward', 'GA')
    paths = semantic_hashes(root) if repository == CENTRAL else {
        p.relative_to(checkout).as_posix(): sha(p.read_bytes())
        for directory in ('contracts/production', 'scripts/production')
        for p in (checkout / directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    for path, expected in paths.items():
        committed = subprocess.check_output(['git', 'show', current_head + ':' + path], cwd=checkout)
        require(sha(committed) == expected, 'CURRENT_AUTHORITY_UNVERIFIED', 'Uncommitted critical bytes: ' + path, 'GA')
    if repository == CENTRAL:
        for native in checkouts.values():
            compatibility(root, native)
    else:
        compatibility(root, checkout)
        from .architecture import resolve
        resolve(root, {repository: str(checkout)})
    return {'status': 'PASS', 'ga_activation_head': ga_head, 'current_head': current_head}
