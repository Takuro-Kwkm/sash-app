"""Current production resolution only; execution stays in the existing v2 engine."""
import json
import re
from pathlib import Path
from .core import require, read_json, sha
from .production import short_route

CURRENT = 'APP_DEVELOPMENT_SKILL_ARCHITECTURE_V2'


def resolve_build_profile(root, checkout, repository, config):
    """Resolve an explicitly adopted repository interface, without executing it."""
    authority = read_json(Path(root) / 'registries/current-architecture.v2.json')
    entry = config.get('new_product_build_profile')
    admitted = authority.get('new_product_build_profiles', {}).get(repository)
    require(entry and admitted and entry['profile_id'] == admitted['profile_id'],
            'NATIVE_BUILD_PROFILE_REQUIRED', repository + ': admitted repository profile required', 'ROUTER')
    checkout, root = Path(checkout).resolve(), Path(root).resolve()

    def owned(base, name):
        path = (base / name).resolve()
        require(not Path(name).is_absolute() and path.is_relative_to(base) and path.is_file(),
                'NATIVE_BUILD_PROFILE_INVALID', 'Missing or escaping profile reference: ' + name, 'ROUTER')
        return path

    path = owned(checkout, entry['path'])
    require(sha(path.read_bytes()) == entry['sha256'], 'NATIVE_BUILD_PROFILE_INVALID', 'Profile bytes changed', 'ROUTER')
    profile = read_json(path)
    from jsonschema import Draft202012Validator
    schema = read_json(owned(root, admitted['schema']))
    require(not list(Draft202012Validator(schema).iter_errors(profile)),
            'NATIVE_BUILD_PROFILE_INVALID', 'Profile schema rejected', 'ROUTER')
    require(profile['repository'] == repository and profile['profile_id'] == entry['profile_id'],
            'NATIVE_BUILD_PROFILE_INVALID', 'Profile repository/identity mismatch', 'ROUTER')
    for ref in profile['refs'].values():
        source = owned(checkout if ref['owner'] == 'native' else root, ref['path'])
        require(sha(source.read_bytes()) == ref['sha256'], 'NATIVE_BUILD_PROFILE_INVALID', ref['path'], 'ROUTER')
    pointer = read_json(checkout / 'contracts/production/current-architecture.json')
    require(pointer.get('new_product_build_profile') == entry,
            'NATIVE_BUILD_PROFILE_INVALID', 'Current and Adapter profile pointers differ', 'ROUTER')
    validators = read_json(owned(checkout, pointer['validator_registry']))
    require(validators.get('build_profiles', {}).get(entry['profile_id']) == {
        'state': 'READY', 'validator': profile['refs']['native_validator']['path'], 'no_fallback': True},
        'NATIVE_BUILD_PROFILE_INVALID', 'Native validator registration differs', 'ROUTER')
    return profile, entry


def bootstrap_route(root, repositories, configs, authority, instruction):
    # A new label is data, never a new manufacturer fact or registered product.
    match = re.fullmatch(r'\s*(.+?)\s*(?:の)?商品マスター(?:を)?(?:新規)?(?:作成して|作って|作成する|作成)(?:くれ|ください)?\s*[。！!]?\s*', instruction)
    require(match is not None, 'PRODUCTION_TARGET_AMBIGUOUS', 'One explicit new product label required', 'ROUTER')
    label = match.group(1).removesuffix('の').strip()
    require(label and not re.search(r'[\n/,、と&＆]', label),
            'PRODUCTION_TARGET_AMBIGUOUS', 'Separate multiple new products', 'ROUTER')
    require(len(configs) == 1, 'REPOSITORY_ACQUISITION_REQUIRED',
            'New product requires one explicit acquired repository context', 'ROUTER')
    repository = next(iter(configs))
    profile, entry = resolve_build_profile(root, repositories[repository], repository, configs[repository])
    return {'repository': repository, 'product_id': 'NEW-CANDIDATE-' + sha(label.encode())[:24],
            'requested_product': label, 'work_skill': 'product-master-builder', 'work_type': 'PRODUCT_MASTER_BUILD',
            'operation': 'NEW_PRODUCT_BOOTSTRAP', 'registry_state': 'REQUIRES_LIVE_NATIVE_ABSENCE_CHECK',
            'native_profile': entry, 'profile': profile, 'mode': profile['mode'], 'writes': 0,
            'current_architecture': CURRENT, 'current_router': authority['current_router'], 'legacy_selection': 0}


def resolve(root, repositories):
    root = Path(root).resolve()
    authority = read_json(root / 'registries/current-architecture.v2.json')
    require(authority['current_architecture'] == CURRENT and authority['status'] in ('GA_CANDIDATE', 'GA'),
            'ARCHITECTURE_NOT_CURRENT', 'Acquire the unique Current v2 authority', 'RESOLUTION')
    for path, expected in authority['frozen_engine']['files'].items():
        require(sha((root / path).read_bytes()) == expected, 'SHARED_HARNESS_FORK', path, 'RESOLUTION')
    configs = {}
    for repository, checkout in repositories.items():
        require(repository in authority['supported_repositories'], 'UNSUPPORTED_REPOSITORY', repository, 'ROUTER')
        checkout = Path(checkout).resolve()
        pointer = read_json(checkout / 'contracts/production/current-architecture.json')
        require(pointer['current_architecture'] == CURRENT and pointer['current_router'] == authority['current_router']
                and pointer['shared_harness_sha'] == authority['frozen_engine']['revision'],
                'CURRENT_AUTHORITY_CONFLICT', repository, 'RESOLUTION')
        config = read_json(checkout / pointer['adapter_registry'])
        require(pointer['architecture_authority']['ref'] == config['shared_authority']['commit'],
                'CURRENT_AUTHORITY_CONFLICT', 'Consumer pointer and adoption pin disagree', 'RESOLUTION')
        for path, expected in pointer.get('shared_router_files', {}).items():
            actual = sha((root / path).read_bytes())
            compatibility = authority.get('existing_route_compatibility', {}).get(path, {})
            preserved_existing = (compatibility.get('scope') == 'EXISTING_ROUTES_ONLY'
                                  and expected == compatibility.get('prior_sha256')
                                  and actual == compatibility.get('current_sha256')
                                  and not config.get('new_product_build_profile'))
            require(actual == expected or preserved_existing, 'CURRENT_ROUTER_CHANGED', path, 'RESOLUTION')
        require(config['shared_authority']['harness_revision'] == authority['frozen_engine']['revision'],
                'SHARED_HARNESS_FORK', repository, 'RESOLUTION')
        require(all(p['repository'] == repository for p in config['products']),
                'CROSS_REPOSITORY_STALE_ADAPTER', repository, 'RESOLUTION')
        require(config['status'] == 'CURRENT', 'REGISTRY_NOT_CURRENT', repository, 'RESOLUTION')
        configs[repository] = config
    return authority, configs


def route_instruction(root, repositories, instruction, selected_product=None):
    authority, configs = resolve(root, repositories)
    hits = []
    for product in authority['product_routes']:
        for alias in product['aliases']:
            pattern = r'(?<![A-Za-z0-9])' + re.escape(alias) + r'(?![A-Za-z0-9])' if alias.isascii() else re.escape(alias)
            for match in re.finditer(pattern, instruction, re.I):
                hits.append((match.start(), match.end(), product))
    # Nested aliases identify the more specific product; disjoint products never
    # resolve merely because one has a longer name.
    hits = [h for h in hits if not any(a <= h[0] and b >= h[1] and b-a > h[1]-h[0] for a,b,_ in hits)]
    products = {p['product_id']: p for _,_,p in hits}
    build_intent = any(word in instruction for word in ('新規', '作成', '作って')) and any(
        word in instruction for word in ('商品マスター', 'Product Master'))
    if not hits and not selected_product and build_intent:
        return bootstrap_route(root, repositories, configs, authority, instruction)
    if not hits and selected_product:
        products = {p['product_id']: p for p in authority['product_routes'] if p['product_id'] == selected_product}
    require(len(products) == 1, 'PRODUCTION_TARGET_AMBIGUOUS', 'One explicit product or saved Work binding required', 'ROUTER')
    product = next(iter(products.values()))
    repository = product['repository']
    require(repository in configs, 'REPOSITORY_ACQUISITION_REQUIRED', repository, 'ROUTER')
    config = configs[repository]
    native = [p for p in config['products'] if p['product_id'] == product['product_id']]
    require(len(native) == 1, 'PRODUCT_REGISTRY_DRIFT', product['product_id'], 'ROUTER')
    require(native[0]['aliases'] == product['aliases'], 'PRODUCT_REGISTRY_DRIFT', 'Reacquire Current routing registry', 'ROUTER')
    if any(word in instruction for word in ('新規', '作成', '作って')) and any(
            word in instruction for word in ('商品マスター', 'Product Master')):
        require(native[0].get('build_profile'), 'NATIVE_BUILD_PROFILE_REQUIRED',
                product['product_id'] + ': acquire an admitted native builder profile; never treat creation as a change', 'ROUTER')
        return {'repository': repository, 'product_id': product['product_id'],
                'work_skill': 'product-master-builder', 'work_type': 'PRODUCT_MASTER_BUILD',
                'native_profile': native[0]['build_profile'], 'current_architecture': CURRENT,
                'current_router': authority['current_router'], 'legacy_selection': 0}
    result = short_route(instruction, config, product['product_id'])
    check_current = ('確認' in instruction or 'current-state' in instruction.lower()) and not any(
        word in instruction for word in ('反映', '更新', '採用', '再開', '作って', '作成'))
    if check_current:
        result.update(operation='CURRENT_STATE', target_gate='CURRENT_STATE_VERIFIED',
                      acceptance_contract='contracts/production/current-state.v2.json',
                      source_scope='CURRENT_ADOPTED_ONLY; NOT_LATEST_MANUFACTURER_DISCOVERY')
    result.update(current_architecture=CURRENT, current_router=authority['current_router'],
                  shared_harness_sha=authority['frozen_engine']['revision'], legacy_selection=0)
    return result


def select_work(index, repository, work_id=None):
    """Resolve explicit operational pointers; the existing engine owns Resume."""
    require(index.get('status') == 'CURRENT', 'RESUME_INDEX_NOT_CURRENT', repository, 'RESUME')
    candidates = [w for w in index['works'] if w['repository'] == repository
                  and w.get('state') != 'ABANDONED' and (not work_id or w['work_id'] == work_id)]
    if not work_id:
        candidates = [w for w in candidates if w.get('selected_current')]
    require(len(candidates) == 1, 'CURRENT_WORK_AMBIGUOUS', 'Select one immutable Work; never choose by chat recency', 'RESUME')
    work = candidates[0]
    terminal = work['state'] in ('COMPLETED', 'ARCHITECTURE_V2_GA_COMPLETED')
    return {**work, 'operation': 'INSPECT_ONLY' if terminal else 'RESUME_PENDING_ONLY',
            'duplicate_human_adoption': False, 'duplicate_formal_promotion': False}


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('route', 'resolve'))
    parser.add_argument('--repositories', required=True, help='Acquired repository -> checkout JSON map')
    parser.add_argument('--instruction'); parser.add_argument('--selected-product')
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    try:
        repositories = read_json(args.repositories)
        result = route_instruction(root, repositories, args.instruction, args.selected_product) if args.command == 'route' else {
            'status': 'PASS', 'authority': resolve(root, repositories)[0], 'legacy_selection': 0}
    except (OSError, KeyError, ValueError, TypeError, __import__('harness.core', fromlist=['Blocked']).Blocked) as error:
        result = {'state': 'FAIL_CLOSED', 'blocking_reason': getattr(error, 'data', {'code': 'AUTHORITY_ACQUISITION_REQUIRED', 'reason': str(error)}),
                  'legacy_selection': 0, 'reference_fallback': False}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 2 if result.get('state') == 'FAIL_CLOSED' else 0
