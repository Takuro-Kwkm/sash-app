"""Continue a frozen Work after a proven metadata-only unchanged-hash error.

The approved plan, scripts and accepted DAG events are never rewritten. A host
must supply both acquired Git trees and the live native Registry readback. Only
an unchanged path with identical baseline/current Git blobs can be corrected;
product updates, identities, impacts and Human Decision remain fixed.
"""
import copy
import hashlib
import json
from pathlib import Path
from .core import fingerprint, lock, read_json, require, sha, write_json
from .workflow import inspect, append
from .changed_path import apply_downstream, verify_decision, safe_destination
from .approved_continuation import approved_registry_guard


def tree_document(raw):
    value = raw.get('structuredContent', raw)
    if 'content' in value:
        value = json.loads(value['content'])
    require(isinstance(value.get('tree'), list) and not value.get('truncated'),
            'TREE_PROOF', 'Complete acquired Git tree required', 'DOWNSTREAM_UPDATE')
    return value


def corrected_plan(plan, proof, checkout, repository, head):
    require(proof.get('repository') == repository and proof.get('baseline_head') == head
            and proof.get('current_head') == head and proof.get('original_plan_sha256') == fingerprint(plan),
            'CORRECTION_BINDING', 'Repository, HEAD or approved plan differs', 'DOWNSTREAM_UPDATE')
    trees = [tree_document(proof[k]) for k in ('baseline_tree', 'current_tree')]
    require(trees[0]['sha'] == trees[1]['sha'], 'CORRECTION_HEAD_DRIFT',
            'Baseline and freshly acquired main tree differ', 'DOWNSTREAM_UPDATE')
    maps = [{a['path']: a for a in t['tree'] if a['type'] == 'blob'} for t in trees]
    corrections = proof.get('corrections', {})
    require(bool(corrections) and set(corrections).issubset(plan.get('unchanged_paths', {})),
            'CORRECTION_SCOPE', 'Only existing unchanged-path hashes may be corrected', 'DOWNSTREAM_UPDATE')
    require(not (set(corrections) & {a['path'] for a in plan['updates']}),
            'CORRECTION_SCOPE', 'Cannot repair an impacted artifact', 'DOWNSTREAM_UPDATE')
    effective = copy.deepcopy(plan)
    for path, correction in corrections.items():
        require(correction.get('before_sha256') == plan['unchanged_paths'][path],
                'CORRECTION_BINDING', 'Original unchanged hash differs', 'DOWNSTREAM_UPDATE')
        b = safe_destination(checkout, path).read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
        require(path in maps[0] and path in maps[1] and maps[0][path]['sha'] == maps[1][path]['sha'] == blob,
                'UNAFFECTED_COMPONENT_CHANGED', path, 'DOWNSTREAM_UPDATE')
        actual = sha(b)
        require(actual == correction.get('after_sha256') and actual != correction['before_sha256'],
                'CORRECTION_HASH', 'Actual unchanged bytes must prove the hash error', 'DOWNSTREAM_UPDATE')
        effective['unchanged_paths'][path] = actual
    return effective


def continue_verified(root, work, spec, live, before_registry, formal_plan, native_receipt,
                      plan, proof, checkout):
    root, work = Path(root), Path(work)
    with lock(work / '.workflow-lock'):
        state, _, _ = inspect(root, work, spec)
        packet = read_json(work / 'review-packets/HUMAN_ADOPTION.json')
        require(packet['work_binding_sha256'] == fingerprint(spec), 'STALE_DECISION',
                'Frozen Work changed', 'DOWNSTREAM_UPDATE')
        require(packet['native_packet']['downstream_plan_sha256'] == fingerprint(plan),
                'STALE_DECISION', 'Downstream plan is not the approved plan', 'DOWNSTREAM_UPDATE')
        decision = read_json(spec['decisions']['HUMAN_ADOPTION'])
        decision_ref = verify_decision(packet, decision)
        binding = read_json(root / spec['production_binding']['path'])
        require(sha((root / spec['production_binding']['path']).read_bytes()) == spec['production_binding']['sha256'],
                'PRODUCTION_BINDING_CHANGED', 'Frozen live binding changed', 'RESUME')
        guard = approved_registry_guard(binding, live, before_registry, formal_plan, packet, decision,
                  native_receipt, {p: Path(binding['checkout']) / p for p in binding['files']})
        effective = corrected_plan(plan, proof, checkout, binding['repository'], binding['head_sha'])
        if state['state'] == 'COMPLETED':
            return {**state, 'idempotent_replay': True, 'approved_native_continuation': guard}
        require(state['pending_gates'] == ['DOWNSTREAM_UPDATE'], 'WORKFLOW_ORDER',
                'Only the final pending downstream gate is admitted', 'DOWNSTREAM_UPDATE')
        formal = read_json(work / 'FORMAL_ADOPTION.json')
        require(formal['decision_ref'] == decision_ref, 'STALE_DECISION',
                'Saved Formal decision differs', 'DOWNSTREAM_UPDATE')
        result = apply_downstream(checkout, work, effective, formal)
        output = work / 'DOWNSTREAM_UPDATE.json'
        correction_path = work / 'verified-downstream-correction.json'
        write_json(correction_path, {'status': 'VERIFIED_METADATA_CORRECTION', 'proof': proof,
                  'original_plan_sha256': fingerprint(plan), 'effective_plan_sha256': fingerprint(effective),
                  'effective_plan': effective, 'decision_ref': decision_ref,
                  'implementation_sha256': sha(Path(__file__).read_bytes())})
        write_json(output, {'status': 'PASS', 'downstream_change': result,
                  'execution': 'VERIFIED_HOST_ADAPTER', 'original_validator_result': 'BLOCKED_HASH_METADATA_ERROR',
                  'approved_plan_sha256': fingerprint(plan), 'correction_sha256': sha(correction_path.read_bytes())})
        artifacts = [{'path': str(p.resolve()), 'sha256': sha(p.read_bytes())}
                     for p in (output, correction_path, Path(__file__))]
        artifacts += [{'path': str(safe_destination(checkout, a['path']).resolve()), 'sha256': a['after_sha256']}
                      for a in plan['updates']]
        append(work, spec, 'DOWNSTREAM_UPDATE', {'execution': 'VERIFIED_HOST_ADAPTER',
               'implementation': 'harness/verified_downstream_continuation.py', 'artifacts': artifacts,
               'approved_native_continuation': guard})
        state, _, _ = inspect(root, work, spec)
        write_json(work / 'workflow-result.json', state)
        return state
